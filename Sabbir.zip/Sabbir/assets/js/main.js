! function (e, t) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function (e) {
        if (!e.document) throw new Error("jQuery requires a window with a document");
        return t(e)
    } : t(e)
}("undefined" != typeof window ? window : this, function (w, e) {
    function r(e) {
        var t = !!e && "length" in e && e.length,
            n = he.type(e);
        return "function" !== n && !he.isWindow(e) && ("array" === n || 0 === t || "number" == typeof t && 0 < t && t - 1 in e)
    }

    function t(e, n, i) {
        if (he.isFunction(n)) return he.grep(e, function (e, t) {
            return !!n.call(e, t, e) !== i
        });
        if (n.nodeType) return he.grep(e, function (e) {
            return e === n !== i
        });
        if ("string" == typeof n) {
            if (we.test(n)) return he.filter(n, e, i);
            n = he.filter(n, e)
        }
        return he.grep(e, function (e) {
            return -1 < he.inArray(e, n) !== i
        })
    }

    function n(e, t) {
        for (;
            (e = e[t]) && 1 !== e.nodeType;);
        return e
    }

    function c(e) {
        var n = {};
        return he.each(e.match(Me) || [], function (e, t) {
            n[t] = !0
        }), n
    }

    function a() {
        ie.addEventListener ? (ie.removeEventListener("DOMContentLoaded", s), w.removeEventListener("load", s)) : (ie.detachEvent("onreadystatechange", s), w.detachEvent("onload", s))
    }

    function s() {
        (ie.addEventListener || "load" === w.event.type || "complete" === ie.readyState) && (a(), he.ready())
    }

    function l(e, t, n) {
        if (n === undefined && 1 === e.nodeType) {
            var i = "data-" + t.replace(Ie, "-$1").toLowerCase();
            if ("string" == typeof (n = e.getAttribute(i))) {
                try {
                    n = "true" === n || "false" !== n && ("null" === n ? null : +n + "" === n ? +n : je.test(n) ? he.parseJSON(n) : n)
                } catch (a) {}
                he.data(e, t, n)
            } else n = undefined
        }
        return n
    }

    function d(e) {
        var t;
        for (t in e)
            if (("data" !== t || !he.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
        return !0
    }

    function i(e, t, n, i) {
        if (Re(e)) {
            var a, s, o = he.expando,
                r = e.nodeType,
                l = r ? he.cache : e,
                d = r ? e[o] : e[o] && o;
            if (d && l[d] && (i || l[d].data) || n !== undefined || "string" != typeof t) return d || (d = r ? e[o] = ne.pop() || he.guid++ : o), l[d] || (l[d] = r ? {} : {
                toJSON: he.noop
            }), "object" != typeof t && "function" != typeof t || (i ? l[d] = he.extend(l[d], t) : l[d].data = he.extend(l[d].data, t)), s = l[d], i || (s.data || (s.data = {}), s = s.data), n !== undefined && (s[he.camelCase(t)] = n), "string" == typeof t ? null == (a = s[t]) && (a = s[he.camelCase(t)]) : a = s, a
        }
    }

    function o(e, t, n) {
        if (Re(e)) {
            var i, a, s = e.nodeType,
                o = s ? he.cache : e,
                r = s ? e[he.expando] : he.expando;
            if (o[r]) {
                if (t && (i = n ? o[r] : o[r].data)) {
                    a = (t = he.isArray(t) ? t.concat(he.map(t, he.camelCase)) : t in i ? [t] : (t = he.camelCase(t)) in i ? [t] : t.split(" ")).length;
                    for (; a--;) delete i[t[a]];
                    if (n ? !d(i) : !he.isEmptyObject(i)) return
                }(n || (delete o[r].data, d(o[r]))) && (s ? he.cleanData([e], !0) : ue.deleteExpando || o != o.window ? delete o[r] : o[r] = undefined)
            }
        }
    }

    function u(e, t, n, i) {
        var a, s = 1,
            o = 20,
            r = i ? function () {
                return i.cur()
            } : function () {
                return he.css(e, t, "")
            },
            l = r(),
            d = n && n[3] || (he.cssNumber[t] ? "" : "px"),
            c = (he.cssNumber[t] || "px" !== d && +l) && Pe.exec(he.css(e, t));
        if (c && c[3] !== d)
            for (d = d || c[3], n = n || [], c = +l || 1; c /= s = s || ".5", he.style(e, t, c + d), s !== (s = r() / l) && 1 !== s && --o;);
        return n && (c = +c || +l || 0, a = n[1] ? c + (n[1] + 1) * n[2] : +n[2], i && (i.unit = d, i.start = c, i.end = a)), a
    }

    function g(e) {
        var t = Ve.split("|"),
            n = e.createDocumentFragment();
        if (n.createElement)
            for (; t.length;) n.createElement(t.pop());
        return n
    }

    function v(e, t) {
        var n, i, a = 0,
            s = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : undefined;
        if (!s)
            for (s = [], n = e.childNodes || e; null != (i = n[a]); a++) !t || he.nodeName(i, t) ? s.push(i) : he.merge(s, v(i, t));
        return t === undefined || t && he.nodeName(e, t) ? he.merge([e], s) : s
    }

    function b(e, t) {
        for (var n, i = 0; null != (n = e[i]); i++) he._data(n, "globalEval", !t || he._data(t[i], "globalEval"))
    }

    function y(e) {
        Ge.test(e.type) && (e.defaultChecked = e.checked)
    }

    function m(e, t, n, i, a) {
        for (var s, o, r, l, d, c, u, p = e.length, h = g(t), f = [], m = 0; m < p; m++)
            if ((o = e[m]) || 0 === o)
                if ("object" === he.type(o)) he.merge(f, o.nodeType ? [o] : o);
                else if (Ue.test(o)) {
            for (l = l || h.appendChild(t.createElement("div")), d = (ze.exec(o) || ["", ""])[1].toLowerCase(), u = Ke[d] || Ke._default, l.innerHTML = u[1] + he.htmlPrefilter(o) + u[2], s = u[0]; s--;) l = l.lastChild;
            if (!ue.leadingWhitespace && Ye.test(o) && f.push(t.createTextNode(Ye.exec(o)[0])), !ue.tbody)
                for (s = (o = "table" !== d || Xe.test(o) ? "<table>" !== u[1] || Xe.test(o) ? 0 : l : l.firstChild) && o.childNodes.length; s--;) he.nodeName(c = o.childNodes[s], "tbody") && !c.childNodes.length && o.removeChild(c);
            for (he.merge(f, l.childNodes), l.textContent = ""; l.firstChild;) l.removeChild(l.firstChild);
            l = h.lastChild
        } else f.push(t.createTextNode(o));
        for (l && h.removeChild(l), ue.appendChecked || he.grep(v(f, "input"), y), m = 0; o = f[m++];)
            if (i && -1 < he.inArray(o, i)) a && a.push(o);
            else if (r = he.contains(o.ownerDocument, o), l = v(h.appendChild(o), "script"), r && b(l), n)
            for (s = 0; o = l[s++];) We.test(o.type || "") && n.push(o);
        return l = null, h
    }

    function p() {
        return !0
    }

    function h() {
        return !1
    }

    function f() {
        try {
            return ie.activeElement
        } catch (e) {}
    }

    function x(e, t, n, i, a, s) {
        var o, r;
        if ("object" == typeof t) {
            for (r in "string" != typeof n && (i = i || n, n = undefined), t) x(e, r, n, i, t[r], s);
            return e
        }
        if (null == i && null == a ? (a = n, i = n = undefined) : null == a && ("string" == typeof n ? (a = i, i = undefined) : (a = i, i = n, n = undefined)), !1 === a) a = h;
        else if (!a) return e;
        return 1 === s && (o = a, (a = function (e) {
            return he().off(e), o.apply(this, arguments)
        }).guid = o.guid || (o.guid = he.guid++)), e.each(function () {
            he.event.add(this, t, a, i, n)
        })
    }

    function _(e, t) {
        return he.nodeName(e, "table") && he.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
    }

    function k(e) {
        return e.type = (null !== he.find.attr(e, "type")) + "/" + e.type, e
    }

    function C(e) {
        var t = rt.exec(e.type);
        return t ? e.type = t[1] : e.removeAttribute("type"), e
    }

    function T(e, t) {
        if (1 === t.nodeType && he.hasData(e)) {
            var n, i, a, s = he._data(e),
                o = he._data(t, s),
                r = s.events;
            if (r)
                for (n in delete o.handle, o.events = {}, r)
                    for (i = 0, a = r[n].length; i < a; i++) he.event.add(t, n, r[n][i]);
            o.data && (o.data = he.extend({}, o.data))
        }
    }

    function S(e, t) {
        var n, i, a;
        if (1 === t.nodeType) {
            if (n = t.nodeName.toLowerCase(), !ue.noCloneEvent && t[he.expando]) {
                for (i in (a = he._data(t)).events) he.removeEvent(t, i, a.handle);
                t.removeAttribute(he.expando)
            }
            "script" === n && t.text !== e.text ? (k(t).text = e.text, C(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), ue.html5Clone && e.innerHTML && !he.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Ge.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected : "input" !== n && "textarea" !== n || (t.defaultValue = e.defaultValue)
        }
    }

    function D(n, i, a, s) {
        i = se.apply([], i);
        var e, t, o, r, l, d, c = 0,
            u = n.length,
            p = u - 1,
            h = i[0],
            f = he.isFunction(h);
        if (f || 1 < u && "string" == typeof h && !ue.checkClone && ot.test(h)) return n.each(function (e) {
            var t = n.eq(e);
            f && (i[0] = h.call(this, e, t.html())), D(t, i, a, s)
        });
        if (u && (e = (d = m(i, n[0].ownerDocument, !1, n, s)).firstChild, 1 === d.childNodes.length && (d = e), e || s)) {
            for (o = (r = he.map(v(d, "script"), k)).length; c < u; c++) t = d, c !== p && (t = he.clone(t, !0, !0), o && he.merge(r, v(t, "script"))), a.call(n[c], t, c);
            if (o)
                for (l = r[r.length - 1].ownerDocument, he.map(r, C), c = 0; c < o; c++) t = r[c], We.test(t.type || "") && !he._data(t, "globalEval") && he.contains(l, t) && (t.src ? he._evalUrl && he._evalUrl(t.src) : he.globalEval((t.text || t.textContent || t.innerHTML || "").replace(lt, "")));
            d = e = null
        }
        return n
    }

    function E(e, t, n) {
        for (var i, a = t ? he.filter(t, e) : e, s = 0; null != (i = a[s]); s++) n || 1 !== i.nodeType || he.cleanData(v(i)), i.parentNode && (n && he.contains(i.ownerDocument, i) && b(v(i, "script")), i.parentNode.removeChild(i));
        return e
    }

    function N(e, t) {
        var n = he(t.createElement(e)).appendTo(t.body),
            i = he.css(n[0], "display");
        return n.detach(), i
    }

    function M(e) {
        var t = ie,
            n = ut[e];
        return n || ("none" !== (n = N(e, t)) && n || ((t = ((ct = (ct || he("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement))[0].contentWindow || ct[0].contentDocument).document).write(), t.close(), n = N(e, t), ct.detach()), ut[e] = n), n
    }

    function A(e, t) {
        return {
            get: function () {
                if (!e()) return (this.get = t).apply(this, arguments);
                delete this.get
            }
        }
    }

    function R(e) {
        if (e in St) return e;
        for (var t = e.charAt(0).toUpperCase() + e.slice(1), n = Tt.length; n--;)
            if ((e = Tt[n] + t) in St) return e
    }

    function j(e, t) {
        for (var n, i, a, s = [], o = 0, r = e.length; o < r; o++)(i = e[o]).style && (s[o] = he._data(i, "olddisplay"), n = i.style.display, t ? (s[o] || "none" !== n || (i.style.display = ""), "" === i.style.display && Be(i) && (s[o] = he._data(i, "olddisplay", M(i.nodeName)))) : (a = Be(i), (n && "none" !== n || !a) && he._data(i, "olddisplay", a ? n : he.css(i, "display"))));
        for (o = 0; o < r; o++)(i = e[o]).style && (t && "none" !== i.style.display && "" !== i.style.display || (i.style.display = t ? s[o] || "" : "none"));
        return e
    }

    function I(e, t, n) {
        var i = kt.exec(t);
        return i ? Math.max(0, i[1] - (n || 0)) + (i[2] || "px") : t
    }

    function L(e, t, n, i, a) {
        for (var s = n === (i ? "border" : "content") ? 4 : "width" === t ? 1 : 0, o = 0; s < 4; s += 2) "margin" === n && (o += he.css(e, n + qe[s], !0, a)), i ? ("content" === n && (o -= he.css(e, "padding" + qe[s], !0, a)), "margin" !== n && (o -= he.css(e, "border" + qe[s] + "Width", !0, a))) : (o += he.css(e, "padding" + qe[s], !0, a), "padding" !== n && (o += he.css(e, "border" + qe[s] + "Width", !0, a)));
        return o
    }

    function F(e, t, n) {
        var i = !0,
            a = "width" === t ? e.offsetWidth : e.offsetHeight,
            s = gt(e),
            o = ue.boxSizing && "border-box" === he.css(e, "boxSizing", !1, s);
        if (a <= 0 || null == a) {
            if (((a = vt(e, t, s)) < 0 || null == a) && (a = e.style[t]), ht.test(a)) return a;
            i = o && (ue.boxSizingReliable() || a === e.style[t]), a = parseFloat(a) || 0
        }
        return a + L(e, t, n || (o ? "border" : "content"), i, s) + "px"
    }

    function O(e, t, n, i, a) {
        return new O.prototype.init(e, t, n, i, a)
    }

    function H() {
        return w.setTimeout(function () {
            Dt = undefined
        }), Dt = he.now()
    }

    function P(e, t) {
        var n, i = {
                height: e
            },
            a = 0;
        for (t = t ? 1 : 0; a < 4; a += 2 - t) i["margin" + (n = qe[a])] = i["padding" + n] = e;
        return t && (i.opacity = i.width = e), i
    }

    function q(e, t, n) {
        for (var i, a = (G.tweeners[t] || []).concat(G.tweeners["*"]), s = 0, o = a.length; s < o; s++)
            if (i = a[s].call(n, t, e)) return i
    }

    function B(t, e, n) {
        var i, a, s, o, r, l, d, c = this,
            u = {},
            p = t.style,
            h = t.nodeType && Be(t),
            f = he._data(t, "fxshow");
        for (i in n.queue || (null == (r = he._queueHooks(t, "fx")).unqueued && (r.unqueued = 0, l = r.empty.fire, r.empty.fire = function () {
                r.unqueued || l()
            }), r.unqueued++, c.always(function () {
                c.always(function () {
                    r.unqueued--, he.queue(t, "fx").length || r.empty.fire()
                })
            })), 1 === t.nodeType && ("height" in e || "width" in e) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], "inline" === ("none" === (d = he.css(t, "display")) ? he._data(t, "olddisplay") || M(t.nodeName) : d) && "none" === he.css(t, "float") && (ue.inlineBlockNeedsLayout && "inline" !== M(t.nodeName) ? p.zoom = 1 : p.display = "inline-block")), n.overflow && (p.overflow = "hidden", ue.shrinkWrapBlocks() || c.always(function () {
                p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
            })), e)
            if (a = e[i], It.exec(a)) {
                if (delete e[i], s = s || "toggle" === a, a === (h ? "hide" : "show")) {
                    if ("show" !== a || !f || f[i] === undefined) continue;
                    h = !0
                }
                u[i] = f && f[i] || he.style(t, i)
            } else d = undefined;
        if (he.isEmptyObject(u)) "inline" === ("none" === d ? M(t.nodeName) : d) && (p.display = d);
        else
            for (i in f ? "hidden" in f && (h = f.hidden) : f = he._data(t, "fxshow", {}), s && (f.hidden = !h), h ? he(t).show() : c.done(function () {
                    he(t).hide()
                }), c.done(function () {
                    var e;
                    for (e in he._removeData(t, "fxshow"), u) he.style(t, e, u[e])
                }), u) o = q(h ? f[i] : 0, i, c), i in f || (f[i] = o.start, h && (o.end = o.start, o.start = "width" === i || "height" === i ? 1 : 0))
    }

    function $(e, t) {
        var n, i, a, s, o;
        for (n in e)
            if (a = t[i = he.camelCase(n)], s = e[n], he.isArray(s) && (a = s[1], s = e[n] = s[0]), n !== i && (e[i] = s, delete e[n]), (o = he.cssHooks[i]) && "expand" in o)
                for (n in s = o.expand(s), delete e[i], s) n in e || (e[n] = s[n], t[n] = a);
            else t[i] = a
    }

    function G(s, e, t) {
        var n, o, i = 0,
            a = G.prefilters.length,
            r = he.Deferred().always(function () {
                delete l.elem
            }),
            l = function () {
                if (o) return !1;
                for (var e = Dt || H(), t = Math.max(0, d.startTime + d.duration - e), n = 1 - (t / d.duration || 0), i = 0, a = d.tweens.length; i < a; i++) d.tweens[i].run(n);
                return r.notifyWith(s, [d, n, t]), n < 1 && a ? t : (r.resolveWith(s, [d]), !1)
            },
            d = r.promise({
                elem: s,
                props: he.extend({}, e),
                opts: he.extend(!0, {
                    specialEasing: {},
                    easing: he.easing._default
                }, t),
                originalProperties: e,
                originalOptions: t,
                startTime: Dt || H(),
                duration: t.duration,
                tweens: [],
                createTween: function (e, t) {
                    var n = he.Tween(s, d.opts, e, t, d.opts.specialEasing[e] || d.opts.easing);
                    return d.tweens.push(n), n
                },
                stop: function (e) {
                    var t = 0,
                        n = e ? d.tweens.length : 0;
                    if (o) return this;
                    for (o = !0; t < n; t++) d.tweens[t].run(1);
                    return e ? (r.notifyWith(s, [d, 1, 0]), r.resolveWith(s, [d, e])) : r.rejectWith(s, [d, e]), this
                }
            }),
            c = d.props;
        for ($(c, d.opts.specialEasing); i < a; i++)
            if (n = G.prefilters[i].call(d, s, c, d.opts)) return he.isFunction(n.stop) && (he._queueHooks(d.elem, d.opts.queue).stop = he.proxy(n.stop, n)), n;
        return he.map(c, q, d), he.isFunction(d.opts.start) && d.opts.start.call(s, d), he.fx.timer(he.extend(l, {
            elem: s,
            anim: d,
            queue: d.opts.queue
        })), d.progress(d.opts.progress).done(d.opts.done, d.opts.complete).fail(d.opts.fail).always(d.opts.always)
    }

    function z(e) {
        return he.attr(e, "class") || ""
    }

    function W(s) {
        return function (e, t) {
            "string" != typeof e && (t = e, e = "*");
            var n, i = 0,
                a = e.toLowerCase().match(Me) || [];
            if (he.isFunction(t))
                for (; n = a[i++];) "+" === n.charAt(0) ? (n = n.slice(1) || "*", (s[n] = s[n] || []).unshift(t)) : (s[n] = s[n] || []).push(t)
        }
    }

    function Y(t, a, s, o) {
        function r(e) {
            var i;
            return l[e] = !0, he.each(t[e] || [], function (e, t) {
                var n = t(a, s, o);
                return "string" != typeof n || d || l[n] ? d ? !(i = n) : void 0 : (a.dataTypes.unshift(n), r(n), !1)
            }), i
        }
        var l = {},
            d = t === on;
        return r(a.dataTypes[0]) || !l["*"] && r("*")
    }

    function V(e, t) {
        var n, i, a = he.ajaxSettings.flatOptions || {};
        for (i in t) t[i] !== undefined && ((a[i] ? e : n || (n = {}))[i] = t[i]);
        return n && he.extend(!0, e, n), e
    }

    function K(e, t, n) {
        for (var i, a, s, o, r = e.contents, l = e.dataTypes;
            "*" === l[0];) l.shift(), a === undefined && (a = e.mimeType || t.getResponseHeader("Content-Type"));
        if (a)
            for (o in r)
                if (r[o] && r[o].test(a)) {
                    l.unshift(o);
                    break
                } if (l[0] in n) s = l[0];
        else {
            for (o in n) {
                if (!l[0] || e.converters[o + " " + l[0]]) {
                    s = o;
                    break
                }
                i || (i = o)
            }
            s = s || i
        }
        if (s) return s !== l[0] && l.unshift(s), n[s]
    }

    function U(e, t, n, i) {
        var a, s, o, r, l, d = {},
            c = e.dataTypes.slice();
        if (c[1])
            for (o in e.converters) d[o.toLowerCase()] = e.converters[o];
        for (s = c.shift(); s;)
            if (e.responseFields[s] && (n[e.responseFields[s]] = t), !l && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = s, s = c.shift())
                if ("*" === s) s = l;
                else if ("*" !== l && l !== s) {
            if (!(o = d[l + " " + s] || d["* " + s]))
                for (a in d)
                    if ((r = a.split(" "))[1] === s && (o = d[l + " " + r[0]] || d["* " + r[0]])) {
                        !0 === o ? o = d[a] : !0 !== d[a] && (s = r[0], c.unshift(r[1]));
                        break
                    } if (!0 !== o)
                if (o && e["throws"]) t = o(t);
                else try {
                    t = o(t)
                } catch (u) {
                    return {
                        state: "parsererror",
                        error: o ? u : "No conversion from " + l + " to " + s
                    }
                }
        }
        return {
            state: "success",
            data: t
        }
    }

    function X(e) {
        return e.style && e.style.display || he.css(e, "display")
    }

    function J(e) {
        if (!he.contains(e.ownerDocument || ie, e)) return !0;
        for (; e && 1 === e.nodeType;) {
            if ("none" === X(e) || "hidden" === e.type) return !0;
            e = e.parentNode
        }
        return !1
    }

    function Q(n, e, i, a) {
        var t;
        if (he.isArray(e)) he.each(e, function (e, t) {
            i || un.test(n) ? a(n, t) : Q(n + "[" + ("object" == typeof t && null != t ? e : "") + "]", t, i, a)
        });
        else if (i || "object" !== he.type(e)) a(n, e);
        else
            for (t in e) Q(n + "[" + t + "]", e[t], i, a)
    }

    function Z() {
        try {
            return new w.XMLHttpRequest
        } catch (e) {}
    }

    function ee() {
        try {
            return new w.ActiveXObject("Microsoft.XMLHTTP")
        } catch (e) {}
    }

    function te(e) {
        return he.isWindow(e) ? e : 9 === e.nodeType && (e.defaultView || e.parentWindow)
    }
    var ne = [],
        ie = w.document,
        ae = ne.slice,
        se = ne.concat,
        oe = ne.push,
        re = ne.indexOf,
        le = {},
        de = le.toString,
        ce = le.hasOwnProperty,
        ue = {},
        pe = "1.12.4",
        he = function (e, t) {
            return new he.fn.init(e, t)
        },
        fe = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        me = /^-ms-/,
        ge = /-([\da-z])/gi,
        ve = function (e, t) {
            return t.toUpperCase()
        };
    he.fn = he.prototype = {
        jquery: pe,
        constructor: he,
        selector: "",
        length: 0,
        toArray: function () {
            return ae.call(this)
        },
        get: function (e) {
            return null != e ? e < 0 ? this[e + this.length] : this[e] : ae.call(this)
        },
        pushStack: function (e) {
            var t = he.merge(this.constructor(), e);
            return t.prevObject = this, t.context = this.context, t
        },
        each: function (e) {
            return he.each(this, e)
        },
        map: function (n) {
            return this.pushStack(he.map(this, function (e, t) {
                return n.call(e, t, e)
            }))
        },
        slice: function () {
            return this.pushStack(ae.apply(this, arguments))
        },
        first: function () {
            return this.eq(0)
        },
        last: function () {
            return this.eq(-1)
        },
        eq: function (e) {
            var t = this.length,
                n = +e + (e < 0 ? t : 0);
            return this.pushStack(0 <= n && n < t ? [this[n]] : [])
        },
        end: function () {
            return this.prevObject || this.constructor()
        },
        push: oe,
        sort: ne.sort,
        splice: ne.splice
    }, he.extend = he.fn.extend = function (e) {
        var t, n, i, a, s, o, r = e || {},
            l = 1,
            d = arguments.length,
            c = !1;
        for ("boolean" == typeof r && (c = r, r = arguments[l] || {}, l++), "object" == typeof r || he.isFunction(r) || (r = {}), l === d && (r = this, l--); l < d; l++)
            if (null != (s = arguments[l]))
                for (a in s) t = r[a], r !== (i = s[a]) && (c && i && (he.isPlainObject(i) || (n = he.isArray(i))) ? (n ? (n = !1, o = t && he.isArray(t) ? t : []) : o = t && he.isPlainObject(t) ? t : {}, r[a] = he.extend(c, o, i)) : i !== undefined && (r[a] = i));
        return r
    }, he.extend({
        expando: "jQuery" + (pe + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function (e) {
            throw new Error(e)
        },
        noop: function () {},
        isFunction: function (e) {
            return "function" === he.type(e)
        },
        isArray: Array.isArray || function (e) {
            return "array" === he.type(e)
        },
        isWindow: function (e) {
            return null != e && e == e.window
        },
        isNumeric: function (e) {
            var t = e && e.toString();
            return !he.isArray(e) && 0 <= t - parseFloat(t) + 1
        },
        isEmptyObject: function (e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        isPlainObject: function (e) {
            var t;
            if (!e || "object" !== he.type(e) || e.nodeType || he.isWindow(e)) return !1;
            try {
                if (e.constructor && !ce.call(e, "constructor") && !ce.call(e.constructor.prototype, "isPrototypeOf")) return !1
            } catch (n) {
                return !1
            }
            if (!ue.ownFirst)
                for (t in e) return ce.call(e, t);
            for (t in e);
            return t === undefined || ce.call(e, t)
        },
        type: function (e) {
            return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? le[de.call(e)] || "object" : typeof e
        },
        globalEval: function (e) {
            e && he.trim(e) && (w.execScript || function (e) {
                w.eval.call(w, e)
            })(e)
        },
        camelCase: function (e) {
            return e.replace(me, "ms-").replace(ge, ve)
        },
        nodeName: function (e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        },
        each: function (e, t) {
            var n, i = 0;
            if (r(e))
                for (n = e.length; i < n && !1 !== t.call(e[i], i, e[i]); i++);
            else
                for (i in e)
                    if (!1 === t.call(e[i], i, e[i])) break;
            return e
        },
        trim: function (e) {
            return null == e ? "" : (e + "").replace(fe, "")
        },
        makeArray: function (e, t) {
            var n = t || [];
            return null != e && (r(Object(e)) ? he.merge(n, "string" == typeof e ? [e] : e) : oe.call(n, e)), n
        },
        inArray: function (e, t, n) {
            var i;
            if (t) {
                if (re) return re.call(t, e, n);
                for (i = t.length, n = n ? n < 0 ? Math.max(0, i + n) : n : 0; n < i; n++)
                    if (n in t && t[n] === e) return n
            }
            return -1
        },
        merge: function (e, t) {
            for (var n = +t.length, i = 0, a = e.length; i < n;) e[a++] = t[i++];
            if (n != n)
                for (; t[i] !== undefined;) e[a++] = t[i++];
            return e.length = a, e
        },
        grep: function (e, t, n) {
            for (var i = [], a = 0, s = e.length, o = !n; a < s; a++) !t(e[a], a) !== o && i.push(e[a]);
            return i
        },
        map: function (e, t, n) {
            var i, a, s = 0,
                o = [];
            if (r(e))
                for (i = e.length; s < i; s++) null != (a = t(e[s], s, n)) && o.push(a);
            else
                for (s in e) null != (a = t(e[s], s, n)) && o.push(a);
            return se.apply([], o)
        },
        guid: 1,
        proxy: function (e, t) {
            var n, i, a;
            return "string" == typeof t && (a = e[t], t = e, e = a), he.isFunction(e) ? (n = ae.call(arguments, 2), (i = function () {
                return e.apply(t || this, n.concat(ae.call(arguments)))
            }).guid = e.guid = e.guid || he.guid++, i) : undefined
        },
        now: function () {
            return +new Date
        },
        support: ue
    }), "function" == typeof Symbol && (he.fn[Symbol.iterator] = ne[Symbol.iterator]), he.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) {
        le["[object " + t + "]"] = t.toLowerCase()
    });
    var be = function (n) {
        function x(e, t, n, i) {
            var a, s, o, r, l, d, c, u, p = t && t.ownerDocument,
                h = t ? t.nodeType : 9;
            if (n = n || [], "string" != typeof e || !e || 1 !== h && 9 !== h && 11 !== h) return n;
            if (!i && ((t ? t.ownerDocument || t : q) !== R && A(t), t = t || R, I)) {
                if (11 !== h && (d = ve.exec(e)))
                    if (a = d[1]) {
                        if (9 === h) {
                            if (!(o = t.getElementById(a))) return n;
                            if (o.id === a) return n.push(o), n
                        } else if (p && (o = p.getElementById(a)) && H(t, o) && o.id === a) return n.push(o), n
                    } else {
                        if (d[2]) return Q.apply(n, t.getElementsByTagName(e)), n;
                        if ((a = d[3]) && v.getElementsByClassName && t.getElementsByClassName) return Q.apply(n, t.getElementsByClassName(a)), n
                    } if (v.qsa && !W[e + " "] && (!L || !L.test(e))) {
                    if (1 !== h) p = t, u = e;
                    else if ("object" !== t.nodeName.toLowerCase()) {
                        for ((r = t.getAttribute("id")) ? r = r.replace(ye, "\\$&") : t.setAttribute("id", r = P), s = (c = T(e)).length, l = pe.test(r) ? "#" + r : "[id='" + r + "']"; s--;) c[s] = l + " " + g(c[s]);
                        u = c.join(","), p = be.test(e) && m(t.parentNode) || t
                    }
                    if (u) try {
                        return Q.apply(n, p.querySelectorAll(u)), n
                    } catch (f) {} finally {
                        r === P && t.removeAttribute("id")
                    }
                }
            }
            return D(e.replace(re, "$1"), t, n, i)
        }

        function e() {
            function n(e, t) {
                return i.push(e + " ") > k.cacheLength && delete n[i.shift()], n[e + " "] = t
            }
            var i = [];
            return n
        }

        function l(e) {
            return e[P] = !0, e
        }

        function a(e) {
            var t = R.createElement("div");
            try {
                return !!e(t)
            } catch (n) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t), t = null
            }
        }

        function t(e, t) {
            for (var n = e.split("|"), i = n.length; i--;) k.attrHandle[n[i]] = t
        }

        function d(e, t) {
            var n = t && e,
                i = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || V) - (~e.sourceIndex || V);
            if (i) return i;
            if (n)
                for (; n = n.nextSibling;)
                    if (n === t) return -1;
            return e ? 1 : -1
        }

        function i(t) {
            return function (e) {
                return "input" === e.nodeName.toLowerCase() && e.type === t
            }
        }

        function s(n) {
            return function (e) {
                var t = e.nodeName.toLowerCase();
                return ("input" === t || "button" === t) && e.type === n
            }
        }

        function o(o) {
            return l(function (s) {
                return s = +s, l(function (e, t) {
                    for (var n, i = o([], e.length, s), a = i.length; a--;) e[n = i[a]] && (e[n] = !(t[n] = e[n]))
                })
            })
        }

        function m(e) {
            return e && "undefined" != typeof e.getElementsByTagName && e
        }

        function r() {}

        function g(e) {
            for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t].value;
            return i
        }

        function u(r, e, t) {
            var l = e.dir,
                d = t && "parentNode" === l,
                c = $++;
            return e.first ? function (e, t, n) {
                for (; e = e[l];)
                    if (1 === e.nodeType || d) return r(e, t, n)
            } : function (e, t, n) {
                var i, a, s, o = [B, c];
                if (n) {
                    for (; e = e[l];)
                        if ((1 === e.nodeType || d) && r(e, t, n)) return !0
                } else
                    for (; e = e[l];)
                        if (1 === e.nodeType || d) {
                            if ((i = (a = (s = e[P] || (e[P] = {}))[e.uniqueID] || (s[e.uniqueID] = {}))[l]) && i[0] === B && i[1] === c) return o[2] = i[2];
                            if ((a[l] = o)[2] = r(e, t, n)) return !0
                        }
            }
        }

        function p(a) {
            return 1 < a.length ? function (e, t, n) {
                for (var i = a.length; i--;)
                    if (!a[i](e, t, n)) return !1;
                return !0
            } : a[0]
        }

        function b(e, t, n) {
            for (var i = 0, a = t.length; i < a; i++) x(e, t[i], n);
            return n
        }

        function _(e, t, n, i, a) {
            for (var s, o = [], r = 0, l = e.length, d = null != t; r < l; r++)(s = e[r]) && (n && !n(s, i, a) || (o.push(s), d && t.push(r)));
            return o
        }

        function y(h, f, m, g, v, e) {
            return g && !g[P] && (g = y(g)), v && !v[P] && (v = y(v, e)), l(function (e, t, n, i) {
                var a, s, o, r = [],
                    l = [],
                    d = t.length,
                    c = e || b(f || "*", n.nodeType ? [n] : n, []),
                    u = !h || !e && f ? c : _(c, r, h, n, i),
                    p = m ? v || (e ? h : d || g) ? [] : t : u;
                if (m && m(u, p, n, i), g)
                    for (a = _(p, l), g(a, [], n, i), s = a.length; s--;)(o = a[s]) && (p[l[s]] = !(u[l[s]] = o));
                if (e) {
                    if (v || h) {
                        if (v) {
                            for (a = [], s = p.length; s--;)(o = p[s]) && a.push(u[s] = o);
                            v(null, p = [], a, i)
                        }
                        for (s = p.length; s--;)(o = p[s]) && -1 < (a = v ? ee(e, o) : r[s]) && (e[a] = !(t[a] = o))
                    }
                } else p = _(p === t ? p.splice(d, p.length) : p), v ? v(null, t, p, i) : Q.apply(t, p)
            })
        }

        function h(e) {
            for (var a, t, n, i = e.length, s = k.relative[e[0].type], o = s || k.relative[" "], r = s ? 1 : 0, l = u(function (e) {
                    return e === a
                }, o, !0), d = u(function (e) {
                    return -1 < ee(a, e)
                }, o, !0), c = [function (e, t, n) {
                    var i = !s && (n || t !== E) || ((a = t).nodeType ? l(e, t, n) : d(e, t, n));
                    return a = null, i
                }]; r < i; r++)
                if (t = k.relative[e[r].type]) c = [u(p(c), t)];
                else {
                    if ((t = k.filter[e[r].type].apply(null, e[r].matches))[P]) {
                        for (n = ++r; n < i && !k.relative[e[n].type]; n++);
                        return y(1 < r && p(c), 1 < r && g(e.slice(0, r - 1).concat({
                            value: " " === e[r - 2].type ? "*" : ""
                        })).replace(re, "$1"), t, r < n && h(e.slice(r, n)), n < i && h(e = e.slice(n)), n < i && g(e))
                    }
                    c.push(t)
                } return p(c)
        }

        function c(g, v) {
            var b = 0 < v.length,
                y = 0 < g.length,
                e = function (e, t, n, i, a) {
                    var s, o, r, l = 0,
                        d = "0",
                        c = e && [],
                        u = [],
                        p = E,
                        h = e || y && k.find.TAG("*", a),
                        f = B += null == p ? 1 : Math.random() || .1,
                        m = h.length;
                    for (a && (E = t === R || t || a); d !== m && null != (s = h[d]); d++) {
                        if (y && s) {
                            for (o = 0, t || s.ownerDocument === R || (A(s), n = !I); r = g[o++];)
                                if (r(s, t || R, n)) {
                                    i.push(s);
                                    break
                                } a && (B = f)
                        }
                        b && ((s = !r && s) && l--, e && c.push(s))
                    }
                    if (l += d, b && d !== l) {
                        for (o = 0; r = v[o++];) r(c, u, t, n);
                        if (e) {
                            if (0 < l)
                                for (; d--;) c[d] || u[d] || (u[d] = X.call(i));
                            u = _(u)
                        }
                        Q.apply(i, u), a && !e && 0 < u.length && 1 < l + v.length && x.uniqueSort(i)
                    }
                    return a && (B = f, E = p), c
                };
            return b ? l(e) : e
        }
        var f, v, k, w, C, T, S, D, E, N, M, A, R, j, I, L, F, O, H, P = "sizzle" + 1 * new Date,
            q = n.document,
            B = 0,
            $ = 0,
            G = e(),
            z = e(),
            W = e(),
            Y = function (e, t) {
                return e === t && (M = !0), 0
            },
            V = 1 << 31,
            K = {}.hasOwnProperty,
            U = [],
            X = U.pop,
            J = U.push,
            Q = U.push,
            Z = U.slice,
            ee = function (e, t) {
                for (var n = 0, i = e.length; n < i; n++)
                    if (e[n] === t) return n;
                return -1
            },
            te = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            ne = "[\\x20\\t\\r\\n\\f]",
            ie = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
            ae = "\\[" + ne + "*(" + ie + ")(?:" + ne + "*([*^$|!~]?=)" + ne + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + ie + "))|)" + ne + "*\\]",
            se = ":(" + ie + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + ae + ")*)|.*)\\)|)",
            oe = new RegExp(ne + "+", "g"),
            re = new RegExp("^" + ne + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ne + "+$", "g"),
            le = new RegExp("^" + ne + "*," + ne + "*"),
            de = new RegExp("^" + ne + "*([>+~]|" + ne + ")" + ne + "*"),
            ce = new RegExp("=" + ne + "*([^\\]'\"]*?)" + ne + "*\\]", "g"),
            ue = new RegExp(se),
            pe = new RegExp("^" + ie + "$"),
            he = {
                ID: new RegExp("^#(" + ie + ")"),
                CLASS: new RegExp("^\\.(" + ie + ")"),
                TAG: new RegExp("^(" + ie + "|[*])"),
                ATTR: new RegExp("^" + ae),
                PSEUDO: new RegExp("^" + se),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ne + "*(even|odd|(([+-]|)(\\d*)n|)" + ne + "*(?:([+-]|)" + ne + "*(\\d+)|))" + ne + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + te + ")$", "i"),
                needsContext: new RegExp("^" + ne + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ne + "*((?:-\\d)?\\d*)" + ne + "*\\)|)(?=[^-]|$)", "i")
            },
            fe = /^(?:input|select|textarea|button)$/i,
            me = /^h\d$/i,
            ge = /^[^{]+\{\s*\[native \w/,
            ve = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            be = /[+~]/,
            ye = /'|\\/g,
            xe = new RegExp("\\\\([\\da-f]{1,6}" + ne + "?|(" + ne + ")|.)", "ig"),
            _e = function (e, t, n) {
                var i = "0x" + t - 65536;
                return i != i || n ? t : i < 0 ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
            },
            ke = function () {
                A()
            };
        try {
            Q.apply(U = Z.call(q.childNodes), q.childNodes), U[q.childNodes.length].nodeType
        } catch (we) {
            Q = {
                apply: U.length ? function (e, t) {
                    J.apply(e, Z.call(t))
                } : function (e, t) {
                    for (var n = e.length, i = 0; e[n++] = t[i++];);
                    e.length = n - 1
                }
            }
        }
        for (f in v = x.support = {}, C = x.isXML = function (e) {
                var t = e && (e.ownerDocument || e).documentElement;
                return !!t && "HTML" !== t.nodeName
            }, A = x.setDocument = function (e) {
                var t, n, i = e ? e.ownerDocument || e : q;
                return i !== R && 9 === i.nodeType && i.documentElement && (j = (R = i).documentElement, I = !C(R), (n = R.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", ke, !1) : n.attachEvent && n.attachEvent("onunload", ke)), v.attributes = a(function (e) {
                    return e.className = "i", !e.getAttribute("className")
                }), v.getElementsByTagName = a(function (e) {
                    return e.appendChild(R.createComment("")), !e.getElementsByTagName("*").length
                }), v.getElementsByClassName = ge.test(R.getElementsByClassName), v.getById = a(function (e) {
                    return j.appendChild(e).id = P, !R.getElementsByName || !R.getElementsByName(P).length
                }), v.getById ? (k.find.ID = function (e, t) {
                    if ("undefined" != typeof t.getElementById && I) {
                        var n = t.getElementById(e);
                        return n ? [n] : []
                    }
                }, k.filter.ID = function (e) {
                    var t = e.replace(xe, _e);
                    return function (e) {
                        return e.getAttribute("id") === t
                    }
                }) : (delete k.find.ID, k.filter.ID = function (e) {
                    var n = e.replace(xe, _e);
                    return function (e) {
                        var t = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
                        return t && t.value === n
                    }
                }), k.find.TAG = v.getElementsByTagName ? function (e, t) {
                    return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : v.qsa ? t.querySelectorAll(e) : void 0
                } : function (e, t) {
                    var n, i = [],
                        a = 0,
                        s = t.getElementsByTagName(e);
                    if ("*" !== e) return s;
                    for (; n = s[a++];) 1 === n.nodeType && i.push(n);
                    return i
                }, k.find.CLASS = v.getElementsByClassName && function (e, t) {
                    if ("undefined" != typeof t.getElementsByClassName && I) return t.getElementsByClassName(e)
                }, F = [], L = [], (v.qsa = ge.test(R.querySelectorAll)) && (a(function (e) {
                    j.appendChild(e).innerHTML = "<a id='" + P + "'></a><select id='" + P + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && L.push("[*^$]=" + ne + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || L.push("\\[" + ne + "*(?:value|" + te + ")"), e.querySelectorAll("[id~=" + P + "-]").length || L.push("~="), e.querySelectorAll(":checked").length || L.push(":checked"), e.querySelectorAll("a#" + P + "+*").length || L.push(".#.+[+~]")
                }), a(function (e) {
                    var t = R.createElement("input");
                    t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && L.push("name" + ne + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || L.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), L.push(",.*:")
                })), (v.matchesSelector = ge.test(O = j.matches || j.webkitMatchesSelector || j.mozMatchesSelector || j.oMatchesSelector || j.msMatchesSelector)) && a(function (e) {
                    v.disconnectedMatch = O.call(e, "div"), O.call(e, "[s!='']:x"), F.push("!=", se)
                }), L = L.length && new RegExp(L.join("|")), F = F.length && new RegExp(F.join("|")), t = ge.test(j.compareDocumentPosition), H = t || ge.test(j.contains) ? function (e, t) {
                    var n = 9 === e.nodeType ? e.documentElement : e,
                        i = t && t.parentNode;
                    return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
                } : function (e, t) {
                    if (t)
                        for (; t = t.parentNode;)
                            if (t === e) return !0;
                    return !1
                }, Y = t ? function (e, t) {
                    if (e === t) return M = !0, 0;
                    var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                    return n || (1 & (n = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !v.sortDetached && t.compareDocumentPosition(e) === n ? e === R || e.ownerDocument === q && H(q, e) ? -1 : t === R || t.ownerDocument === q && H(q, t) ? 1 : N ? ee(N, e) - ee(N, t) : 0 : 4 & n ? -1 : 1)
                } : function (e, t) {
                    if (e === t) return M = !0, 0;
                    var n, i = 0,
                        a = e.parentNode,
                        s = t.parentNode,
                        o = [e],
                        r = [t];
                    if (!a || !s) return e === R ? -1 : t === R ? 1 : a ? -1 : s ? 1 : N ? ee(N, e) - ee(N, t) : 0;
                    if (a === s) return d(e, t);
                    for (n = e; n = n.parentNode;) o.unshift(n);
                    for (n = t; n = n.parentNode;) r.unshift(n);
                    for (; o[i] === r[i];) i++;
                    return i ? d(o[i], r[i]) : o[i] === q ? -1 : r[i] === q ? 1 : 0
                }), R
            }, x.matches = function (e, t) {
                return x(e, null, null, t)
            }, x.matchesSelector = function (e, t) {
                if ((e.ownerDocument || e) !== R && A(e), t = t.replace(ce, "='$1']"), v.matchesSelector && I && !W[t + " "] && (!F || !F.test(t)) && (!L || !L.test(t))) try {
                    var n = O.call(e, t);
                    if (n || v.disconnectedMatch || e.document && 11 !== e.document.nodeType) return n
                } catch (we) {}
                return 0 < x(t, R, null, [e]).length
            }, x.contains = function (e, t) {
                return (e.ownerDocument || e) !== R && A(e), H(e, t)
            }, x.attr = function (e, t) {
                (e.ownerDocument || e) !== R && A(e);
                var n = k.attrHandle[t.toLowerCase()],
                    i = n && K.call(k.attrHandle, t.toLowerCase()) ? n(e, t, !I) : undefined;
                return i !== undefined ? i : v.attributes || !I ? e.getAttribute(t) : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
            }, x.error = function (e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, x.uniqueSort = function (e) {
                var t, n = [],
                    i = 0,
                    a = 0;
                if (M = !v.detectDuplicates, N = !v.sortStable && e.slice(0), e.sort(Y), M) {
                    for (; t = e[a++];) t === e[a] && (i = n.push(a));
                    for (; i--;) e.splice(n[i], 1)
                }
                return N = null, e
            }, w = x.getText = function (e) {
                var t, n = "",
                    i = 0,
                    a = e.nodeType;
                if (a) {
                    if (1 === a || 9 === a || 11 === a) {
                        if ("string" == typeof e.textContent) return e.textContent;
                        for (e = e.firstChild; e; e = e.nextSibling) n += w(e)
                    } else if (3 === a || 4 === a) return e.nodeValue
                } else
                    for (; t = e[i++];) n += w(t);
                return n
            }, (k = x.selectors = {
                cacheLength: 50,
                createPseudo: l,
                match: he,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function (e) {
                        return e[1] = e[1].replace(xe, _e), e[3] = (e[3] || e[4] || e[5] || "").replace(xe, _e), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function (e) {
                        return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || x.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && x.error(e[0]), e
                    },
                    PSEUDO: function (e) {
                        var t, n = !e[6] && e[2];
                        return he.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && ue.test(n) && (t = T(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function (e) {
                        var t = e.replace(xe, _e).toLowerCase();
                        return "*" === e ? function () {
                            return !0
                        } : function (e) {
                            return e.nodeName && e.nodeName.toLowerCase() === t
                        }
                    },
                    CLASS: function (e) {
                        var t = G[e + " "];
                        return t || (t = new RegExp("(^|" + ne + ")" + e + "(" + ne + "|$)")) && G(e, function (e) {
                            return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "")
                        })
                    },
                    ATTR: function (n, i, a) {
                        return function (e) {
                            var t = x.attr(e, n);
                            return null == t ? "!=" === i : !i || (t += "", "=" === i ? t === a : "!=" === i ? t !== a : "^=" === i ? a && 0 === t.indexOf(a) : "*=" === i ? a && -1 < t.indexOf(a) : "$=" === i ? a && t.slice(-a.length) === a : "~=" === i ? -1 < (" " + t.replace(oe, " ") + " ").indexOf(a) : "|=" === i && (t === a || t.slice(0, a.length + 1) === a + "-"))
                        }
                    },
                    CHILD: function (f, e, t, m, g) {
                        var v = "nth" !== f.slice(0, 3),
                            b = "last" !== f.slice(-4),
                            y = "of-type" === e;
                        return 1 === m && 0 === g ? function (e) {
                            return !!e.parentNode
                        } : function (e, t, n) {
                            var i, a, s, o, r, l, d = v !== b ? "nextSibling" : "previousSibling",
                                c = e.parentNode,
                                u = y && e.nodeName.toLowerCase(),
                                p = !n && !y,
                                h = !1;
                            if (c) {
                                if (v) {
                                    for (; d;) {
                                        for (o = e; o = o[d];)
                                            if (y ? o.nodeName.toLowerCase() === u : 1 === o.nodeType) return !1;
                                        l = d = "only" === f && !l && "nextSibling"
                                    }
                                    return !0
                                }
                                if (l = [b ? c.firstChild : c.lastChild], b && p) {
                                    for (h = (r = (i = (a = (s = (o = c)[P] || (o[P] = {}))[o.uniqueID] || (s[o.uniqueID] = {}))[f] || [])[0] === B && i[1]) && i[2], o = r && c.childNodes[r]; o = ++r && o && o[d] || (h = r = 0) || l.pop();)
                                        if (1 === o.nodeType && ++h && o === e) {
                                            a[f] = [B, r, h];
                                            break
                                        }
                                } else if (p && (h = r = (i = (a = (s = (o = e)[P] || (o[P] = {}))[o.uniqueID] || (s[o.uniqueID] = {}))[f] || [])[0] === B && i[1]), !1 === h)
                                    for (;
                                        (o = ++r && o && o[d] || (h = r = 0) || l.pop()) && ((y ? o.nodeName.toLowerCase() !== u : 1 !== o.nodeType) || !++h || (p && ((a = (s = o[P] || (o[P] = {}))[o.uniqueID] || (s[o.uniqueID] = {}))[f] = [B, h]), o !== e)););
                                return (h -= g) === m || h % m == 0 && 0 <= h / m
                            }
                        }
                    },
                    PSEUDO: function (e, s) {
                        var t, o = k.pseudos[e] || k.setFilters[e.toLowerCase()] || x.error("unsupported pseudo: " + e);
                        return o[P] ? o(s) : 1 < o.length ? (t = [e, e, "", s], k.setFilters.hasOwnProperty(e.toLowerCase()) ? l(function (e, t) {
                            for (var n, i = o(e, s), a = i.length; a--;) e[n = ee(e, i[a])] = !(t[n] = i[a])
                        }) : function (e) {
                            return o(e, 0, t)
                        }) : o
                    }
                },
                pseudos: {
                    not: l(function (e) {
                        var i = [],
                            a = [],
                            r = S(e.replace(re, "$1"));
                        return r[P] ? l(function (e, t, n, i) {
                            for (var a, s = r(e, null, i, []), o = e.length; o--;)(a = s[o]) && (e[o] = !(t[o] = a))
                        }) : function (e, t, n) {
                            return i[0] = e, r(i, null, n, a), i[0] = null, !a.pop()
                        }
                    }),
                    has: l(function (t) {
                        return function (e) {
                            return 0 < x(t, e).length
                        }
                    }),
                    contains: l(function (t) {
                        return t = t.replace(xe, _e),
                            function (e) {
                                return -1 < (e.textContent || e.innerText || w(e)).indexOf(t)
                            }
                    }),
                    lang: l(function (n) {
                        return pe.test(n || "") || x.error("unsupported lang: " + n), n = n.replace(xe, _e).toLowerCase(),
                            function (e) {
                                var t;
                                do {
                                    if (t = I ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang")) return (t = t.toLowerCase()) === n || 0 === t.indexOf(n + "-")
                                } while ((e = e.parentNode) && 1 === e.nodeType);
                                return !1
                            }
                    }),
                    target: function (e) {
                        var t = n.location && n.location.hash;
                        return t && t.slice(1) === e.id
                    },
                    root: function (e) {
                        return e === j
                    },
                    focus: function (e) {
                        return e === R.activeElement && (!R.hasFocus || R.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: function (e) {
                        return !1 === e.disabled
                    },
                    disabled: function (e) {
                        return !0 === e.disabled
                    },
                    checked: function (e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && !!e.checked || "option" === t && !!e.selected
                    },
                    selected: function (e) {
                        return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                    },
                    empty: function (e) {
                        for (e = e.firstChild; e; e = e.nextSibling)
                            if (e.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function (e) {
                        return !k.pseudos.empty(e)
                    },
                    header: function (e) {
                        return me.test(e.nodeName)
                    },
                    input: function (e) {
                        return fe.test(e.nodeName)
                    },
                    button: function (e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && "button" === e.type || "button" === t
                    },
                    text: function (e) {
                        var t;
                        return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                    },
                    first: o(function () {
                        return [0]
                    }),
                    last: o(function (e, t) {
                        return [t - 1]
                    }),
                    eq: o(function (e, t, n) {
                        return [n < 0 ? n + t : n]
                    }),
                    even: o(function (e, t) {
                        for (var n = 0; n < t; n += 2) e.push(n);
                        return e
                    }),
                    odd: o(function (e, t) {
                        for (var n = 1; n < t; n += 2) e.push(n);
                        return e
                    }),
                    lt: o(function (e, t, n) {
                        for (var i = n < 0 ? n + t : n; 0 <= --i;) e.push(i);
                        return e
                    }),
                    gt: o(function (e, t, n) {
                        for (var i = n < 0 ? n + t : n; ++i < t;) e.push(i);
                        return e
                    })
                }
            }).pseudos.nth = k.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) k.pseudos[f] = i(f);
        for (f in {
                submit: !0,
                reset: !0
            }) k.pseudos[f] = s(f);
        return r.prototype = k.filters = k.pseudos, k.setFilters = new r, T = x.tokenize = function (e, t) {
            var n, i, a, s, o, r, l, d = z[e + " "];
            if (d) return t ? 0 : d.slice(0);
            for (o = e, r = [], l = k.preFilter; o;) {
                for (s in n && !(i = le.exec(o)) || (i && (o = o.slice(i[0].length) || o), r.push(a = [])), n = !1, (i = de.exec(o)) && (n = i.shift(), a.push({
                        value: n,
                        type: i[0].replace(re, " ")
                    }), o = o.slice(n.length)), k.filter) !(i = he[s].exec(o)) || l[s] && !(i = l[s](i)) || (n = i.shift(), a.push({
                    value: n,
                    type: s,
                    matches: i
                }), o = o.slice(n.length));
                if (!n) break
            }
            return t ? o.length : o ? x.error(e) : z(e, r).slice(0)
        }, S = x.compile = function (e, t) {
            var n, i = [],
                a = [],
                s = W[e + " "];
            if (!s) {
                for (t || (t = T(e)), n = t.length; n--;)(s = h(t[n]))[P] ? i.push(s) : a.push(s);
                (s = W(e, c(a, i))).selector = e
            }
            return s
        }, D = x.select = function (e, t, n, i) {
            var a, s, o, r, l, d = "function" == typeof e && e,
                c = !i && T(e = d.selector || e);
            if (n = n || [], 1 === c.length) {
                if (2 < (s = c[0] = c[0].slice(0)).length && "ID" === (o = s[0]).type && v.getById && 9 === t.nodeType && I && k.relative[s[1].type]) {
                    if (!(t = (k.find.ID(o.matches[0].replace(xe, _e), t) || [])[0])) return n;
                    d && (t = t.parentNode), e = e.slice(s.shift().value.length)
                }
                for (a = he.needsContext.test(e) ? 0 : s.length; a-- && (o = s[a], !k.relative[r = o.type]);)
                    if ((l = k.find[r]) && (i = l(o.matches[0].replace(xe, _e), be.test(s[0].type) && m(t.parentNode) || t))) {
                        if (s.splice(a, 1), !(e = i.length && g(s))) return Q.apply(n, i), n;
                        break
                    }
            }
            return (d || S(e, c))(i, t, !I, n, !t || be.test(e) && m(t.parentNode) || t), n
        }, v.sortStable = P.split("").sort(Y).join("") === P, v.detectDuplicates = !!M, A(), v.sortDetached = a(function (e) {
            return 1 & e.compareDocumentPosition(R.createElement("div"))
        }), a(function (e) {
            return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
        }) || t("type|href|height|width", function (e, t, n) {
            if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }), v.attributes && a(function (e) {
            return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
        }) || t("value", function (e, t, n) {
            if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue
        }), a(function (e) {
            return null == e.getAttribute("disabled")
        }) || t(te, function (e, t, n) {
            var i;
            if (!n) return !0 === e[t] ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
        }), x
    }(w);
    he.find = be, he.expr = be.selectors, he.expr[":"] = he.expr.pseudos, he.uniqueSort = he.unique = be.uniqueSort, he.text = be.getText, he.isXMLDoc = be.isXML, he.contains = be.contains;
    var ye = function (e, t, n) {
            for (var i = [], a = n !== undefined;
                (e = e[t]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (a && he(e).is(n)) break;
                    i.push(e)
                } return i
        },
        xe = function (e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        _e = he.expr.match.needsContext,
        ke = /^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,
        we = /^.[^:#\[\.,]*$/;
    he.filter = function (e, t, n) {
        var i = t[0];
        return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? he.find.matchesSelector(i, e) ? [i] : [] : he.find.matches(e, he.grep(t, function (e) {
            return 1 === e.nodeType
        }))
    }, he.fn.extend({
        find: function (e) {
            var t, n = [],
                i = this,
                a = i.length;
            if ("string" != typeof e) return this.pushStack(he(e).filter(function () {
                for (t = 0; t < a; t++)
                    if (he.contains(i[t], this)) return !0
            }));
            for (t = 0; t < a; t++) he.find(e, i[t], n);
            return (n = this.pushStack(1 < a ? he.unique(n) : n)).selector = this.selector ? this.selector + " " + e : e, n
        },
        filter: function (e) {
            return this.pushStack(t(this, e || [], !1))
        },
        not: function (e) {
            return this.pushStack(t(this, e || [], !0))
        },
        is: function (e) {
            return !!t(this, "string" == typeof e && _e.test(e) ? he(e) : e || [], !1).length
        }
    });
    var Ce, Te = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/;
    (he.fn.init = function (e, t, n) {
        var i, a;
        if (!e) return this;
        if (n = n || Ce, "string" != typeof e) return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : he.isFunction(e) ? "undefined" != typeof n.ready ? n.ready(e) : e(he) : (e.selector !== undefined && (this.selector = e.selector, this.context = e.context), he.makeArray(e, this));
        if (!(i = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && 3 <= e.length ? [null, e, null] : Te.exec(e)) || !i[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
        if (i[1]) {
            if (t = t instanceof he ? t[0] : t, he.merge(this, he.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : ie, !0)), ke.test(i[1]) && he.isPlainObject(t))
                for (i in t) he.isFunction(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
            return this
        }
        if ((a = ie.getElementById(i[2])) && a.parentNode) {
            if (a.id !== i[2]) return Ce.find(e);
            this.length = 1, this[0] = a
        }
        return this.context = ie, this.selector = e, this
    }).prototype = he.fn, Ce = he(ie);
    var Se = /^(?:parents|prev(?:Until|All))/,
        De = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    he.fn.extend({
        has: function (e) {
            var t, n = he(e, this),
                i = n.length;
            return this.filter(function () {
                for (t = 0; t < i; t++)
                    if (he.contains(this, n[t])) return !0
            })
        },
        closest: function (e, t) {
            for (var n, i = 0, a = this.length, s = [], o = _e.test(e) || "string" != typeof e ? he(e, t || this.context) : 0; i < a; i++)
                for (n = this[i]; n && n !== t; n = n.parentNode)
                    if (n.nodeType < 11 && (o ? -1 < o.index(n) : 1 === n.nodeType && he.find.matchesSelector(n, e))) {
                        s.push(n);
                        break
                    } return this.pushStack(1 < s.length ? he.uniqueSort(s) : s)
        },
        index: function (e) {
            return e ? "string" == typeof e ? he.inArray(this[0], he(e)) : he.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function (e, t) {
            return this.pushStack(he.uniqueSort(he.merge(this.get(), he(e, t))))
        },
        addBack: function (e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), he.each({
        parent: function (e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function (e) {
            return ye(e, "parentNode")
        },
        parentsUntil: function (e, t, n) {
            return ye(e, "parentNode", n)
        },
        next: function (e) {
            return n(e, "nextSibling")
        },
        prev: function (e) {
            return n(e, "previousSibling")
        },
        nextAll: function (e) {
            return ye(e, "nextSibling")
        },
        prevAll: function (e) {
            return ye(e, "previousSibling")
        },
        nextUntil: function (e, t, n) {
            return ye(e, "nextSibling", n)
        },
        prevUntil: function (e, t, n) {
            return ye(e, "previousSibling", n)
        },
        siblings: function (e) {
            return xe((e.parentNode || {}).firstChild, e)
        },
        children: function (e) {
            return xe(e.firstChild)
        },
        contents: function (e) {
            return he.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : he.merge([], e.childNodes)
        }
    }, function (i, a) {
        he.fn[i] = function (e, t) {
            var n = he.map(this, a, e);
            return "Until" !== i.slice(-5) && (t = e), t && "string" == typeof t && (n = he.filter(t, n)), 1 < this.length && (De[i] || (n = he.uniqueSort(n)), Se.test(i) && (n = n.reverse())), this.pushStack(n)
        }
    });
    var Ee, Ne, Me = /\S+/g;
    for (Ne in he.Callbacks = function (i) {
            i = "string" == typeof i ? c(i) : he.extend({}, i);
            var a, e, t, n, s = [],
                o = [],
                r = -1,
                l = function () {
                    for (n = i.once, t = a = !0; o.length; r = -1)
                        for (e = o.shift(); ++r < s.length;) !1 === s[r].apply(e[0], e[1]) && i.stopOnFalse && (r = s.length, e = !1);
                    i.memory || (e = !1), a = !1, n && (s = e ? [] : "")
                },
                d = {
                    add: function () {
                        return s && (e && !a && (r = s.length - 1, o.push(e)), function n(e) {
                            he.each(e, function (e, t) {
                                he.isFunction(t) ? i.unique && d.has(t) || s.push(t) : t && t.length && "string" !== he.type(t) && n(t)
                            })
                        }(arguments), e && !a && l()), this
                    },
                    remove: function () {
                        return he.each(arguments, function (e, t) {
                            for (var n; - 1 < (n = he.inArray(t, s, n));) s.splice(n, 1), n <= r && r--
                        }), this
                    },
                    has: function (e) {
                        return e ? -1 < he.inArray(e, s) : 0 < s.length
                    },
                    empty: function () {
                        return s && (s = []), this
                    },
                    disable: function () {
                        return n = o = [], s = e = "", this
                    },
                    disabled: function () {
                        return !s
                    },
                    lock: function () {
                        return n = !0, e || d.disable(), this
                    },
                    locked: function () {
                        return !!n
                    },
                    fireWith: function (e, t) {
                        return n || (t = [e, (t = t || []).slice ? t.slice() : t], o.push(t), a || l()), this
                    },
                    fire: function () {
                        return d.fireWith(this, arguments), this
                    },
                    fired: function () {
                        return !!t
                    }
                };
            return d
        }, he.extend({
            Deferred: function (e) {
                var s = [["resolve", "done", he.Callbacks("once memory"), "resolved"], ["reject", "fail", he.Callbacks("once memory"), "rejected"], ["notify", "progress", he.Callbacks("memory")]],
                    a = "pending",
                    o = {
                        state: function () {
                            return a
                        },
                        always: function () {
                            return r.done(arguments).fail(arguments), this
                        },
                        then: function () {
                            var a = arguments;
                            return he.Deferred(function (i) {
                                he.each(s, function (e, t) {
                                    var n = he.isFunction(a[e]) && a[e];
                                    r[t[1]](function () {
                                        var e = n && n.apply(this, arguments);
                                        e && he.isFunction(e.promise) ? e.promise().progress(i.notify).done(i.resolve).fail(i.reject) : i[t[0] + "With"](this === o ? i.promise() : this, n ? [e] : arguments)
                                    })
                                }), a = null
                            }).promise()
                        },
                        promise: function (e) {
                            return null != e ? he.extend(e, o) : o
                        }
                    },
                    r = {};
                return o.pipe = o.then, he.each(s, function (e, t) {
                    var n = t[2],
                        i = t[3];
                    o[t[1]] = n.add, i && n.add(function () {
                        a = i
                    }, s[1 ^ e][2].disable, s[2][2].lock), r[t[0]] = function () {
                        return r[t[0] + "With"](this === r ? o : this, arguments), this
                    }, r[t[0] + "With"] = n.fireWith
                }), o.promise(r), e && e.call(r, r), r
            },
            when: function (e) {
                var a, t, n, i = 0,
                    s = ae.call(arguments),
                    o = s.length,
                    r = 1 !== o || e && he.isFunction(e.promise) ? o : 0,
                    l = 1 === r ? e : he.Deferred(),
                    d = function (t, n, i) {
                        return function (e) {
                            n[t] = this, i[t] = 1 < arguments.length ? ae.call(arguments) : e, i === a ? l.notifyWith(n, i) : --r || l.resolveWith(n, i)
                        }
                    };
                if (1 < o)
                    for (a = new Array(o), t = new Array(o), n = new Array(o); i < o; i++) s[i] && he.isFunction(s[i].promise) ? s[i].promise().progress(d(i, t, a)).done(d(i, n, s)).fail(l.reject) : --r;
                return r || l.resolveWith(n, s), l.promise()
            }
        }), he.fn.ready = function (e) {
            return he.ready.promise().done(e), this
        }, he.extend({
            isReady: !1,
            readyWait: 1,
            holdReady: function (e) {
                e ? he.readyWait++ : he.ready(!0)
            },
            ready: function (e) {
                (!0 === e ? --he.readyWait : he.isReady) || (he.isReady = !0) !== e && 0 < --he.readyWait || (Ee.resolveWith(ie, [he]), he.fn.triggerHandler && (he(ie).triggerHandler("ready"), he(ie).off("ready")))
            }
        }), he.ready.promise = function (e) {
            if (!Ee)
                if (Ee = he.Deferred(), "complete" === ie.readyState || "loading" !== ie.readyState && !ie.documentElement.doScroll) w.setTimeout(he.ready);
                else if (ie.addEventListener) ie.addEventListener("DOMContentLoaded", s), w.addEventListener("load", s);
            else {
                ie.attachEvent("onreadystatechange", s), w.attachEvent("onload", s);
                var t = !1;
                try {
                    t = null == w.frameElement && ie.documentElement
                } catch (n) {}
                t && t.doScroll && function i() {
                    if (!he.isReady) {
                        try {
                            t.doScroll("left")
                        } catch (n) {
                            return w.setTimeout(i, 50)
                        }
                        a(), he.ready()
                    }
                }()
            }
            return Ee.promise(e)
        }, he.ready.promise(), he(ue)) break;
    ue.ownFirst = "0" === Ne, ue.inlineBlockNeedsLayout = !1, he(function () {
            var e, t, n, i;
            (n = ie.getElementsByTagName("body")[0]) && n.style && (t = ie.createElement("div"), (i = ie.createElement("div")).style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(i).appendChild(t), "undefined" != typeof t.style.zoom && (t.style.cssText = "display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1", ue.inlineBlockNeedsLayout = e = 3 === t.offsetWidth, e && (n.style.zoom = 1)), n.removeChild(i))
        }),
        function () {
            var e = ie.createElement("div");
            ue.deleteExpando = !0;
            try {
                delete e.test
            } catch (t) {
                ue.deleteExpando = !1
            }
            e = null
        }();
    var Ae, Re = function (e) {
            var t = he.noData[(e.nodeName + " ").toLowerCase()],
                n = +e.nodeType || 1;
            return (1 === n || 9 === n) && (!t || !0 !== t && e.getAttribute("classid") === t)
        },
        je = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        Ie = /([A-Z])/g;
    he.extend({
        cache: {},
        noData: {
            "applet ": !0,
            "embed ": !0,
            "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function (e) {
            return !!(e = e.nodeType ? he.cache[e[he.expando]] : e[he.expando]) && !d(e)
        },
        data: function (e, t, n) {
            return i(e, t, n)
        },
        removeData: function (e, t) {
            return o(e, t)
        },
        _data: function (e, t, n) {
            return i(e, t, n, !0)
        },
        _removeData: function (e, t) {
            return o(e, t, !0)
        }
    }), he.fn.extend({
        data: function (e, t) {
            var n, i, a, s = this[0],
                o = s && s.attributes;
            if (e !== undefined) return "object" == typeof e ? this.each(function () {
                he.data(this, e)
            }) : 1 < arguments.length ? this.each(function () {
                he.data(this, e, t)
            }) : s ? l(s, e, he.data(s, e)) : undefined;
            if (this.length && (a = he.data(s), 1 === s.nodeType && !he._data(s, "parsedAttrs"))) {
                for (n = o.length; n--;) o[n] && 0 === (i = o[n].name).indexOf("data-") && l(s, i = he.camelCase(i.slice(5)), a[i]);
                he._data(s, "parsedAttrs", !0)
            }
            return a
        },
        removeData: function (e) {
            return this.each(function () {
                he.removeData(this, e)
            })
        }
    }), he.extend({
        queue: function (e, t, n) {
            var i;
            if (e) return t = (t || "fx") + "queue", i = he._data(e, t), n && (!i || he.isArray(n) ? i = he._data(e, t, he.makeArray(n)) : i.push(n)), i || []
        },
        dequeue: function (e, t) {
            t = t || "fx";
            var n = he.queue(e, t),
                i = n.length,
                a = n.shift(),
                s = he._queueHooks(e, t),
                o = function () {
                    he.dequeue(e, t)
                };
            "inprogress" === a && (a = n.shift(), i--), a && ("fx" === t && n.unshift("inprogress"), delete s.stop, a.call(e, o, s)), !i && s && s.empty.fire()
        },
        _queueHooks: function (e, t) {
            var n = t + "queueHooks";
            return he._data(e, n) || he._data(e, n, {
                empty: he.Callbacks("once memory").add(function () {
                    he._removeData(e, t + "queue"), he._removeData(e, n)
                })
            })
        }
    }), he.fn.extend({
        queue: function (t, n) {
            var e = 2;
            return "string" != typeof t && (n = t, t = "fx", e--), arguments.length < e ? he.queue(this[0], t) : n === undefined ? this : this.each(function () {
                var e = he.queue(this, t, n);
                he._queueHooks(this, t), "fx" === t && "inprogress" !== e[0] && he.dequeue(this, t)
            })
        },
        dequeue: function (e) {
            return this.each(function () {
                he.dequeue(this, e)
            })
        },
        clearQueue: function (e) {
            return this.queue(e || "fx", [])
        },
        promise: function (e, t) {
            var n, i = 1,
                a = he.Deferred(),
                s = this,
                o = this.length,
                r = function () {
                    --i || a.resolveWith(s, [s])
                };
            for ("string" != typeof e && (t = e, e = undefined), e = e || "fx"; o--;)(n = he._data(s[o], e + "queueHooks")) && n.empty && (i++, n.empty.add(r));
            return r(), a.promise(t)
        }
    }), ue.shrinkWrapBlocks = function () {
        return null != Ae ? Ae : (Ae = !1, (t = ie.getElementsByTagName("body")[0]) && t.style ? (e = ie.createElement("div"), (n = ie.createElement("div")).style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", t.appendChild(n).appendChild(e), "undefined" != typeof e.style.zoom && (e.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1", e.appendChild(ie.createElement("div")).style.width = "5px", Ae = 3 !== e.offsetWidth), t.removeChild(n), Ae) : void 0);
        var e, t, n
    };
    var Le, Fe, Oe, He = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Pe = new RegExp("^(?:([+-])=|)(" + He + ")([a-z%]*)$", "i"),
        qe = ["Top", "Right", "Bottom", "Left"],
        Be = function (e, t) {
            return e = t || e, "none" === he.css(e, "display") || !he.contains(e.ownerDocument, e)
        },
        $e = function (e, t, n, i, a, s, o) {
            var r = 0,
                l = e.length,
                d = null == n;
            if ("object" === he.type(n))
                for (r in a = !0, n) $e(e, t, r, n[r], !0, s, o);
            else if (i !== undefined && (a = !0, he.isFunction(i) || (o = !0), d && (o ? (t.call(e, i), t = null) : (d = t, t = function (e, t, n) {
                    return d.call(he(e), n)
                })), t))
                for (; r < l; r++) t(e[r], n, o ? i : i.call(e[r], r, t(e[r], n)));
            return a ? e : d ? t.call(e) : l ? t(e[0], n) : s
        },
        Ge = /^(?:checkbox|radio)$/i,
        ze = /<([\w:-]+)/,
        We = /^$|\/(?:java|ecma)script/i,
        Ye = /^\s+/,
        Ve = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|dialog|figcaption|figure|footer|header|hgroup|main|mark|meter|nav|output|picture|progress|section|summary|template|time|video";
    Le = ie.createElement("div"), Fe = ie.createDocumentFragment(), Oe = ie.createElement("input"), Le.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", ue.leadingWhitespace = 3 === Le.firstChild.nodeType, ue.tbody = !Le.getElementsByTagName("tbody").length, ue.htmlSerialize = !!Le.getElementsByTagName("link").length, ue.html5Clone = "<:nav></:nav>" !== ie.createElement("nav").cloneNode(!0).outerHTML, Oe.type = "checkbox", Oe.checked = !0, Fe.appendChild(Oe), ue.appendChecked = Oe.checked, Le.innerHTML = "<textarea>x</textarea>", ue.noCloneChecked = !!Le.cloneNode(!0).lastChild.defaultValue, Fe.appendChild(Le), (Oe = ie.createElement("input")).setAttribute("type", "radio"), Oe.setAttribute("checked", "checked"), Oe.setAttribute("name", "t"), Le.appendChild(Oe), ue.checkClone = Le.cloneNode(!0).cloneNode(!0).lastChild.checked, ue.noCloneEvent = !!Le.addEventListener, Le[he.expando] = 1, ue.attributes = !Le.getAttribute(he.expando);
    var Ke = {
        option: [1, "<select multiple='multiple'>", "</select>"],
        legend: [1, "<fieldset>", "</fieldset>"],
        area: [1, "<map>", "</map>"],
        param: [1, "<object>", "</object>"],
        thead: [1, "<table>", "</table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: ue.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
    };
    Ke.optgroup = Ke.option, Ke.tbody = Ke.tfoot = Ke.colgroup = Ke.caption = Ke.thead, Ke.th = Ke.td;
    var Ue = /<|&#?\w+;/,
        Xe = /<tbody/i;
    ! function () {
        var e, t, n = ie.createElement("div");
        for (e in {
                submit: !0,
                change: !0,
                focusin: !0
            }) t = "on" + e, (ue[e] = t in w) || (n.setAttribute(t, "t"), ue[e] = !1 === n.attributes[t].expando);
        n = null
    }();
    var Je = /^(?:input|select|textarea)$/i,
        Qe = /^key/,
        Ze = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        et = /^(?:focusinfocus|focusoutblur)$/,
        tt = /^([^.]*)(?:\.(.+)|)/;
    he.event = {
        global: {},
        add: function (e, t, n, i, a) {
            var s, o, r, l, d, c, u, p, h, f, m, g = he._data(e);
            if (g) {
                for (n.handler && (n = (l = n).handler, a = l.selector), n.guid || (n.guid = he.guid++), (o = g.events) || (o = g.events = {}), (c = g.handle) || ((c = g.handle = function (e) {
                        return void 0 === he || e && he.event.triggered === e.type ? undefined : he.event.dispatch.apply(c.elem, arguments)
                    }).elem = e), r = (t = (t || "").match(Me) || [""]).length; r--;) h = m = (s = tt.exec(t[r]) || [])[1], f = (s[2] || "").split(".").sort(), h && (d = he.event.special[h] || {}, h = (a ? d.delegateType : d.bindType) || h, d = he.event.special[h] || {}, u = he.extend({
                    type: h,
                    origType: m,
                    data: i,
                    handler: n,
                    guid: n.guid,
                    selector: a,
                    needsContext: a && he.expr.match.needsContext.test(a),
                    namespace: f.join(".")
                }, l), (p = o[h]) || ((p = o[h] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, i, f, c) || (e.addEventListener ? e.addEventListener(h, c, !1) : e.attachEvent && e.attachEvent("on" + h, c))), d.add && (d.add.call(e, u), u.handler.guid || (u.handler.guid = n.guid)), a ? p.splice(p.delegateCount++, 0, u) : p.push(u), he.event.global[h] = !0);
                e = null
            }
        },
        remove: function (e, t, n, i, a) {
            var s, o, r, l, d, c, u, p, h, f, m, g = he.hasData(e) && he._data(e);
            if (g && (c = g.events)) {
                for (d = (t = (t || "").match(Me) || [""]).length; d--;)
                    if (h = m = (r = tt.exec(t[d]) || [])[1], f = (r[2] || "").split(".").sort(), h) {
                        for (u = he.event.special[h] || {}, p = c[h = (i ? u.delegateType : u.bindType) || h] || [], r = r[2] && new RegExp("(^|\\.)" + f.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = s = p.length; s--;) o = p[s], !a && m !== o.origType || n && n.guid !== o.guid || r && !r.test(o.namespace) || i && i !== o.selector && ("**" !== i || !o.selector) || (p.splice(s, 1), o.selector && p.delegateCount--, u.remove && u.remove.call(e, o));
                        l && !p.length && (u.teardown && !1 !== u.teardown.call(e, f, g.handle) || he.removeEvent(e, h, g.handle), delete c[h])
                    } else
                        for (h in c) he.event.remove(e, h + t[d], n, i, !0);
                he.isEmptyObject(c) && (delete g.handle, he._removeData(e, "events"))
            }
        },
        trigger: function (e, t, n, i) {
            var a, s, o, r, l, d, c, u = [n || ie],
                p = ce.call(e, "type") ? e.type : e,
                h = ce.call(e, "namespace") ? e.namespace.split(".") : [];
            if (o = d = n = n || ie, 3 !== n.nodeType && 8 !== n.nodeType && !et.test(p + he.event.triggered) && (-1 < p.indexOf(".") && (p = (h = p.split(".")).shift(), h.sort()), s = p.indexOf(":") < 0 && "on" + p, (e = e[he.expando] ? e : new he.Event(p, "object" == typeof e && e)).isTrigger = i ? 2 : 3, e.namespace = h.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = undefined, e.target || (e.target = n), t = null == t ? [e] : he.makeArray(t, [e]), l = he.event.special[p] || {}, i || !l.trigger || !1 !== l.trigger.apply(n, t))) {
                if (!i && !l.noBubble && !he.isWindow(n)) {
                    for (r = l.delegateType || p, et.test(r + p) || (o = o.parentNode); o; o = o.parentNode) u.push(o), d = o;
                    d === (n.ownerDocument || ie) && u.push(d.defaultView || d.parentWindow || w)
                }
                for (c = 0;
                    (o = u[c++]) && !e.isPropagationStopped();) e.type = 1 < c ? r : l.bindType || p, (a = (he._data(o, "events") || {})[e.type] && he._data(o, "handle")) && a.apply(o, t), (a = s && o[s]) && a.apply && Re(o) && (e.result = a.apply(o, t), !1 === e.result && e.preventDefault());
                if (e.type = p, !i && !e.isDefaultPrevented() && (!l._default || !1 === l._default.apply(u.pop(), t)) && Re(n) && s && n[p] && !he.isWindow(n)) {
                    (d = n[s]) && (n[s] = null), he.event.triggered = p;
                    try {
                        n[p]()
                    } catch (f) {}
                    he.event.triggered = undefined, d && (n[s] = d)
                }
                return e.result
            }
        },
        dispatch: function (e) {
            e = he.event.fix(e);
            var t, n, i, a, s, o = [],
                r = ae.call(arguments),
                l = (he._data(this, "events") || {})[e.type] || [],
                d = he.event.special[e.type] || {};
            if ((r[0] = e).delegateTarget = this, !d.preDispatch || !1 !== d.preDispatch.call(this, e)) {
                for (o = he.event.handlers.call(this, e, l), t = 0;
                    (a = o[t++]) && !e.isPropagationStopped();)
                    for (e.currentTarget = a.elem, n = 0;
                        (s = a.handlers[n++]) && !e.isImmediatePropagationStopped();) e.rnamespace && !e.rnamespace.test(s.namespace) || (e.handleObj = s, e.data = s.data, (i = ((he.event.special[s.origType] || {}).handle || s.handler).apply(a.elem, r)) !== undefined && !1 === (e.result = i) && (e.preventDefault(), e.stopPropagation()));
                return d.postDispatch && d.postDispatch.call(this, e), e.result
            }
        },
        handlers: function (e, t) {
            var n, i, a, s, o = [],
                r = t.delegateCount,
                l = e.target;
            if (r && l.nodeType && ("click" !== e.type || isNaN(e.button) || e.button < 1))
                for (; l != this; l = l.parentNode || this)
                    if (1 === l.nodeType && (!0 !== l.disabled || "click" !== e.type)) {
                        for (i = [], n = 0; n < r; n++) i[a = (s = t[n]).selector + " "] === undefined && (i[a] = s.needsContext ? -1 < he(a, this).index(l) : he.find(a, this, null, [l]).length), i[a] && i.push(s);
                        i.length && o.push({
                            elem: l,
                            handlers: i
                        })
                    } return r < t.length && o.push({
                elem: this,
                handlers: t.slice(r)
            }), o
        },
        fix: function (e) {
            if (e[he.expando]) return e;
            var t, n, i, a = e.type,
                s = e,
                o = this.fixHooks[a];
            for (o || (this.fixHooks[a] = o = Ze.test(a) ? this.mouseHooks : Qe.test(a) ? this.keyHooks : {}), i = o.props ? this.props.concat(o.props) : this.props, e = new he.Event(s), t = i.length; t--;) e[n = i[t]] = s[n];
            return e.target || (e.target = s.srcElement || ie), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !!e.metaKey, o.filter ? o.filter(e, s) : e
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function (e, t) {
                return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (e, t) {
                var n, i, a, s = t.button,
                    o = t.fromElement;
                return null == e.pageX && null != t.clientX && (a = (i = e.target.ownerDocument || ie).documentElement, n = i.body, e.pageX = t.clientX + (a && a.scrollLeft || n && n.scrollLeft || 0) - (a && a.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (a && a.scrollTop || n && n.scrollTop || 0) - (a && a.clientTop || n && n.clientTop || 0)), !e.relatedTarget && o && (e.relatedTarget = o === e.target ? t.toElement : o), e.which || s === undefined || (e.which = 1 & s ? 1 : 2 & s ? 3 : 4 & s ? 2 : 0), e
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function () {
                    if (this !== f() && this.focus) try {
                        return this.focus(), !1
                    } catch (e) {}
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function () {
                    if (this === f() && this.blur) return this.blur(), !1
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function () {
                    if (he.nodeName(this, "input") && "checkbox" === this.type && this.click) return this.click(), !1
                },
                _default: function (e) {
                    return he.nodeName(e.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function (e) {
                    e.result !== undefined && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        },
        simulate: function (e, t, n) {
            var i = he.extend(new he.Event, n, {
                type: e,
                isSimulated: !0
            });
            he.event.trigger(i, null, t), i.isDefaultPrevented() && n.preventDefault()
        }
    }, he.removeEvent = ie.removeEventListener ? function (e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    } : function (e, t, n) {
        var i = "on" + t;
        e.detachEvent && ("undefined" == typeof e[i] && (e[i] = null), e.detachEvent(i, n))
    }, he.Event = function (e, t) {
        if (!(this instanceof he.Event)) return new he.Event(e, t);
        e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || e.defaultPrevented === undefined && !1 === e.returnValue ? p : h) : this.type = e, t && he.extend(this, t), this.timeStamp = e && e.timeStamp || he.now(), this[he.expando] = !0
    }, he.Event.prototype = {
        constructor: he.Event,
        isDefaultPrevented: h,
        isPropagationStopped: h,
        isImmediatePropagationStopped: h,
        preventDefault: function () {
            var e = this.originalEvent;
            this.isDefaultPrevented = p, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
        },
        stopPropagation: function () {
            var e = this.originalEvent;
            this.isPropagationStopped = p, e && !this.isSimulated && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
        },
        stopImmediatePropagation: function () {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = p, e && e.stopImmediatePropagation && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, he.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function (e, s) {
        he.event.special[e] = {
            delegateType: s,
            bindType: s,
            handle: function (e) {
                var t, n = this,
                    i = e.relatedTarget,
                    a = e.handleObj;
                return i && (i === n || he.contains(n, i)) || (e.type = a.origType, t = a.handler.apply(this, arguments), e.type = s), t
            }
        }
    }), ue.submit || (he.event.special.submit = {
        setup: function () {
            if (he.nodeName(this, "form")) return !1;
            he.event.add(this, "click._submit keypress._submit", function (e) {
                var t = e.target,
                    n = he.nodeName(t, "input") || he.nodeName(t, "button") ? he.prop(t, "form") : undefined;
                n && !he._data(n, "submit") && (he.event.add(n, "submit._submit", function (e) {
                    e._submitBubble = !0
                }), he._data(n, "submit", !0))
            })
        },
        postDispatch: function (e) {
            e._submitBubble && (delete e._submitBubble, this.parentNode && !e.isTrigger && he.event.simulate("submit", this.parentNode, e))
        },
        teardown: function () {
            if (he.nodeName(this, "form")) return !1;
            he.event.remove(this, "._submit")
        }
    }), ue.change || (he.event.special.change = {
        setup: function () {
            if (Je.test(this.nodeName)) return "checkbox" !== this.type && "radio" !== this.type || (he.event.add(this, "propertychange._change", function (e) {
                "checked" === e.originalEvent.propertyName && (this._justChanged = !0)
            }), he.event.add(this, "click._change", function (e) {
                this._justChanged && !e.isTrigger && (this._justChanged = !1), he.event.simulate("change", this, e)
            })), !1;
            he.event.add(this, "beforeactivate._change", function (e) {
                var t = e.target;
                Je.test(t.nodeName) && !he._data(t, "change") && (he.event.add(t, "change._change", function (e) {
                    !this.parentNode || e.isSimulated || e.isTrigger || he.event.simulate("change", this.parentNode, e)
                }), he._data(t, "change", !0))
            })
        },
        handle: function (e) {
            var t = e.target;
            if (this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type) return e.handleObj.handler.apply(this, arguments)
        },
        teardown: function () {
            return he.event.remove(this, "._change"), !Je.test(this.nodeName)
        }
    }), ue.focusin || he.each({
        focus: "focusin",
        blur: "focusout"
    }, function (n, i) {
        var a = function (e) {
            he.event.simulate(i, e.target, he.event.fix(e))
        };
        he.event.special[i] = {
            setup: function () {
                var e = this.ownerDocument || this,
                    t = he._data(e, i);
                t || e.addEventListener(n, a, !0), he._data(e, i, (t || 0) + 1)
            },
            teardown: function () {
                var e = this.ownerDocument || this,
                    t = he._data(e, i) - 1;
                t ? he._data(e, i, t) : (e.removeEventListener(n, a, !0), he._removeData(e, i))
            }
        }
    }), he.fn.extend({
        on: function (e, t, n, i) {
            return x(this, e, t, n, i)
        },
        one: function (e, t, n, i) {
            return x(this, e, t, n, i, 1)
        },
        off: function (e, t, n) {
            var i, a;
            if (e && e.preventDefault && e.handleObj) return i = e.handleObj, he(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
            if ("object" != typeof e) return !1 !== t && "function" != typeof t || (n = t, t = undefined), !1 === n && (n = h), this.each(function () {
                he.event.remove(this, e, n, t)
            });
            for (a in e) this.off(a, t, e[a]);
            return this
        },
        trigger: function (e, t) {
            return this.each(function () {
                he.event.trigger(e, t, this)
            })
        },
        triggerHandler: function (e, t) {
            var n = this[0];
            if (n) return he.event.trigger(e, t, n, !0)
        }
    });
    var nt = / jQuery\d+="(?:null|\d+)"/g,
        it = new RegExp("<(?:" + Ve + ")[\\s/>]", "i"),
        at = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,
        st = /<script|<style|<link/i,
        ot = /checked\s*(?:[^=]|=\s*.checked.)/i,
        rt = /^true\/(.*)/,
        lt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
        dt = g(ie).appendChild(ie.createElement("div"));
    he.extend({
        htmlPrefilter: function (e) {
            return e.replace(at, "<$1></$2>")
        },
        clone: function (e, t, n) {
            var i, a, s, o, r, l = he.contains(e.ownerDocument, e);
            if (ue.html5Clone || he.isXMLDoc(e) || !it.test("<" + e.nodeName + ">") ? s = e.cloneNode(!0) : (dt.innerHTML = e.outerHTML, dt.removeChild(s = dt.firstChild)), !(ue.noCloneEvent && ue.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || he.isXMLDoc(e)))
                for (i = v(s), r = v(e), o = 0; null != (a = r[o]); ++o) i[o] && S(a, i[o]);
            if (t)
                if (n)
                    for (r = r || v(e), i = i || v(s), o = 0; null != (a = r[o]); o++) T(a, i[o]);
                else T(e, s);
            return 0 < (i = v(s, "script")).length && b(i, !l && v(e, "script")), i = r = a = null, s
        },
        cleanData: function (e, t) {
            for (var n, i, a, s, o = 0, r = he.expando, l = he.cache, d = ue.attributes, c = he.event.special; null != (n = e[o]); o++)
                if ((t || Re(n)) && (s = (a = n[r]) && l[a])) {
                    if (s.events)
                        for (i in s.events) c[i] ? he.event.remove(n, i) : he.removeEvent(n, i, s.handle);
                    l[a] && (delete l[a], d || "undefined" == typeof n.removeAttribute ? n[r] = undefined : n.removeAttribute(r), ne.push(a))
                }
        }
    }), he.fn.extend({
        domManip: D,
        detach: function (e) {
            return E(this, e, !0)
        },
        remove: function (e) {
            return E(this, e)
        },
        text: function (e) {
            return $e(this, function (e) {
                return e === undefined ? he.text(this) : this.empty().append((this[0] && this[0].ownerDocument || ie).createTextNode(e))
            }, null, e, arguments.length)
        },
        append: function () {
            return D(this, arguments, function (e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || _(this, e).appendChild(e)
            })
        },
        prepend: function () {
            return D(this, arguments, function (e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = _(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            })
        },
        before: function () {
            return D(this, arguments, function (e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function () {
            return D(this, arguments, function (e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function () {
            for (var e, t = 0; null != (e = this[t]); t++) {
                for (1 === e.nodeType && he.cleanData(v(e, !1)); e.firstChild;) e.removeChild(e.firstChild);
                e.options && he.nodeName(e, "select") && (e.options.length = 0)
            }
            return this
        },
        clone: function (e, t) {
            return e = null != e && e, t = null == t ? e : t, this.map(function () {
                return he.clone(this, e, t)
            })
        },
        html: function (e) {
            return $e(this, function (e) {
                var t = this[0] || {},
                    n = 0,
                    i = this.length;
                if (e === undefined) return 1 === t.nodeType ? t.innerHTML.replace(nt, "") : undefined;
                if ("string" == typeof e && !st.test(e) && (ue.htmlSerialize || !it.test(e)) && (ue.leadingWhitespace || !Ye.test(e)) && !Ke[(ze.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = he.htmlPrefilter(e);
                    try {
                        for (; n < i; n++) 1 === (t = this[n] || {}).nodeType && (he.cleanData(v(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (a) {}
                }
                t && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function () {
            var n = [];
            return D(this, arguments, function (e) {
                var t = this.parentNode;
                he.inArray(this, n) < 0 && (he.cleanData(v(this)), t && t.replaceChild(e, this))
            }, n)
        }
    }), he.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (e, o) {
        he.fn[e] = function (e) {
            for (var t, n = 0, i = [], a = he(e), s = a.length - 1; n <= s; n++) t = n === s ? this : this.clone(!0), he(a[n])[o](t), oe.apply(i, t.get());
            return this.pushStack(i)
        }
    });
    var ct, ut = {
            HTML: "block",
            BODY: "block"
        },
        pt = /^margin/,
        ht = new RegExp("^(" + He + ")(?!px)[a-z%]+$", "i"),
        ft = function (e, t, n, i) {
            var a, s, o = {};
            for (s in t) o[s] = e.style[s], e.style[s] = t[s];
            for (s in a = n.apply(e, i || []), t) e.style[s] = o[s];
            return a
        },
        mt = ie.documentElement;
    ! function () {
        function e() {
            var e, t, n = ie.documentElement;
            n.appendChild(d), c.style.cssText = "-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", i = s = l = !1, a = r = !0, w.getComputedStyle && (t = w.getComputedStyle(c), i = "1%" !== (t || {}).top, l = "2px" === (t || {}).marginLeft, s = "4px" === (t || {
                width: "4px"
            }).width, c.style.marginRight = "50%", a = "4px" === (t || {
                marginRight: "4px"
            }).marginRight, (e = c.appendChild(ie.createElement("div"))).style.cssText = c.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", e.style.marginRight = e.style.width = "0", c.style.width = "1px", r = !parseFloat((w.getComputedStyle(e) || {}).marginRight), c.removeChild(e)), c.style.display = "none", (o = 0 === c.getClientRects().length) && (c.style.display = "", c.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", c.childNodes[0].style.borderCollapse = "separate", (
                e = c.getElementsByTagName("td"))[0].style.cssText = "margin:0;border:0;padding:0;display:none", (o = 0 === e[0].offsetHeight) && (e[0].style.display = "", e[1].style.display = "none", o = 0 === e[0].offsetHeight)), n.removeChild(d)
        }
        var i, a, s, o, r, l, d = ie.createElement("div"),
            c = ie.createElement("div");
        c.style && (c.style.cssText = "float:left;opacity:.5", ue.opacity = "0.5" === c.style.opacity, ue.cssFloat = !!c.style.cssFloat, c.style.backgroundClip = "content-box", c.cloneNode(!0).style.backgroundClip = "", ue.clearCloneStyle = "content-box" === c.style.backgroundClip, (d = ie.createElement("div")).style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", c.innerHTML = "", d.appendChild(c), ue.boxSizing = "" === c.style.boxSizing || "" === c.style.MozBoxSizing || "" === c.style.WebkitBoxSizing, he.extend(ue, {
            reliableHiddenOffsets: function () {
                return null == i && e(), o
            },
            boxSizingReliable: function () {
                return null == i && e(), s
            },
            pixelMarginRight: function () {
                return null == i && e(), a
            },
            pixelPosition: function () {
                return null == i && e(), i
            },
            reliableMarginRight: function () {
                return null == i && e(), r
            },
            reliableMarginLeft: function () {
                return null == i && e(), l
            }
        }))
    }();
    var gt, vt, bt = /^(top|right|bottom|left)$/;
    w.getComputedStyle ? (gt = function (e) {
        var t = e.ownerDocument.defaultView;
        return t && t.opener || (t = w), t.getComputedStyle(e)
    }, vt = function (e, t, n) {
        var i, a, s, o, r = e.style;
        return "" !== (o = (n = n || gt(e)) ? n.getPropertyValue(t) || n[t] : undefined) && o !== undefined || he.contains(e.ownerDocument, e) || (o = he.style(e, t)), n && !ue.pixelMarginRight() && ht.test(o) && pt.test(t) && (i = r.width, a = r.minWidth, s = r.maxWidth, r.minWidth = r.maxWidth = r.width = o, o = n.width, r.width = i, r.minWidth = a, r.maxWidth = s), o === undefined ? o : o + ""
    }) : mt.currentStyle && (gt = function (e) {
        return e.currentStyle
    }, vt = function (e, t, n) {
        var i, a, s, o, r = e.style;
        return null == (o = (n = n || gt(e)) ? n[t] : undefined) && r && r[t] && (o = r[t]), ht.test(o) && !bt.test(t) && (i = r.left, (s = (a = e.runtimeStyle) && a.left) && (a.left = e.currentStyle.left), r.left = "fontSize" === t ? "1em" : o, o = r.pixelLeft + "px", r.left = i, s && (a.left = s)), o === undefined ? o : o + "" || "auto"
    });
    var yt = /alpha\([^)]*\)/i,
        xt = /opacity\s*=\s*([^)]*)/i,
        _t = /^(none|table(?!-c[ea]).+)/,
        kt = new RegExp("^(" + He + ")(.*)$", "i"),
        wt = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        Ct = {
            letterSpacing: "0",
            fontWeight: "400"
        },
        Tt = ["Webkit", "O", "Moz", "ms"],
        St = ie.createElement("div").style;
    he.extend({
        cssHooks: {
            opacity: {
                get: function (e, t) {
                    if (t) {
                        var n = vt(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": ue.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function (e, t, n, i) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var a, s, o, r = he.camelCase(t),
                    l = e.style;
                if (t = he.cssProps[r] || (he.cssProps[r] = R(r) || r), o = he.cssHooks[t] || he.cssHooks[r], n === undefined) return o && "get" in o && (a = o.get(e, !1, i)) !== undefined ? a : l[t];
                if ("string" === (s = typeof n) && (a = Pe.exec(n)) && a[1] && (n = u(e, t, a), s = "number"), null != n && n == n && ("number" === s && (n += a && a[3] || (he.cssNumber[r] ? "" : "px")), ue.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), !(o && "set" in o && (n = o.set(e, n, i)) === undefined))) try {
                    l[t] = n
                } catch (d) {}
            }
        },
        css: function (e, t, n, i) {
            var a, s, o, r = he.camelCase(t);
            return t = he.cssProps[r] || (he.cssProps[r] = R(r) || r), (o = he.cssHooks[t] || he.cssHooks[r]) && "get" in o && (s = o.get(e, !0, n)), s === undefined && (s = vt(e, t, i)), "normal" === s && t in Ct && (s = Ct[t]), "" === n || n ? (a = parseFloat(s), !0 === n || isFinite(a) ? a || 0 : s) : s
        }
    }), he.each(["height", "width"], function (e, a) {
        he.cssHooks[a] = {
            get: function (e, t, n) {
                if (t) return _t.test(he.css(e, "display")) && 0 === e.offsetWidth ? ft(e, wt, function () {
                    return F(e, a, n)
                }) : F(e, a, n)
            },
            set: function (e, t, n) {
                var i = n && gt(e);
                return I(e, t, n ? L(e, a, n, ue.boxSizing && "border-box" === he.css(e, "boxSizing", !1, i), i) : 0)
            }
        }
    }), ue.opacity || (he.cssHooks.opacity = {
        get: function (e, t) {
            return xt.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
        },
        set: function (e, t) {
            var n = e.style,
                i = e.currentStyle,
                a = he.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                s = i && i.filter || n.filter || "";
            ((n.zoom = 1) <= t || "" === t) && "" === he.trim(s.replace(yt, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || i && !i.filter) || (n.filter = yt.test(s) ? s.replace(yt, a) : s + " " + a)
        }
    }), he.cssHooks.marginRight = A(ue.reliableMarginRight, function (e, t) {
        if (t) return ft(e, {
            display: "inline-block"
        }, vt, [e, "marginRight"])
    }), he.cssHooks.marginLeft = A(ue.reliableMarginLeft, function (e, t) {
        if (t) return (parseFloat(vt(e, "marginLeft")) || (he.contains(e.ownerDocument, e) ? e.getBoundingClientRect().left - ft(e, {
            marginLeft: 0
        }, function () {
            return e.getBoundingClientRect().left
        }) : 0)) + "px"
    }), he.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function (a, s) {
        he.cssHooks[a + s] = {
            expand: function (e) {
                for (var t = 0, n = {}, i = "string" == typeof e ? e.split(" ") : [e]; t < 4; t++) n[a + qe[t] + s] = i[t] || i[t - 2] || i[0];
                return n
            }
        }, pt.test(a) || (he.cssHooks[a + s].set = I)
    }), he.fn.extend({
        css: function (e, t) {
            return $e(this, function (e, t, n) {
                var i, a, s = {},
                    o = 0;
                if (he.isArray(t)) {
                    for (i = gt(e), a = t.length; o < a; o++) s[t[o]] = he.css(e, t[o], !1, i);
                    return s
                }
                return n !== undefined ? he.style(e, t, n) : he.css(e, t)
            }, e, t, 1 < arguments.length)
        },
        show: function () {
            return j(this, !0)
        },
        hide: function () {
            return j(this)
        },
        toggle: function (e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function () {
                Be(this) ? he(this).show() : he(this).hide()
            })
        }
    }), (he.Tween = O).prototype = {
        constructor: O,
        init: function (e, t, n, i, a, s) {
            this.elem = e, this.prop = n, this.easing = a || he.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = s || (he.cssNumber[n] ? "" : "px")
        },
        cur: function () {
            var e = O.propHooks[this.prop];
            return e && e.get ? e.get(this) : O.propHooks._default.get(this)
        },
        run: function (e) {
            var t, n = O.propHooks[this.prop];
            return this.options.duration ? this.pos = t = he.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : O.propHooks._default.set(this), this
        }
    }, O.prototype.init.prototype = O.prototype, O.propHooks = {
        _default: {
            get: function (e) {
                var t;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = he.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0
            },
            set: function (e) {
                he.fx.step[e.prop] ? he.fx.step[e.prop](e) : 1 !== e.elem.nodeType || null == e.elem.style[he.cssProps[e.prop]] && !he.cssHooks[e.prop] ? e.elem[e.prop] = e.now : he.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }, O.propHooks.scrollTop = O.propHooks.scrollLeft = {
        set: function (e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, he.easing = {
        linear: function (e) {
            return e
        },
        swing: function (e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, he.fx = O.prototype.init, he.fx.step = {};
    var Dt, Et, Nt, Mt, At, Rt, jt, It = /^(?:toggle|show|hide)$/,
        Lt = /queueHooks$/;
    he.Animation = he.extend(G, {
        tweeners: {
            "*": [function (e, t) {
                var n = this.createTween(e, t);
                return u(n.elem, e, Pe.exec(t), n), n
            }]
        },
        tweener: function (e, t) {
            he.isFunction(e) ? (t = e, e = ["*"]) : e = e.match(Me);
            for (var n, i = 0, a = e.length; i < a; i++) n = e[i], G.tweeners[n] = G.tweeners[n] || [], G.tweeners[n].unshift(t)
        },
        prefilters: [B],
        prefilter: function (e, t) {
            t ? G.prefilters.unshift(e) : G.prefilters.push(e)
        }
    }), he.speed = function (e, t, n) {
        var i = e && "object" == typeof e ? he.extend({}, e) : {
            complete: n || !n && t || he.isFunction(e) && e,
            duration: e,
            easing: n && t || t && !he.isFunction(t) && t
        };
        return i.duration = he.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in he.fx.speeds ? he.fx.speeds[i.duration] : he.fx.speeds._default, null != i.queue && !0 !== i.queue || (i.queue = "fx"), i.old = i.complete, i.complete = function () {
            he.isFunction(i.old) && i.old.call(this), i.queue && he.dequeue(this, i.queue)
        }, i
    }, he.fn.extend({
        fadeTo: function (e, t, n, i) {
            return this.filter(Be).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, i)
        },
        animate: function (t, e, n, i) {
            var a = he.isEmptyObject(t),
                s = he.speed(e, n, i),
                o = function () {
                    var e = G(this, he.extend({}, t), s);
                    (a || he._data(this, "finish")) && e.stop(!0)
                };
            return o.finish = o, a || !1 === s.queue ? this.each(o) : this.queue(s.queue, o)
        },
        stop: function (a, e, s) {
            var o = function (e) {
                var t = e.stop;
                delete e.stop, t(s)
            };
            return "string" != typeof a && (s = e, e = a, a = undefined), e && !1 !== a && this.queue(a || "fx", []), this.each(function () {
                var e = !0,
                    t = null != a && a + "queueHooks",
                    n = he.timers,
                    i = he._data(this);
                if (t) i[t] && i[t].stop && o(i[t]);
                else
                    for (t in i) i[t] && i[t].stop && Lt.test(t) && o(i[t]);
                for (t = n.length; t--;) n[t].elem !== this || null != a && n[t].queue !== a || (n[t].anim.stop(s), e = !1, n.splice(t, 1));
                !e && s || he.dequeue(this, a)
            })
        },
        finish: function (o) {
            return !1 !== o && (o = o || "fx"), this.each(function () {
                var e, t = he._data(this),
                    n = t[o + "queue"],
                    i = t[o + "queueHooks"],
                    a = he.timers,
                    s = n ? n.length : 0;
                for (t.finish = !0, he.queue(this, o, []), i && i.stop && i.stop.call(this, !0), e = a.length; e--;) a[e].elem === this && a[e].queue === o && (a[e].anim.stop(!0), a.splice(e, 1));
                for (e = 0; e < s; e++) n[e] && n[e].finish && n[e].finish.call(this);
                delete t.finish
            })
        }
    }), he.each(["toggle", "show", "hide"], function (e, i) {
        var a = he.fn[i];
        he.fn[i] = function (e, t, n) {
            return null == e || "boolean" == typeof e ? a.apply(this, arguments) : this.animate(P(i, !0), e, t, n)
        }
    }), he.each({
        slideDown: P("show"),
        slideUp: P("hide"),
        slideToggle: P("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function (e, i) {
        he.fn[e] = function (e, t, n) {
            return this.animate(i, e, t, n)
        }
    }), he.timers = [], he.fx.tick = function () {
        var e, t = he.timers,
            n = 0;
        for (Dt = he.now(); n < t.length; n++)(e = t[n])() || t[n] !== e || t.splice(n--, 1);
        t.length || he.fx.stop(), Dt = undefined
    }, he.fx.timer = function (e) {
        he.timers.push(e), e() ? he.fx.start() : he.timers.pop()
    }, he.fx.interval = 13, he.fx.start = function () {
        Et || (Et = w.setInterval(he.fx.tick, he.fx.interval))
    }, he.fx.stop = function () {
        w.clearInterval(Et), Et = null
    }, he.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, he.fn.delay = function (i, e) {
        return i = he.fx && he.fx.speeds[i] || i, e = e || "fx", this.queue(e, function (e, t) {
            var n = w.setTimeout(e, i);
            t.stop = function () {
                w.clearTimeout(n)
            }
        })
    }, Mt = ie.createElement("input"), At = ie.createElement("div"), Rt = ie.createElement("select"), jt = Rt.appendChild(ie.createElement("option")), (At = ie.createElement("div")).setAttribute("className", "t"), At.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", Nt = At.getElementsByTagName("a")[0], Mt.setAttribute("type", "checkbox"), At.appendChild(Mt), (Nt = At.getElementsByTagName("a")[0]).style.cssText = "top:1px", ue.getSetAttribute = "t" !== At.className, ue.style = /top/.test(Nt.getAttribute("style")), ue.hrefNormalized = "/a" === Nt.getAttribute("href"), ue.checkOn = !!Mt.value, ue.optSelected = jt.selected, ue.enctype = !!ie.createElement("form").enctype, Rt.disabled = !0, ue.optDisabled = !jt.disabled, (Mt = ie.createElement("input")).setAttribute("value", ""), ue.input = "" === Mt.getAttribute("value"), Mt.value = "t", Mt.setAttribute("type", "radio"), ue.radioValue = "t" === Mt.value;
    var Ft = /\r/g,
        Ot = /[\x20\t\r\n\f]+/g;
    he.fn.extend({
        val: function (n) {
            var i, e, a, t = this[0];
            return arguments.length ? (a = he.isFunction(n), this.each(function (e) {
                var t;
                1 === this.nodeType && (null == (t = a ? n.call(this, e, he(this).val()) : n) ? t = "" : "number" == typeof t ? t += "" : he.isArray(t) && (t = he.map(t, function (e) {
                    return null == e ? "" : e + ""
                })), (i = he.valHooks[this.type] || he.valHooks[this.nodeName.toLowerCase()]) && "set" in i && i.set(this, t, "value") !== undefined || (this.value = t))
            })) : t ? (i = he.valHooks[t.type] || he.valHooks[t.nodeName.toLowerCase()]) && "get" in i && (e = i.get(t, "value")) !== undefined ? e : "string" == typeof (e = t.value) ? e.replace(Ft, "") : null == e ? "" : e : void 0
        }
    }), he.extend({
        valHooks: {
            option: {
                get: function (e) {
                    var t = he.find.attr(e, "value");
                    return null != t ? t : he.trim(he.text(e)).replace(Ot, " ")
                }
            },
            select: {
                get: function (e) {
                    for (var t, n, i = e.options, a = e.selectedIndex, s = "select-one" === e.type || a < 0, o = s ? null : [], r = s ? a + 1 : i.length, l = a < 0 ? r : s ? a : 0; l < r; l++)
                        if (((n = i[l]).selected || l === a) && (ue.optDisabled ? !n.disabled : null === n.getAttribute("disabled")) && (!n.parentNode.disabled || !he.nodeName(n.parentNode, "optgroup"))) {
                            if (t = he(n).val(), s) return t;
                            o.push(t)
                        } return o
                },
                set: function (e, t) {
                    for (var n, i, a = e.options, s = he.makeArray(t), o = a.length; o--;)
                        if (i = a[o], -1 < he.inArray(he.valHooks.option.get(i), s)) try {
                            i.selected = n = !0
                        } catch (r) {
                            i.scrollHeight
                        } else i.selected = !1;
                    return n || (e.selectedIndex = -1), a
                }
            }
        }
    }), he.each(["radio", "checkbox"], function () {
        he.valHooks[this] = {
            set: function (e, t) {
                if (he.isArray(t)) return e.checked = -1 < he.inArray(he(e).val(), t)
            }
        }, ue.checkOn || (he.valHooks[this].get = function (e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    });
    var Ht, Pt, qt = he.expr.attrHandle,
        Bt = /^(?:checked|selected)$/i,
        $t = ue.getSetAttribute,
        Gt = ue.input;
    he.fn.extend({
        attr: function (e, t) {
            return $e(this, he.attr, e, t, 1 < arguments.length)
        },
        removeAttr: function (e) {
            return this.each(function () {
                he.removeAttr(this, e)
            })
        }
    }), he.extend({
        attr: function (e, t, n) {
            var i, a, s = e.nodeType;
            if (3 !== s && 8 !== s && 2 !== s) return "undefined" == typeof e.getAttribute ? he.prop(e, t, n) : (1 === s && he.isXMLDoc(e) || (t = t.toLowerCase(), a = he.attrHooks[t] || (he.expr.match.bool.test(t) ? Pt : Ht)), n !== undefined ? null === n ? void he.removeAttr(e, t) : a && "set" in a && (i = a.set(e, n, t)) !== undefined ? i : (e.setAttribute(t, n + ""), n) : a && "get" in a && null !== (i = a.get(e, t)) ? i : null == (i = he.find.attr(e, t)) ? undefined : i)
        },
        attrHooks: {
            type: {
                set: function (e, t) {
                    if (!ue.radioValue && "radio" === t && he.nodeName(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        removeAttr: function (e, t) {
            var n, i, a = 0,
                s = t && t.match(Me);
            if (s && 1 === e.nodeType)
                for (; n = s[a++];) i = he.propFix[n] || n, he.expr.match.bool.test(n) ? Gt && $t || !Bt.test(n) ? e[i] = !1 : e[he.camelCase("default-" + n)] = e[i] = !1 : he.attr(e, n, ""), e.removeAttribute($t ? n : i)
        }
    }), Pt = {
        set: function (e, t, n) {
            return !1 === t ? he.removeAttr(e, n) : Gt && $t || !Bt.test(n) ? e.setAttribute(!$t && he.propFix[n] || n, n) : e[he.camelCase("default-" + n)] = e[n] = !0, n
        }
    }, he.each(he.expr.match.bool.source.match(/\w+/g), function (e, t) {
        var s = qt[t] || he.find.attr;
        Gt && $t || !Bt.test(t) ? qt[t] = function (e, t, n) {
            var i, a;
            return n || (a = qt[t], qt[t] = i, i = null != s(e, t, n) ? t.toLowerCase() : null, qt[t] = a), i
        } : qt[t] = function (e, t, n) {
            if (!n) return e[he.camelCase("default-" + t)] ? t.toLowerCase() : null
        }
    }), Gt && $t || (he.attrHooks.value = {
        set: function (e, t, n) {
            if (!he.nodeName(e, "input")) return Ht && Ht.set(e, t, n);
            e.defaultValue = t
        }
    }), $t || (Ht = {
        set: function (e, t, n) {
            var i = e.getAttributeNode(n);
            if (i || e.setAttributeNode(i = e.ownerDocument.createAttribute(n)), i.value = t += "", "value" === n || t === e.getAttribute(n)) return t
        }
    }, qt.id = qt.name = qt.coords = function (e, t, n) {
        var i;
        if (!n) return (i = e.getAttributeNode(t)) && "" !== i.value ? i.value : null
    }, he.valHooks.button = {
        get: function (e, t) {
            var n = e.getAttributeNode(t);
            if (n && n.specified) return n.value
        },
        set: Ht.set
    }, he.attrHooks.contenteditable = {
        set: function (e, t, n) {
            Ht.set(e, "" !== t && t, n)
        }
    }, he.each(["width", "height"], function (e, n) {
        he.attrHooks[n] = {
            set: function (e, t) {
                if ("" === t) return e.setAttribute(n, "auto"), t
            }
        }
    })), ue.style || (he.attrHooks.style = {
        get: function (e) {
            return e.style.cssText || undefined
        },
        set: function (e, t) {
            return e.style.cssText = t + ""
        }
    });
    var zt = /^(?:input|select|textarea|button|object)$/i,
        Wt = /^(?:a|area)$/i;
    he.fn.extend({
        prop: function (e, t) {
            return $e(this, he.prop, e, t, 1 < arguments.length)
        },
        removeProp: function (t) {
            return t = he.propFix[t] || t, this.each(function () {
                try {
                    this[t] = undefined, delete this[t]
                } catch (e) {}
            })
        }
    }), he.extend({
        prop: function (e, t, n) {
            var i, a, s = e.nodeType;
            if (3 !== s && 8 !== s && 2 !== s) return 1 === s && he.isXMLDoc(e) || (t = he.propFix[t] || t, a = he.propHooks[t]), n !== undefined ? a && "set" in a && (i = a.set(e, n, t)) !== undefined ? i : e[t] = n : a && "get" in a && null !== (i = a.get(e, t)) ? i : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function (e) {
                    var t = he.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : zt.test(e.nodeName) || Wt.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            "for": "htmlFor",
            "class": "className"
        }
    }), ue.hrefNormalized || he.each(["href", "src"], function (e, t) {
        he.propHooks[t] = {
            get: function (e) {
                return e.getAttribute(t, 4)
            }
        }
    }), ue.optSelected || (he.propHooks.selected = {
        get: function (e) {
            var t = e.parentNode;
            return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
        },
        set: function (e) {
            var t = e.parentNode;
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
        }
    }), he.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
        he.propFix[this.toLowerCase()] = this
    }), ue.enctype || (he.propFix.enctype = "encoding");
    var Yt = /[\t\r\n\f]/g;
    he.fn.extend({
        addClass: function (t) {
            var e, n, i, a, s, o, r, l = 0;
            if (he.isFunction(t)) return this.each(function (e) {
                he(this).addClass(t.call(this, e, z(this)))
            });
            if ("string" == typeof t && t)
                for (e = t.match(Me) || []; n = this[l++];)
                    if (a = z(n), i = 1 === n.nodeType && (" " + a + " ").replace(Yt, " ")) {
                        for (o = 0; s = e[o++];) i.indexOf(" " + s + " ") < 0 && (i += s + " ");
                        a !== (r = he.trim(i)) && he.attr(n, "class", r)
                    } return this
        },
        removeClass: function (t) {
            var e, n, i, a, s, o, r, l = 0;
            if (he.isFunction(t)) return this.each(function (e) {
                he(this).removeClass(t.call(this, e, z(this)))
            });
            if (!arguments.length) return this.attr("class", "");
            if ("string" == typeof t && t)
                for (e = t.match(Me) || []; n = this[l++];)
                    if (a = z(n), i = 1 === n.nodeType && (" " + a + " ").replace(Yt, " ")) {
                        for (o = 0; s = e[o++];)
                            for (; - 1 < i.indexOf(" " + s + " ");) i = i.replace(" " + s + " ", " ");
                        a !== (r = he.trim(i)) && he.attr(n, "class", r)
                    } return this
        },
        toggleClass: function (a, t) {
            var s = typeof a;
            return "boolean" == typeof t && "string" === s ? t ? this.addClass(a) : this.removeClass(a) : he.isFunction(a) ? this.each(function (e) {
                he(this).toggleClass(a.call(this, e, z(this), t), t)
            }) : this.each(function () {
                var e, t, n, i;
                if ("string" === s)
                    for (t = 0, n = he(this), i = a.match(Me) || []; e = i[t++];) n.hasClass(e) ? n.removeClass(e) : n.addClass(e);
                else a !== undefined && "boolean" !== s || ((e = z(this)) && he._data(this, "__className__", e), he.attr(this, "class", e || !1 === a ? "" : he._data(this, "__className__") || ""))
            })
        },
        hasClass: function (e) {
            var t, n, i = 0;
            for (t = " " + e + " "; n = this[i++];)
                if (1 === n.nodeType && -1 < (" " + z(n) + " ").replace(Yt, " ").indexOf(t)) return !0;
            return !1
        }
    }), he.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function (e, n) {
        he.fn[n] = function (e, t) {
            return 0 < arguments.length ? this.on(n, null, e, t) : this.trigger(n)
        }
    }), he.fn.extend({
        hover: function (e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        }
    });
    var Vt = w.location,
        Kt = he.now(),
        Ut = /\?/,
        Xt = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    he.parseJSON = function (e) {
        if (w.JSON && w.JSON.parse) return w.JSON.parse(e + "");
        var a, s = null,
            t = he.trim(e + "");
        return t && !he.trim(t.replace(Xt, function (e, t, n, i) {
            return a && t && (s = 0), 0 === s ? e : (a = n || t, s += !i - !n, "")
        })) ? Function("return " + t)() : he.error("Invalid JSON: " + e)
    }, he.parseXML = function (e) {
        var t;
        if (!e || "string" != typeof e) return null;
        try {
            w.DOMParser ? t = (new w.DOMParser).parseFromString(e, "text/xml") : ((t = new w.ActiveXObject("Microsoft.XMLDOM")).async = "false", t.loadXML(e))
        } catch (n) {
            t = undefined
        }
        return t && t.documentElement && !t.getElementsByTagName("parsererror").length || he.error("Invalid XML: " + e), t
    };
    var Jt = /#.*$/,
        Qt = /([?&])_=[^&]*/,
        Zt = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
        en = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        tn = /^(?:GET|HEAD)$/,
        nn = /^\/\//,
        an = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
        sn = {},
        on = {},
        rn = "*/".concat("*"),
        ln = Vt.href,
        dn = an.exec(ln.toLowerCase()) || [];
    he.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: ln,
            type: "GET",
            isLocal: en.test(dn[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": rn,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": he.parseJSON,
                "text xml": he.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function (e, t) {
            return t ? V(V(e, he.ajaxSettings), t) : V(he.ajaxSettings, e)
        },
        ajaxPrefilter: W(sn),
        ajaxTransport: W(on),
        ajax: function (e, t) {
            function n(e, t, n, i) {
                var a, s, o, r, l, d = t;
                2 !== _ && (_ = 2, p && w.clearTimeout(p), f = undefined, u = i || "", k.readyState = 0 < e ? 4 : 0, a = 200 <= e && e < 300 || 304 === e, n && (r = K(m, k, n)), r = U(m, r, k, a), a ? (m.ifModified && ((l = k.getResponseHeader("Last-Modified")) && (he.lastModified[c] = l), (l = k.getResponseHeader("etag")) && (he.etag[c] = l)), 204 === e || "HEAD" === m.type ? d = "nocontent" : 304 === e ? d = "notmodified" : (d = r.state, s = r.data, a = !(o = r.error))) : (o = d, !e && d || (d = "error", e < 0 && (e = 0))), k.status = e, k.statusText = (t || d) + "", a ? b.resolveWith(g, [s, d, k]) : b.rejectWith(g, [k, d, o]), k.statusCode(x), x = undefined, h && v.trigger(a ? "ajaxSuccess" : "ajaxError", [k, m, a ? s : o]), y.fireWith(g, [k, d]), h && (v.trigger("ajaxComplete", [k, m]), --he.active || he.event.trigger("ajaxStop")))
            }
            "object" == typeof e && (t = e, e = undefined), t = t || {};
            var i, a, c, u, p, h, f, s, m = he.ajaxSetup({}, t),
                g = m.context || m,
                v = m.context && (g.nodeType || g.jquery) ? he(g) : he.event,
                b = he.Deferred(),
                y = he.Callbacks("once memory"),
                x = m.statusCode || {},
                o = {},
                r = {},
                _ = 0,
                l = "canceled",
                k = {
                    readyState: 0,
                    getResponseHeader: function (e) {
                        var t;
                        if (2 === _) {
                            if (!s)
                                for (s = {}; t = Zt.exec(u);) s[t[1].toLowerCase()] = t[2];
                            t = s[e.toLowerCase()]
                        }
                        return null == t ? null : t
                    },
                    getAllResponseHeaders: function () {
                        return 2 === _ ? u : null
                    },
                    setRequestHeader: function (e, t) {
                        var n = e.toLowerCase();
                        return _ || (e = r[n] = r[n] || e, o[e] = t), this
                    },
                    overrideMimeType: function (e) {
                        return _ || (m.mimeType = e), this
                    },
                    statusCode: function (e) {
                        var t;
                        if (e)
                            if (_ < 2)
                                for (t in e) x[t] = [x[t], e[t]];
                            else k.always(e[k.status]);
                        return this
                    },
                    abort: function (e) {
                        var t = e || l;
                        return f && f.abort(t), n(0, t), this
                    }
                };
            if (b.promise(k).complete = y.add, k.success = k.done, k.error = k.fail, m.url = ((e || m.url || ln) + "").replace(Jt, "").replace(nn, dn[1] + "//"), m.type = t.method || t.type || m.method || m.type, m.dataTypes = he.trim(m.dataType || "*").toLowerCase().match(Me) || [""], null == m.crossDomain && (i = an.exec(m.url.toLowerCase()), m.crossDomain = !(!i || i[1] === dn[1] && i[2] === dn[2] && (i[3] || ("http:" === i[1] ? "80" : "443")) === (dn[3] || ("http:" === dn[1] ? "80" : "443")))), m.data && m.processData && "string" != typeof m.data && (m.data = he.param(m.data, m.traditional)), Y(sn, m, t, k), 2 === _) return k;
            for (a in (h = he.event && m.global) && 0 == he.active++ && he.event.trigger("ajaxStart"), m.type = m.type.toUpperCase(), m.hasContent = !tn.test(m.type), c = m.url, m.hasContent || (m.data && (c = m.url += (Ut.test(c) ? "&" : "?") + m.data, delete m.data), !1 === m.cache && (m.url = Qt.test(c) ? c.replace(Qt, "$1_=" + Kt++) : c + (Ut.test(c) ? "&" : "?") + "_=" + Kt++)), m.ifModified && (he.lastModified[c] && k.setRequestHeader("If-Modified-Since", he.lastModified[c]), he.etag[c] && k.setRequestHeader("If-None-Match", he.etag[c])), (m.data && m.hasContent && !1 !== m.contentType || t.contentType) && k.setRequestHeader("Content-Type", m.contentType), k.setRequestHeader("Accept", m.dataTypes[0] && m.accepts[m.dataTypes[0]] ? m.accepts[m.dataTypes[0]] + ("*" !== m.dataTypes[0] ? ", " + rn + "; q=0.01" : "") : m.accepts["*"]), m.headers) k.setRequestHeader(a, m.headers[a]);
            if (m.beforeSend && (!1 === m.beforeSend.call(g, k, m) || 2 === _)) return k.abort();
            for (a in l = "abort", {
                    success: 1,
                    error: 1,
                    complete: 1
                }) k[a](m[a]);
            if (f = Y(on, m, t, k)) {
                if (k.readyState = 1, h && v.trigger("ajaxSend", [k, m]), 2 === _) return k;
                m.async && 0 < m.timeout && (p = w.setTimeout(function () {
                    k.abort("timeout")
                }, m.timeout));
                try {
                    _ = 1, f.send(o, n)
                } catch (d) {
                    if (!(_ < 2)) throw d;
                    n(-1, d)
                }
            } else n(-1, "No Transport");
            return k
        },
        getJSON: function (e, t, n) {
            return he.get(e, t, n, "json")
        },
        getScript: function (e, t) {
            return he.get(e, undefined, t, "script")
        }
    }), he.each(["get", "post"], function (e, a) {
        he[a] = function (e, t, n, i) {
            return he.isFunction(t) && (i = i || n, n = t, t = undefined), he.ajax(he.extend({
                url: e,
                type: a,
                dataType: i,
                data: t,
                success: n
            }, he.isPlainObject(e) && e))
        }
    }), he._evalUrl = function (e) {
        return he.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            "throws": !0
        })
    }, he.fn.extend({
        wrapAll: function (t) {
            if (he.isFunction(t)) return this.each(function (e) {
                he(this).wrapAll(t.call(this, e))
            });
            if (this[0]) {
                var e = he(t, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && e.insertBefore(this[0]), e.map(function () {
                    for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                    return e
                }).append(this)
            }
            return this
        },
        wrapInner: function (n) {
            return he.isFunction(n) ? this.each(function (e) {
                he(this).wrapInner(n.call(this, e))
            }) : this.each(function () {
                var e = he(this),
                    t = e.contents();
                t.length ? t.wrapAll(n) : e.append(n)
            })
        },
        wrap: function (t) {
            var n = he.isFunction(t);
            return this.each(function (e) {
                he(this).wrapAll(n ? t.call(this, e) : t)
            })
        },
        unwrap: function () {
            return this.parent().each(function () {
                he.nodeName(this, "body") || he(this).replaceWith(this.childNodes)
            }).end()
        }
    }), he.expr.filters.hidden = function (e) {
        return ue.reliableHiddenOffsets() ? e.offsetWidth <= 0 && e.offsetHeight <= 0 && !e.getClientRects().length : J(e)
    }, he.expr.filters.visible = function (e) {
        return !he.expr.filters.hidden(e)
    };
    var cn = /%20/g,
        un = /\[\]$/,
        pn = /\r?\n/g,
        hn = /^(?:submit|button|image|reset|file)$/i,
        fn = /^(?:input|select|textarea|keygen)/i;
    he.param = function (e, t) {
        var n, i = [],
            a = function (e, t) {
                t = he.isFunction(t) ? t() : null == t ? "" : t, i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
            };
        if (t === undefined && (t = he.ajaxSettings && he.ajaxSettings.traditional), he.isArray(e) || e.jquery && !he.isPlainObject(e)) he.each(e, function () {
            a(this.name, this.value)
        });
        else
            for (n in e) Q(n, e[n], t, a);
        return i.join("&").replace(cn, "+")
    }, he.fn.extend({
        serialize: function () {
            return he.param(this.serializeArray())
        },
        serializeArray: function () {
            return this.map(function () {
                var e = he.prop(this, "elements");
                return e ? he.makeArray(e) : this
            }).filter(function () {
                var e = this.type;
                return this.name && !he(this).is(":disabled") && fn.test(this.nodeName) && !hn.test(e) && (this.checked || !Ge.test(e))
            }).map(function (e, t) {
                var n = he(this).val();
                return null == n ? null : he.isArray(n) ? he.map(n, function (e) {
                    return {
                        name: t.name,
                        value: e.replace(pn, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(pn, "\r\n")
                }
            }).get()
        }
    }), he.ajaxSettings.xhr = w.ActiveXObject !== undefined ? function () {
        return this.isLocal ? ee() : 8 < ie.documentMode ? Z() : /^(get|post|head|put|delete|options)$/i.test(this.type) && Z() || ee()
    } : Z;
    var mn = 0,
        gn = {},
        vn = he.ajaxSettings.xhr();
    w.attachEvent && w.attachEvent("onunload", function () {
        for (var e in gn) gn[e](undefined, !0)
    }), ue.cors = !!vn && "withCredentials" in vn, (vn = ue.ajax = !!vn) && he.ajaxTransport(function (d) {
        var c;
        if (!d.crossDomain || ue.cors) return {
            send: function (e, o) {
                var t, r = d.xhr(),
                    l = ++mn;
                if (r.open(d.type, d.url, d.async, d.username, d.password), d.xhrFields)
                    for (t in d.xhrFields) r[t] = d.xhrFields[t];
                for (t in d.mimeType && r.overrideMimeType && r.overrideMimeType(d.mimeType), d.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest"), e) e[t] !== undefined && r.setRequestHeader(t, e[t] + "");
                r.send(d.hasContent && d.data || null), c = function (e, t) {
                    var n, i, a;
                    if (c && (t || 4 === r.readyState))
                        if (delete gn[l], c = undefined, r.onreadystatechange = he.noop, t) 4 !== r.readyState && r.abort();
                        else {
                            a = {}, n = r.status, "string" == typeof r.responseText && (a.text = r.responseText);
                            try {
                                i = r.statusText
                            } catch (s) {
                                i = ""
                            }
                            n || !d.isLocal || d.crossDomain ? 1223 === n && (n = 204) : n = a.text ? 200 : 404
                        } a && o(n, i, a, r.getAllResponseHeaders())
                }, d.async ? 4 === r.readyState ? w.setTimeout(c) : r.onreadystatechange = gn[l] = c : c()
            },
            abort: function () {
                c && c(undefined, !0)
            }
        }
    }), he.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function (e) {
                return he.globalEval(e), e
            }
        }
    }), he.ajaxPrefilter("script", function (e) {
        e.cache === undefined && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
    }), he.ajaxTransport("script", function (t) {
        if (t.crossDomain) {
            var i, a = ie.head || he("head")[0] || ie.documentElement;
            return {
                send: function (e, n) {
                    (i = ie.createElement("script")).async = !0, t.scriptCharset && (i.charset = t.scriptCharset), i.src = t.url, i.onload = i.onreadystatechange = function (e, t) {
                        (t || !i.readyState || /loaded|complete/.test(i.readyState)) && (i.onload = i.onreadystatechange = null, i.parentNode && i.parentNode.removeChild(i), i = null, t || n(200, "success"))
                    }, a.insertBefore(i, a.firstChild)
                },
                abort: function () {
                    i && i.onload(undefined, !0)
                }
            }
        }
    });
    var bn = [],
        yn = /(=)\?(?=&|$)|\?\?/;
    he.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function () {
            var e = bn.pop() || he.expando + "_" + Kt++;
            return this[e] = !0, e
        }
    }), he.ajaxPrefilter("json jsonp", function (e, t, n) {
        var i, a, s, o = !1 !== e.jsonp && (yn.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && yn.test(e.data) && "data");
        if (o || "jsonp" === e.dataTypes[0]) return i = e.jsonpCallback = he.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, o ? e[o] = e[o].replace(yn, "$1" + i) : !1 !== e.jsonp && (e.url += (Ut.test(e.url) ? "&" : "?") + e.jsonp + "=" + i), e.converters["script json"] = function () {
            return s || he.error(i + " was not called"), s[0]
        }, e.dataTypes[0] = "json", a = w[i], w[i] = function () {
            s = arguments
        }, n.always(function () {
            a === undefined ? he(w).removeProp(i) : w[i] = a, e[i] && (e.jsonpCallback = t.jsonpCallback, bn.push(i)), s && he.isFunction(a) && a(s[0]), s = a = undefined
        }), "script"
    }), he.parseHTML = function (e, t, n) {
        if (!e || "string" != typeof e) return null;
        "boolean" == typeof t && (n = t, t = !1), t = t || ie;
        var i = ke.exec(e),
            a = !n && [];
        return i ? [t.createElement(i[1])] : (i = m([e], t, a), a && a.length && he(a).remove(), he.merge([], i.childNodes))
    };
    var xn = he.fn.load;
    he.fn.load = function (e, t, n) {
        if ("string" != typeof e && xn) return xn.apply(this, arguments);
        var i, a, s, o = this,
            r = e.indexOf(" ");
        return -1 < r && (i = he.trim(e.slice(r, e.length)), e = e.slice(0, r)), he.isFunction(t) ? (n = t, t = undefined) : t && "object" == typeof t && (a = "POST"), 0 < o.length && he.ajax({
            url: e,
            type: a || "GET",
            dataType: "html",
            data: t
        }).done(function (e) {
            s = arguments, o.html(i ? he("<div>").append(he.parseHTML(e)).find(i) : e)
        }).always(n && function (e, t) {
            o.each(function () {
                n.apply(this, s || [e.responseText, t, e])
            })
        }), this
    }, he.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) {
        he.fn[t] = function (e) {
            return this.on(t, e)
        }
    }), he.expr.filters.animated = function (t) {
        return he.grep(he.timers, function (e) {
            return t === e.elem
        }).length
    }, he.offset = {
        setOffset: function (e, t, n) {
            var i, a, s, o, r, l, d = he.css(e, "position"),
                c = he(e),
                u = {};
            "static" === d && (e.style.position = "relative"), r = c.offset(), s = he.css(e, "top"), l = he.css(e, "left"), ("absolute" === d || "fixed" === d) && -1 < he.inArray("auto", [s, l]) ? (o = (i = c.position()).top, a = i.left) : (o = parseFloat(s) || 0, a = parseFloat(l) || 0), he.isFunction(t) && (t = t.call(e, n, he.extend({}, r))), null != t.top && (u.top = t.top - r.top + o), null != t.left && (u.left = t.left - r.left + a), "using" in t ? t.using.call(e, u) : c.css(u)
        }
    }, he.fn.extend({
        offset: function (t) {
            if (arguments.length) return t === undefined ? this : this.each(function (e) {
                he.offset.setOffset(this, t, e)
            });
            var e, n, i = {
                    top: 0,
                    left: 0
                },
                a = this[0],
                s = a && a.ownerDocument;
            return s ? (e = s.documentElement, he.contains(e, a) ? ("undefined" != typeof a.getBoundingClientRect && (i = a.getBoundingClientRect()), n = te(s), {
                top: i.top + (n.pageYOffset || e.scrollTop) - (e.clientTop || 0),
                left: i.left + (n.pageXOffset || e.scrollLeft) - (e.clientLeft || 0)
            }) : i) : void 0
        },
        position: function () {
            if (this[0]) {
                var e, t, n = {
                        top: 0,
                        left: 0
                    },
                    i = this[0];
                return "fixed" === he.css(i, "position") ? t = i.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), he.nodeName(e[0], "html") || (n = e.offset()), n.top += he.css(e[0], "borderTopWidth", !0), n.left += he.css(e[0], "borderLeftWidth", !0)), {
                    top: t.top - n.top - he.css(i, "marginTop", !0),
                    left: t.left - n.left - he.css(i, "marginLeft", !0)
                }
            }
        },
        offsetParent: function () {
            return this.map(function () {
                for (var e = this.offsetParent; e && !he.nodeName(e, "html") && "static" === he.css(e, "position");) e = e.offsetParent;
                return e || mt
            })
        }
    }), he.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function (t, a) {
        var s = /Y/.test(a);
        he.fn[t] = function (e) {
            return $e(this, function (e, t, n) {
                var i = te(e);
                if (n === undefined) return i ? a in i ? i[a] : i.document.documentElement[t] : e[t];
                i ? i.scrollTo(s ? he(i).scrollLeft() : n, s ? n : he(i).scrollTop()) : e[t] = n
            }, t, e, arguments.length, null)
        }
    }), he.each(["top", "left"], function (e, n) {
        he.cssHooks[n] = A(ue.pixelPosition, function (e, t) {
            if (t) return t = vt(e, n), ht.test(t) ? he(e).position()[n] + "px" : t
        })
    }), he.each({
        Height: "height",
        Width: "width"
    }, function (s, o) {
        he.each({
            padding: "inner" + s,
            content: o,
            "": "outer" + s
        }, function (i, e) {
            he.fn[e] = function (e, t) {
                var n = arguments.length && (i || "boolean" != typeof e),
                    a = i || (!0 === e || !0 === t ? "margin" : "border");
                return $e(this, function (e, t, n) {
                    var i;
                    return he.isWindow(e) ? e.document.documentElement["client" + s] : 9 === e.nodeType ? (i = e.documentElement, Math.max(e.body["scroll" + s], i["scroll" + s], e.body["offset" + s], i["offset" + s], i["client" + s])) : n === undefined ? he.css(e, t, a) : he.style(e, t, n, a)
                }, o, n ? e : undefined, n, null)
            }
        })
    }), he.fn.extend({
        bind: function (e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function (e, t) {
            return this.off(e, null, t)
        },
        delegate: function (e, t, n, i) {
            return this.on(t, e, n, i)
        },
        undelegate: function (e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        }
    }), he.fn.size = function () {
        return this.length
    }, he.fn.andSelf = he.fn.addBack, "function" == typeof define && define.amd && define("jquery", [], function () {
        return he
    });
    var _n = w.jQuery,
        kn = w.$;
    return he.noConflict = function (e) {
        return w.$ === he && (w.$ = kn), e && w.jQuery === he && (w.jQuery = _n), he
    }, e || (w.jQuery = w.$ = he), he
}),
function (c, l) {
    "use strict";
    var d;
    c.rails !== l && c.error("jquery-ujs has already been loaded!");
    var e = c(document);
    c.rails = d = {
        linkClickSelector: "a[data-confirm], a[data-method], a[data-remote]:not([disabled]), a[data-disable-with], a[data-disable]",
        buttonClickSelector: "button[data-remote]:not([form]):not(form button), button[data-confirm]:not([form]):not(form button)",
        inputChangeSelector: "select[data-remote], input[data-remote], textarea[data-remote]",
        formSubmitSelector: "form",
        formInputClickSelector: "form input[type=submit], form input[type=image], form button[type=submit], form button:not([type]), input[type=submit][form], input[type=image][form], button[type=submit][form], button[form]:not([type])",
        disableSelector: "input[data-disable-with]:enabled, button[data-disable-with]:enabled, textarea[data-disable-with]:enabled, input[data-disable]:enabled, button[data-disable]:enabled, textarea[data-disable]:enabled",
        enableSelector: "input[data-disable-with]:disabled, button[data-disable-with]:disabled, textarea[data-disable-with]:disabled, input[data-disable]:disabled, button[data-disable]:disabled, textarea[data-disable]:disabled",
        requiredInputSelector: "input[name][required]:not([disabled]), textarea[name][required]:not([disabled])",
        fileInputSelector: "input[name][type=file]:not([disabled])",
        linkDisableSelector: "a[data-disable-with], a[data-disable]",
        buttonDisableSelector: "button[data-remote][data-disable-with], button[data-remote][data-disable]",
        csrfToken: function () {
            return c("meta[name=csrf-token]").attr("content")
        },
        csrfParam: function () {
            return c("meta[name=csrf-param]").attr("content")
        },
        CSRFProtection: function (e) {
            var t = d.csrfToken();
            t && e.setRequestHeader("X-CSRF-Token", t)
        },
        refreshCSRFTokens: function () {
            c('form input[name="' + d.csrfParam() + '"]').val(d.csrfToken())
        },
        fire: function (e, t, n) {
            var i = c.Event(t);
            return e.trigger(i, n), !1 !== i.result
        },
        confirm: function (e) {
            return confirm(e)
        },
        ajax: function (e) {
            return c.ajax(e)
        },
        href: function (e) {
            return e[0].href
        },
        isRemote: function (e) {
            return e.data("remote") !== l && !1 !== e.data("remote")
        },
        handleRemote: function (i) {
            var e, t, n, a, s, o;
            if (d.fire(i, "ajax:before")) {
                if (a = i.data("with-credentials") || null, s = i.data("type") || c.ajaxSettings && c.ajaxSettings.dataType, i.is("form")) {
                    e = i.data("ujs:submit-button-formmethod") || i.attr("method"), t = i.data("ujs:submit-button-formaction") || i.attr("action"), n = c(i[0]).serializeArray();
                    var r = i.data("ujs:submit-button");
                    r && (n.push(r), i.data("ujs:submit-button", null)), i.data("ujs:submit-button-formmethod", null), i.data("ujs:submit-button-formaction", null)
                } else i.is(d.inputChangeSelector) ? (e = i.data("method"), t = i.data("url"), n = i.serialize(), i.data("params") && (n = n + "&" + i.data("params"))) : i.is(d.buttonClickSelector) ? (e = i.data("method") || "get", t = i.data("url"), n = i.serialize(), i.data("params") && (n = n + "&" + i.data("params"))) : (e = i.data("method"), t = d.href(i), n = i.data("params") || null);
                return o = {
                    type: e || "GET",
                    data: n,
                    dataType: s,
                    beforeSend: function (e, t) {
                        if (t.dataType === l && e.setRequestHeader("accept", "*/*;q=0.5, " + t.accepts.script), !d.fire(i, "ajax:beforeSend", [e, t])) return !1;
                        i.trigger("ajax:send", e)
                    },
                    success: function (e, t, n) {
                        i.trigger("ajax:success", [e, t, n])
                    },
                    complete: function (e, t) {
                        i.trigger("ajax:complete", [e, t])
                    },
                    error: function (e, t, n) {
                        i.trigger("ajax:error", [e, t, n])
                    },
                    crossDomain: d.isCrossDomain(t)
                }, a && (o.xhrFields = {
                    withCredentials: a
                }), t && (o.url = t), d.ajax(o)
            }
            return !1
        },
        isCrossDomain: function (e) {
            var t = document.createElement("a");
            t.href = location.href;
            var n = document.createElement("a");
            try {
                return n.href = e, n.href = n.href, !((!n.protocol || ":" === n.protocol) && !n.host || t.protocol + "//" + t.host == n.protocol + "//" + n.host)
            } catch (i) {
                return !0
            }
        },
        handleMethod: function (e) {
            var t = d.href(e),
                n = e.data("method"),
                i = e.attr("target"),
                a = d.csrfToken(),
                s = d.csrfParam(),
                o = c('<form method="post" action="' + t + '"></form>'),
                r = '<input name="_method" value="' + n + '" type="hidden" />';
            s === l || a === l || d.isCrossDomain(t) || (r += '<input name="' + s + '" value="' + a + '" type="hidden" />'), i && o.attr("target", i), o.hide().append(r).appendTo("body"), o.submit()
        },
        formElements: function (e, t) {
            return e.is("form") ? c(e[0].elements).filter(t) : e.find(t)
        },
        disableFormElements: function (e) {
            d.formElements(e, d.disableSelector).each(function () {
                d.disableFormElement(c(this))
            })
        },
        disableFormElement: function (e) {
            var t, n;
            t = e.is("button") ? "html" : "val", (n = e.data("disable-with")) !== l && (e.data("ujs:enable-with", e[t]()), e[t](n)), e.prop("disabled", !0), e.data("ujs:disabled", !0)
        },
        enableFormElements: function (e) {
            d.formElements(e, d.enableSelector).each(function () {
                d.enableFormElement(c(this))
            })
        },
        enableFormElement: function (e) {
            var t = e.is("button") ? "html" : "val";
            e.data("ujs:enable-with") !== l && (e[t](e.data("ujs:enable-with")), e.removeData("ujs:enable-with")), e.prop("disabled", !1), e.removeData("ujs:disabled")
        },
        allowAction: function (e) {
            var t, n = e.data("confirm"),
                i = !1;
            if (!n) return !0;
            if (d.fire(e, "confirm")) {
                try {
                    i = d.confirm(n)
                } catch (a) {
                    (console.error || console.log).call(console, a.stack || a)
                }
                t = d.fire(e, "confirm:complete", [i])
            }
            return i && t
        },
        blankInputs: function (e, t, n) {
            var i, a, s, o = c(),
                r = t || "input,textarea",
                l = e.find(r),
                d = {};
            return l.each(function () {
                (i = c(this)).is("input[type=radio]") ? (s = i.attr("name"), d[s] || (0 === e.find('input[type=radio]:checked[name="' + s + '"]').length && (a = e.find('input[type=radio][name="' + s + '"]'), o = o.add(a)), d[s] = s)) : (i.is("input[type=checkbox],input[type=radio]") ? i.is(":checked") : !!i.val()) === n && (o = o.add(i))
            }), !!o.length && o
        },
        nonBlankInputs: function (e, t) {
            return d.blankInputs(e, t, !0)
        },
        stopEverything: function (e) {
            return c(e.target).trigger("ujs:everythingStopped"), e.stopImmediatePropagation(), !1
        },
        disableElement: function (e) {
            var t = e.data("disable-with");
            t !== l && (e.data("ujs:enable-with", e.html()), e.html(t)), e.bind("click.railsDisable", function (e) {
                return d.stopEverything(e)
            }), e.data("ujs:disabled", !0)
        },
        enableElement: function (e) {
            e.data("ujs:enable-with") !== l && (e.html(e.data("ujs:enable-with")), e.removeData("ujs:enable-with")), e.unbind("click.railsDisable"), e.removeData("ujs:disabled")
        }
    }, d.fire(e, "rails:attachBindings") && (c.ajaxPrefilter(function (e, t, n) {
        e.crossDomain || d.CSRFProtection(n)
    }), c(window).on("pageshow.rails", function () {
        c(c.rails.enableSelector).each(function () {
            var e = c(this);
            e.data("ujs:disabled") && c.rails.enableFormElement(e)
        }), c(c.rails.linkDisableSelector).each(function () {
            var e = c(this);
            e.data("ujs:disabled") && c.rails.enableElement(e)
        })
    }), e.on("ajax:complete", d.linkDisableSelector, function () {
        d.enableElement(c(this))
    }), e.on("ajax:complete", d.buttonDisableSelector, function () {
        d.enableFormElement(c(this))
    }), e.on("click.rails", d.linkClickSelector, function (e) {
        var t = c(this),
            n = t.data("method"),
            i = t.data("params"),
            a = e.metaKey || e.ctrlKey;
        if (!d.allowAction(t)) return d.stopEverything(e);
        if (!a && t.is(d.linkDisableSelector) && d.disableElement(t), d.isRemote(t)) {
            if (a && (!n || "GET" === n) && !i) return !0;
            var s = d.handleRemote(t);
            return !1 === s ? d.enableElement(t) : s.fail(function () {
                d.enableElement(t)
            }), !1
        }
        return n ? (d.handleMethod(t), !1) : void 0
    }), e.on("click.rails", d.buttonClickSelector, function (e) {
        var t = c(this);
        if (!d.allowAction(t) || !d.isRemote(t)) return d.stopEverything(e);
        t.is(d.buttonDisableSelector) && d.disableFormElement(t);
        var n = d.handleRemote(t);
        return !1 === n ? d.enableFormElement(t) : n.fail(function () {
            d.enableFormElement(t)
        }), !1
    }), e.on("change.rails", d.inputChangeSelector, function (e) {
        var t = c(this);
        return d.allowAction(t) && d.isRemote(t) ? (d.handleRemote(t), !1) : d.stopEverything(e)
    }), e.on("submit.rails", d.formSubmitSelector, function (e) {
        var t, n, i = c(this),
            a = d.isRemote(i);
        if (!d.allowAction(i)) return d.stopEverything(e);
        if (i.attr("novalidate") === l)
            if (i.data("ujs:formnovalidate-button") === l) {
                if ((t = d.blankInputs(i, d.requiredInputSelector, !1)) && d.fire(i, "ajax:aborted:required", [t])) return d.stopEverything(e)
            } else i.data("ujs:formnovalidate-button", l);
        if (a) {
            if (n = d.nonBlankInputs(i, d.fileInputSelector)) {
                setTimeout(function () {
                    d.disableFormElements(i)
                }, 13);
                var s = d.fire(i, "ajax:aborted:file", [n]);
                return s || setTimeout(function () {
                    d.enableFormElements(i)
                }, 13), s
            }
            return d.handleRemote(i), !1
        }
        setTimeout(function () {
            d.disableFormElements(i)
        }, 13)
    }), e.on("click.rails", d.formInputClickSelector, function (e) {
        var t = c(this);
        if (!d.allowAction(t)) return d.stopEverything(e);
        var n = t.attr("name"),
            i = n ? {
                name: n,
                value: t.val()
            } : null,
            a = t.closest("form");
        0 === a.length && (a = c("#" + t.attr("form"))), a.data("ujs:submit-button", i), a.data("ujs:formnovalidate-button", t.attr("formnovalidate")), a.data("ujs:submit-button-formaction", t.attr("formaction")), a.data("ujs:submit-button-formmethod", t.attr("formmethod"))
    }), e.on("ajax:send.rails", d.formSubmitSelector, function (e) {
        this === e.target && d.disableFormElements(c(this))
    }), e.on("ajax:complete.rails", d.formSubmitSelector, function (e) {
        this === e.target && d.enableFormElements(c(this))
    }), c(function () {
        d.refreshCSRFTokens()
    }))
}(jQuery), $.fn.uploadThumbs = function (t) {
        return t = $.extend({
            position: 0,
            imgbreak: !1,
            exclusion: !0,
            checkbox: ":checkbox, label, .checked_images",
            alternate: ".alt"
        }, t || {}), this.change(function () {
            $.fn.uploadThumbs.run.call(this, t)
        }), this.each(function () {
            var e = $(this);
            $.fn.uploadThumbs.exclusion_event.call(e, t)
        }), this
    }, $.fn.uploadThumbs.run = function (n) {
        var i = $(this);
        if ($.fn.uploadThumbs.clear.call(i, n), window.File && window.FileReader && this.files) {
            for (var e = [], t = 0, a = this.files.length; t < a; t++) {
                if ((r = this.files[t]) && (r.type && r.type.match(/^image/) || !r.type && r.name.match(/\.(jp[eg]+|png|gif|bmp)$/i) && $.browser.msie)) {
                    var s = new FileReader;
                    s.onload = function (t) {
                        return function () {
                            var e = '<img src="' + this.result + '" alt="' + t.name + '" title="' + t.name + " (" + Math.round(t.size / 1024) + 'kb)" class="thumb" />';
                            $.fn.uploadThumbs.set.call(i, n, e)
                        }
                    }(r), s.readAsDataURL(r), e.push(r.name)
                }
            }
            var o = e.length ? e.join(", ") : null;
            $.fn.uploadThumbs.exclusion.call(i, n, o)
        } else {
            var r;
            if ((r = this.value) && !r.match("fakepath") && r.match(/\.(jp[eg]+|png|gif|bmp)$/i)) {
                var l = new Image;
                l.src = r, l.onload = function () {
                    var e = this.src.match(/([^\\\/]+)$/) ? RegExp.$1 : "",
                        t = '<img src="' + this.src + '" alt="' + e + '" title="' + this.src + '" class="legacy thumb" />';
                    $.fn.uploadThumbs.set.call(i, n, t)
                }, l.complete && l.onload()
            }
            o = r ? r.match(/([^\\\/]+)$/) ? RegExp.$1 : r : null;
            $.fn.uploadThumbs.exclusion.call(i, n, o)
        }
    }, $.fn.uploadThumbs.clear = function (e) {
        void 0 === this.data("alternate").attr("value") ? this.data("alternate").hide().text("") : this.data("alternate").val("");
        var t = "number" == typeof e.position ? this.siblings("img.thumb") : $(e.position).find("img.thumb");
        t.length && t.not("img.uploaded").next("br").remove().end().remove()
    }, $.fn.uploadThumbs.set = function (e, t) {
        var n = this.parent("label").length,
            i = e.imgbreak ? "<br />\n" : "\n",
            a = 1 == e.position || 3 == e.position ? $(i + t) : $(t + i);
        if (0 == e.position ? this.before(a) : 1 == e.position ? this.after(a) : 2 == e.position ? this.parent().prepend(a) : 3 == e.position ? this.parent().append(a) : $(e.position).append(a).show(), n) {
            var s = $(this);
            a.click(function () {
                return s.click(), !1
            })
        }
    }, $.fn.uploadThumbs.exclusion = function (e, t) {
        void 0 === this.data("alternate").attr("value") ? this.data("alternate").show().text(t || "") : this.data("alternate").show().val(t || ""), e.exclusion && (t ? (this.data("checkbox").attr("checked", !1), this.siblings("img.uploaded").slideUp(), this.data("checkbox").siblings("img.uploaded").slideUp()) : (this.siblings("img.uploaded").slideDown(), this.data("checkbox").siblings("img.uploaded").slideDown()))
    }, $.fn.uploadThumbs.exclusion_event = function (n) {
        var i = this;
        if (!this.data("alternate")) {
            var e = this.siblings(n.alternate);
            0 == e.length && (e = this.parent("label").siblings(n.alternate)), this.data("alternate", e), void 0 === e.attr("value") ? e.hide().text("") : e.val("")
        }
        if (n.exclusion) {
            if (!this.data("checkbox")) {
                var t = this.siblings(n.checkbox);
                0 == t.length && (t = this.parent("label").siblings(n.checkbox)), t.find(":checkbox").length && (t = t.find(":checkbox")), this.data("checkbox", t)
            }
            this.data("checkbox").change(function () {
                var e = $(this);
                if (e.is(":checked")) {
                    $.fn.uploadThumbs.clear.call(i, n), i.siblings("img.uploaded").slideDown(), e.siblings("img.uploaded").slideDown();
                    var t = i.clone();
                    i.replaceWith(t), t.uploadThumbs(n)
                } else i.siblings("img.uploaded").slideUp(), e.siblings("img.uploaded").slideUp()
            })
        }
    },
    function (s) {
        s.fn.extend({
            leanModal: function (e) {
                function a(e) {
                    s("#lean_overlay").fadeOut(200), s(e).css({
                        display: "none"
                    })
                }
                var t = {
                        top: 100,
                        overlay: .5,
                        closeButton: null
                    },
                    n = s("<div id='lean_overlay'></div>");
                return s("body").append(n), e = s.extend(t, e), this.each(function () {
                    var i = e;
                    s(this).click(function (e) {
                        var t = s(this).attr("href");
                        s("#lean_overlay").click(function () {
                            a(t)
                        }), s(i.closeButton).click(function () {
                            a(t)
                        });
                        s(t).outerHeight();
                        var n = s(t).outerWidth();
                        s("#lean_overlay").css({
                            display: "block",
                            opacity: 0
                        }), s("#lean_overlay").fadeTo(200, i.overlay), s(t).css({
                            display: "block",
                            position: "absolute",
                            opacity: 0,
                            "z-index": 11e3,
                            left: "50%",
                            "margin-left": -n / 2 + "px",
                            top: i.top + "px"
                        }), s(t).fadeTo(200, 1), e.preventDefault()
                    })
                })
            }
        })
    }(jQuery),
    function (e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function (w) {
        function i(e, t) {
            var n, i, a, s = e.nodeName.toLowerCase();
            return "area" === s ? (i = (n = e.parentNode).name, !(!e.href || !i || "map" !== n.nodeName.toLowerCase()) && (!!(a = w("img[usemap='#" + i + "']")[0]) && o(a))) : (/^(input|select|textarea|button|object)$/.test(s) ? !e.disabled : "a" === s && e.href || t) && o(e)
        }

        function o(e) {
            return w.expr.filters.visible(e) && !w(e).parents().addBack().filter(function () {
                return "hidden" === w.css(this, "visibility")
            }).length
        }

        function l(e) {
            for (var t, n; e.length && e[0] !== document;) {
                if (("absolute" === (t = e.css("position")) || "relative" === t || "fixed" === t) && (n = parseInt(e.css("zIndex"), 10), !isNaN(n) && 0 !== n)) return n;
                e = e.parent()
            }
            return 0
        }

        function n() {
            this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
                closeText: "Done",
                prevText: "Prev",
                nextText: "Next",
                currentText: "Today",
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                weekHeader: "Wk",
                dateFormat: "mm/dd/yy",
                firstDay: 0,
                isRTL: !1,
                showMonthAfterYear: !1,
                yearSuffix: ""
            }, this._defaults = {
                showOn: "focus",
                showAnim: "fadeIn",
                showOptions: {},
                defaultDate: null,
                appendText: "",
                buttonText: "...",
                buttonImage: "",
                buttonImageOnly: !1,
                hideIfNoPrevNext: !1,
                navigationAsDateFormat: !1,
                gotoCurrent: !1,
                changeMonth: !1,
                changeYear: !1,
                yearRange: "c-10:c+10",
                showOtherMonths: !1,
                selectOtherMonths: !1,
                showWeek: !1,
                calculateWeek: this.iso8601Week,
                shortYearCutoff: "+10",
                minDate: null,
                maxDate: null,
                duration: "fast",
                beforeShowDay: null,
                beforeShow: null,
                onSelect: null,
                onChangeMonthYear: null,
                onClose: null,
                numberOfMonths: 1,
                showCurrentAtPos: 0,
                stepMonths: 1,
                stepBigMonths: 12,
                altField: "",
                altFormat: "",
                constrainInput: !0,
                showButtonPanel: !1,
                autoSize: !1,
                disabled: !1
            }, w.extend(this._defaults, this.regional[""]), this.regional.en = w.extend(!0, {}, this.regional[""]), this.regional["en-US"] = w.extend(!0, {}, this.regional.en), this.dpDiv = a(w("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
        }

        function a(e) {
            var t = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
            return e.delegate(t, "mouseout", function () {
                w(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && w(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && w(this).removeClass("ui-datepicker-next-hover")
            }).delegate(t, "mouseover", r)
        }

        function r() {
            w.datepicker._isDisabledDatepicker(c.inline ? c.dpDiv.parent()[0] : c.input[0]) || (w(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), w(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && w(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && w(this).addClass("ui-datepicker-next-hover"))
        }

        function u(e, t) {
            for (var n in w.extend(e, t), t) null == t[n] && (e[n] = t[n]);
            return e
        }
        var e, s, t, d, c;
        w.ui = w.ui || {}, w.extend(w.ui, {
            version: "1.11.4",
            keyCode: {
                BACKSPACE: 8,
                COMMA: 188,
                DELETE: 46,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                ESCAPE: 27,
                HOME: 36,
                LEFT: 37,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                PERIOD: 190,
                RIGHT: 39,
                SPACE: 32,
                TAB: 9,
                UP: 38
            }
        }), w.fn.extend({
            scrollParent: function (e) {
                var t = this.css("position"),
                    n = "absolute" === t,
                    i = e ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                    a = this.parents().filter(function () {
                        var e = w(this);
                        return (!n || "static" !== e.css("position")) && i.test(e.css("overflow") + e.css("overflow-y") + e.css("overflow-x"))
                    }).eq(0);
                return "fixed" !== t && a.length ? a : w(this[0].ownerDocument || document)
            },
            uniqueId: (d = 0, function () {
                return this.each(function () {
                    this.id || (this.id = "ui-id-" + ++d)
                })
            }),
            removeUniqueId: function () {
                return this.each(function () {
                    /^ui-id-\d+$/.test(this.id) && w(this).removeAttr("id")
                })
            }
        }), w.extend(w.expr[":"], {
            data: w.expr.createPseudo ? w.expr.createPseudo(function (t) {
                return function (e) {
                    return !!w.data(e, t)
                }
            }) : function (e, t, n) {
                return !!w.data(e, n[3])
            },
            focusable: function (e) {
                return i(e, !isNaN(w.attr(e, "tabindex")))
            },
            tabbable: function (e) {
                var t = w.attr(e, "tabindex"),
                    n = isNaN(t);
                return (n || 0 <= t) && i(e, !n)
            }
        }), w("<a>").outerWidth(1).jquery || w.each(["Width", "Height"], function (e, n) {
            function i(e, t, n, i) {
                return w.each(a, function () {
                    t -= parseFloat(w.css(e, "padding" + this)) || 0, n && (t -= parseFloat(w.css(e, "border" + this + "Width")) || 0), i && (t -= parseFloat(w.css(e, "margin" + this)) || 0)
                }), t
            }
            var a = "Width" === n ? ["Left", "Right"] : ["Top", "Bottom"],
                s = n.toLowerCase(),
                o = {
                    innerWidth: w.fn.innerWidth,
                    innerHeight: w.fn.innerHeight,
                    outerWidth: w.fn.outerWidth,
                    outerHeight: w.fn.outerHeight
                };
            w.fn["inner" + n] = function (e) {
                return void 0 === e ? o["inner" + n].call(this) : this.each(function () {
                    w(this).css(s, i(this, e) + "px")
                })
            }, w.fn["outer" + n] = function (e, t) {
                return "number" != typeof e ? o["outer" + n].call(this, e) : this.each(function () {
                    w(this).css(s, i(this, e, !0, t) + "px")
                })
            }
        }), w.fn.addBack || (w.fn.addBack = function (e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }), w("<a>").data("a-b", "a").removeData("a-b").data("a-b") && (w.fn.removeData = (t = w.fn.removeData, function (e) {
            return arguments.length ? t.call(this, w.camelCase(e)) : t.call(this)
        })), w.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()), w.fn.extend({
            focus: (s = w.fn.focus, function (t, n) {
                return "number" == typeof t ? this.each(function () {
                    var e = this;
                    setTimeout(function () {
                        w(e).focus(), n && n.call(e)
                    }, t)
                }) : s.apply(this, arguments)
            }),
            disableSelection: (e = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown", function () {
                return this.bind(e + ".ui-disableSelection", function (e) {
                    e.preventDefault()
                })
            }),
            enableSelection: function () {
                return this.unbind(".ui-disableSelection")
            },
            zIndex: function (e) {
                if (void 0 !== e) return this.css("zIndex", e);
                if (this.length)
                    for (var t, n, i = w(this[0]); i.length && i[0] !== document;) {
                        if (("absolute" === (t = i.css("position")) || "relative" === t || "fixed" === t) && (n = parseInt(i.css("zIndex"), 10), !isNaN(n) && 0 !== n)) return n;
                        i = i.parent()
                    }
                return 0
            }
        }), w.ui.plugin = {
            add: function (e, t, n) {
                var i, a = w.ui[e].prototype;
                for (i in n) a.plugins[i] = a.plugins[i] || [], a.plugins[i].push([t, n[i]])
            },
            call: function (e, t, n, i) {
                var a, s = e.plugins[t];
                if (s && (i || e.element[0].parentNode && 11 !== e.element[0].parentNode.nodeType))
                    for (a = 0; s.length > a; a++) e.options[s[a][0]] && s[a][1].apply(e.element, n)
            }
        }, w.extend(w.ui, {
            datepicker: {
                version: "1.11.4"
            }
        }), w.extend(n.prototype, {
            markerClassName: "hasDatepicker",
            maxRows: 4,
            _widgetDatepicker: function () {
                return this.dpDiv
            },
            setDefaults: function (e) {
                return u(this._defaults, e || {}), this
            },
            _attachDatepicker: function (e, t) {
                var n, i, a;
                i = "div" === (n = e.nodeName.toLowerCase()) || "span" === n, e.id || (this.uuid += 1, e.id = "dp" + this.uuid), (a = this._newInst(w(e), i)).settings = w.extend({}, t || {}), "input" === n ? this._connectDatepicker(e, a) : i && this._inlineDatepicker(e, a)
            },
            _newInst: function (e, t) {
                return {
                    id: e[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1"),
                    input: e,
                    selectedDay: 0,
                    selectedMonth: 0,
                    selectedYear: 0,
                    drawMonth: 0,
                    drawYear: 0,
                    inline: t,
                    dpDiv: t ? a(w("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
                }
            },
            _connectDatepicker: function (e, t) {
                var n = w(e);
                t.append = w([]), t.trigger = w([]), n.hasClass(this.markerClassName) || (this._attachments(n, t), n.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp), this._autoSize(t), w.data(e, "datepicker", t), t.settings.disabled && this._disableDatepicker(e))
            },
            _attachments: function (e, t) {
                var n, i, a, s = this._get(t, "appendText"),
                    o = this._get(t, "isRTL");
                t.append && t.append.remove(), s && (t.append = w("<span class='" + this._appendClass + "'>" + s + "</span>"), e[o ? "before" : "after"](t.append)), e.unbind("focus", this._showDatepicker), t.trigger && t.trigger.remove(), ("focus" === (n = this._get(t, "showOn")) || "both" === n) && e.focus(this._showDatepicker), ("button" === n || "both" === n) && (i = this._get(t, "buttonText"), a = this._get(t, "buttonImage"), t.trigger = w(this._get(t, "buttonImageOnly") ? w("<img/>").addClass(this._triggerClass).attr({
                    src: a,
                    alt: i,
                    title: i
                }) : w("<button type='button'></button>").addClass(this._triggerClass).html(a ? w("<img/>").attr({
                    src: a,
                    alt: i,
                    title: i
                }) : i)), e[o ? "before" : "after"](t.trigger), t.trigger.click(function () {
                    return w.datepicker._datepickerShowing && w.datepicker._lastInput === e[0] ? w.datepicker._hideDatepicker() : (w.datepicker._datepickerShowing && w.datepicker._lastInput !== e[0] && w.datepicker._hideDatepicker(), w.datepicker._showDatepicker(e[0])), !1
                }))
            },
            _autoSize: function (e) {
                if (this._get(e, "autoSize") && !e.inline) {
                    var t, n, i, a, s = new Date(2009, 11, 20),
                        o = this._get(e, "dateFormat");
                    o.match(/[DM]/) && (t = function (e) {
                        for (a = i = n = 0; e.length > a; a++) e[a].length > n && (n = e[a].length, i = a);
                        return i
                    }, s.setMonth(t(this._get(e, o.match(/MM/) ? "monthNames" : "monthNamesShort"))), s.setDate(t(this._get(e, o.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - s.getDay())), e.input.attr("size", this._formatDate(e, s).length)
                }
            },
            _inlineDatepicker: function (e, t) {
                var n = w(e);
                n.hasClass(this.markerClassName) || (n.addClass(this.markerClassName).append(t.dpDiv), w.data(e, "datepicker", t), this._setDate(t, this._getDefaultDate(t), !0), this._updateDatepicker(t), this._updateAlternate(t), t.settings.disabled && this._disableDatepicker(e), t.dpDiv.css("display", "block"))
            },
            _dialogDatepicker: function (e, t, n, i, a) {
                var s, o, r, l, d, c = this._dialogInst;
                return c || (this.uuid += 1, s = "dp" + this.uuid, this._dialogInput = w("<input type='text' id='" + s + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.keydown(this._doKeyDown), w("body").append(this._dialogInput), (c = this._dialogInst = this._newInst(this._dialogInput, !1)).settings = {}, w.data(this._dialogInput[0], "datepicker", c)), u(c.settings, i || {}), t = t && t.constructor === Date ? this._formatDate(c, t) : t, this._dialogInput.val(t), this._pos = a ? a.length ? a : [a.pageX, a.pageY] : null, this._pos || (o = document.documentElement.clientWidth, r = document.documentElement.clientHeight, l = document.documentElement.scrollLeft || document.body.scrollLeft, d = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [o / 2 - 100 + l, r / 2 - 150 + d]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), c.settings.onSelect = n, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), w.blockUI && w.blockUI(this.dpDiv), w.data(this._dialogInput[0], "datepicker", c), this
            },
            _destroyDatepicker: function (e) {
                var t, n = w(e),
                    i = w.data(e, "datepicker");
                n.hasClass(this.markerClassName) && (t = e.nodeName.toLowerCase(), w.removeData(e, "datepicker"), "input" === t ? (i.append.remove(), i.trigger.remove(), n.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp)) : ("div" === t || "span" === t) && n.removeClass(this.markerClassName).empty(), c === i && (c = null))
            },
            _enableDatepicker: function (t) {
                var e, n, i = w(t),
                    a = w.data(t, "datepicker");
                i.hasClass(this.markerClassName) && ("input" === (e = t.nodeName.toLowerCase()) ? (t.disabled = !1, a.trigger.filter("button").each(function () {
                    this.disabled = !1
                }).end().filter("img").css({
                    opacity: "1.0",
                    cursor: ""
                })) : ("div" === e || "span" === e) && ((n = i.children("." + this._inlineClass)).children().removeClass("ui-state-disabled"), n.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)), this._disabledInputs = w.map(this._disabledInputs, function (e) {
                    return e === t ? null : e
                }))
            },
            _disableDatepicker: function (t) {
                var e, n, i = w(t),
                    a = w.data(t, "datepicker");
                i.hasClass(this.markerClassName) && ("input" === (e = t.nodeName.toLowerCase()) ? (t.disabled = !0, a.trigger.filter("button").each(function () {
                    this.disabled = !0
                }).end().filter("img").css({
                    opacity: "0.5",
                    cursor: "default"
                })) : ("div" === e || "span" === e) && ((n = i.children("." + this._inlineClass)).children().addClass("ui-state-disabled"), n.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)), this._disabledInputs = w.map(this._disabledInputs, function (e) {
                    return e === t ? null : e
                }), this._disabledInputs[this._disabledInputs.length] = t)
            },
            _isDisabledDatepicker: function (e) {
                if (!e) return !1;
                for (var t = 0; this._disabledInputs.length > t; t++)
                    if (this._disabledInputs[t] === e) return !0;
                return !1
            },
            _getInst: function (e) {
                try {
                    return w.data(e, "datepicker")
                } catch (o) {
                    throw "Missing instance data for this datepicker"
                }
            },
            _optionDatepicker: function (e, t, n) {
                var i, a, s, o, r = this._getInst(e);
                return 2 === arguments.length && "string" == typeof t ? "defaults" === t ? w.extend({}, w.datepicker._defaults) : r ? "all" === t ? w.extend({}, r.settings) : this._get(r, t) : null : (i = t || {}, "string" == typeof t && ((i = {})[t] = n), void(r && (this._curInst === r && this._hideDatepicker(), a = this._getDateDatepicker(e, !0), s = this._getMinMaxDate(r, "min"), o = this._getMinMaxDate(r, "max"), u(r.settings, i), null !== s && void 0 !== i.dateFormat && void 0 === i.minDate && (r.settings.minDate = this._formatDate(r, s)), null !== o && void 0 !== i.dateFormat && void 0 === i.maxDate && (r.settings.maxDate = this._formatDate(r, o)), "disabled" in i && (i.disabled ? this._disableDatepicker(e) : this._enableDatepicker(e)), this._attachments(w(e), r), this._autoSize(r), this._setDate(r, a), this._updateAlternate(r), this._updateDatepicker(r))))
            },
            _changeDatepicker: function (e, t, n) {
                this._optionDatepicker(e, t, n)
            },
            _refreshDatepicker: function (e) {
                var t = this._getInst(e);
                t && this._updateDatepicker(t)
            },
            _setDateDatepicker: function (e, t) {
                var n = this._getInst(e);
                n && (this._setDate(n, t), this._updateDatepicker(n), this._updateAlternate(n))
            },
            _getDateDatepicker: function (e, t) {
                var n = this._getInst(e);
                return n && !n.inline && this._setDateFromField(n, t), n ? this._getDate(n) : null
            },
            _doKeyDown: function (e) {
                var t, n, i, a = w.datepicker._getInst(e.target),
                    s = !0,
                    o = a.dpDiv.is(".ui-datepicker-rtl");
                if (a._keyEvent = !0, w.datepicker._datepickerShowing) switch (e.keyCode) {
                    case 9:
                        w.datepicker._hideDatepicker(), s = !1;
                        break;
                    case 13:
                        return (i = w("td." + w.datepicker._dayOverClass + ":not(." + w.datepicker._currentClass + ")", a.dpDiv))[0] && w.datepicker._selectDay(e.target, a.selectedMonth, a.selectedYear, i[0]), (t = w.datepicker._get(a, "onSelect")) ? (n = w.datepicker._formatDate(a), t.apply(a.input ? a.input[0] : null, [n, a])) : w.datepicker._hideDatepicker(), !1;
                    case 27:
                        w.datepicker._hideDatepicker();
                        break;
                    case 33:
                        w.datepicker._adjustDate(e.target, e.ctrlKey ? -w.datepicker._get(a, "stepBigMonths") : -w.datepicker._get(a, "stepMonths"), "M");
                        break;
                    case 34:
                        w.datepicker._adjustDate(e.target, e.ctrlKey ? +w.datepicker._get(a, "stepBigMonths") : +w.datepicker._get(a, "stepMonths"), "M");
                        break;
                    case 35:
                        (e.ctrlKey || e.metaKey) && w.datepicker._clearDate(e.target), s = e.ctrlKey || e.metaKey;
                        break;
                    case 36:
                        (e.ctrlKey || e.metaKey) && w.datepicker._gotoToday(e.target), s = e.ctrlKey || e.metaKey;
                        break;
                    case 37:
                        (e.ctrlKey || e.metaKey) && w.datepicker._adjustDate(e.target, o ? 1 : -1, "D"), s = e.ctrlKey || e.metaKey, e.originalEvent.altKey && w.datepicker._adjustDate(e.target, e.ctrlKey ? -w.datepicker._get(a, "stepBigMonths") : -w.datepicker._get(a, "stepMonths"), "M");
                        break;
                    case 38:
                        (e.ctrlKey || e.metaKey) && w.datepicker._adjustDate(e.target, -7, "D"), s = e.ctrlKey || e.metaKey;
                        break;
                    case 39:
                        (e.ctrlKey || e.metaKey) && w.datepicker._adjustDate(e.target, o ? -1 : 1, "D"), s = e.ctrlKey || e.metaKey, e.originalEvent.altKey && w.datepicker._adjustDate(e.target, e.ctrlKey ? +w.datepicker._get(a, "stepBigMonths") : +w.datepicker._get(a, "stepMonths"), "M");
                        break;
                    case 40:
                        (e.ctrlKey || e.metaKey) && w.datepicker._adjustDate(e.target, 7, "D"), s = e.ctrlKey || e.metaKey;
                        break;
                    default:
                        s = !1
                } else 36 === e.keyCode && e.ctrlKey ? w.datepicker._showDatepicker(this) : s = !1;
                s && (e.preventDefault(), e.stopPropagation())
            },
            _doKeyPress: function (e) {
                var t, n, i = w.datepicker._getInst(e.target);
                return w.datepicker._get(i, "constrainInput") ? (t = w.datepicker._possibleChars(w.datepicker._get(i, "dateFormat")), n = String.fromCharCode(null == e.charCode ? e.keyCode : e.charCode), e.ctrlKey || e.metaKey || n < " " || !t || -1 < t.indexOf(n)) : void 0
            },
            _doKeyUp: function (e) {
                var t = w.datepicker._getInst(e.target);
                if (t.input.val() !== t.lastVal) try {
                    w.datepicker.parseDate(w.datepicker._get(t, "dateFormat"), t.input ? t.input.val() : null, w.datepicker._getFormatConfig(t)) && (w.datepicker._setDateFromField(t), w.datepicker._updateAlternate(t), w.datepicker._updateDatepicker(t))
                } catch (n) {}
                return !0
            },
            _showDatepicker: function (e) {
                var t, n, i, a, s, o, r;
                ("input" !== (e = e.target || e).nodeName.toLowerCase() && (e = w("input", e.parentNode)[0]), w.datepicker._isDisabledDatepicker(e) || w.datepicker._lastInput === e) || (t = w.datepicker._getInst(e), w.datepicker._curInst && w.datepicker._curInst !== t && (w.datepicker._curInst.dpDiv.stop(!0, !0), t && w.datepicker._datepickerShowing && w.datepicker._hideDatepicker(w.datepicker._curInst.input[0])), !1 !== (i = (n = w.datepicker._get(t, "beforeShow")) ? n.apply(e, [e, t]) : {}) && (u(t.settings, i), t.lastVal = null, w.datepicker._lastInput = e, w.datepicker._setDateFromField(t), w.datepicker._inDialog && (e.value = ""), w.datepicker._pos || (w.datepicker._pos = w.datepicker._findPos(e), w.datepicker._pos[1] += e.offsetHeight), a = !1, w(e).parents().each(function () {
                    return !(a |= "fixed" === w(this).css("position"))
                }), s = {
                    left: w.datepicker._pos[0],
                    top: w.datepicker._pos[1]
                }, w.datepicker._pos = null, t.dpDiv.empty(), t.dpDiv.css({
                    position: "absolute",
                    display: "block",
                    top: "-1000px"
                }), w.datepicker._updateDatepicker(t), s = w.datepicker._checkOffset(t, s, a), t.dpDiv.css({
                    position: w.datepicker._inDialog && w.blockUI ? "static" : a ? "fixed" : "absolute",
                    display: "none",
                    left: s.left + "px",
                    top: s.top + "px"
                }), t.inline || (o = w.datepicker._get(t, "showAnim"), r = w.datepicker._get(t, "duration"), t.dpDiv.css("z-index", l(w(e)) + 1), w.datepicker._datepickerShowing = !0, w.effects && w.effects.effect[o] ? t.dpDiv.show(o, w.datepicker._get(t, "showOptions"), r) : t.dpDiv[o || "show"](o ? r : null), w.datepicker._shouldFocusInput(t) && t.input.focus(), w.datepicker._curInst = t)))
            },
            _updateDatepicker: function (e) {
                this.maxRows = 4, (c = e).dpDiv.empty().append(this._generateHTML(e)), this._attachHandlers(e);
                var t, n = this._getNumberOfMonths(e),
                    i = n[1],
                    a = 17,
                    s = e.dpDiv.find("." + this._dayOverClass + " a");
                0 < s.length && r.apply(s.get(0)), e.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), 1 < i && e.dpDiv.addClass("ui-datepicker-multi-" + i).css("width", a * i + "em"), e.dpDiv[(1 !== n[0] || 1 !== n[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), e.dpDiv[(this._get(e, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), e === w.datepicker._curInst && w.datepicker._datepickerShowing && w.datepicker._shouldFocusInput(e) && e.input.focus(), e.yearshtml && (t = e.yearshtml, setTimeout(function () {
                    t === e.yearshtml && e.yearshtml && e.dpDiv.find("select.ui-datepicker-year:first").replaceWith(e.yearshtml), t = e.yearshtml = null
                }, 0))
            },
            _shouldFocusInput: function (e) {
                return e.input && e.input.is(":visible") && !e.input.is(":disabled") && !e.input.is(":focus")
            },
            _checkOffset: function (e, t, n) {
                var i = e.dpDiv.outerWidth(),
                    a = e.dpDiv.outerHeight(),
                    s = e.input ? e.input.outerWidth() : 0,
                    o = e.input ? e.input.outerHeight() : 0,
                    r = document.documentElement.clientWidth + (n ? 0 : w(document).scrollLeft()),
                    l = document.documentElement.clientHeight + (n ? 0 : w(document).scrollTop());
                return t.left -= this._get(e, "isRTL") ? i - s : 0, t.left -= n && t.left === e.input.offset().left ? w(document).scrollLeft() : 0, t.top -= n && t.top === e.input.offset().top + o ? w(document).scrollTop() : 0, t.left -= Math.min(t.left, t.left + i > r && i < r ? Math.abs(t.left + i - r) : 0), t.top -= Math.min(t.top, t.top + a > l && a < l ? Math.abs(a + o) : 0), t
            },
            _findPos: function (e) {
                for (var t, n = this._getInst(e), i = this._get(n, "isRTL"); e && ("hidden" === e.type || 1 !== e.nodeType || w.expr.filters.hidden(e));) e = e[i ? "previousSibling" : "nextSibling"];
                return [(t = w(e).offset()).left, t.top]
            },
            _hideDatepicker: function (e) {
                var t, n, i, a, s = this._curInst;
                !s || e && s !== w.data(e, "datepicker") || this._datepickerShowing && (t = this._get(s, "showAnim"), n = this._get(s, "duration"), i = function () {
                    w.datepicker._tidyDialog(s)
                }, w.effects && (w.effects.effect[t] || w.effects[t]) ? s.dpDiv.hide(t, w.datepicker._get(s, "showOptions"), n, i) : s.dpDiv["slideDown" === t ? "slideUp" : "fadeIn" === t ? "fadeOut" : "hide"](t ? n : null, i), t || i(), this._datepickerShowing = !1, (a = this._get(s, "onClose")) && a.apply(s.input ? s.input[0] : null, [s.input ? s.input.val() : "", s]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
                    position: "absolute",
                    left: "0",
                    top: "-100px"
                }), w.blockUI && (w.unblockUI(), w("body").append(this.dpDiv))), this._inDialog = !1)
            },
            _tidyDialog: function (e) {
                e.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
            },
            _checkExternalClick: function (e) {
                if (w.datepicker._curInst) {
                    var t = w(e.target),
                        n = w.datepicker._getInst(t[0]);
                    (t[0].id !== w.datepicker._mainDivId && 0 === t.parents("#" + w.datepicker._mainDivId).length && !t.hasClass(w.datepicker.markerClassName) && !t.closest("." + w.datepicker._triggerClass).length && w.datepicker._datepickerShowing && (!w.datepicker._inDialog || !w.blockUI) || t.hasClass(w.datepicker.markerClassName) && w.datepicker._curInst !== n) && w.datepicker._hideDatepicker()
                }
            },
            _adjustDate: function (e, t, n) {
                var i = w(e),
                    a = this._getInst(i[0]);
                this._isDisabledDatepicker(i[0]) || (this._adjustInstDate(a, t + ("M" === n ? this._get(a, "showCurrentAtPos") : 0), n), this._updateDatepicker(a))
            },
            _gotoToday: function (e) {
                var t, n = w(e),
                    i = this._getInst(n[0]);
                this._get(i, "gotoCurrent") && i.currentDay ? (i.selectedDay = i.currentDay, i.drawMonth = i.selectedMonth = i.currentMonth, i.drawYear = i.selectedYear = i.currentYear) : (t = new Date, i.selectedDay = t.getDate(), i.drawMonth = i.selectedMonth = t.getMonth(), i.drawYear = i.selectedYear = t.getFullYear()), this._notifyChange(i), this._adjustDate(n)
            },
            _selectMonthYear: function (e, t, n) {
                var i = w(e),
                    a = this._getInst(i[0]);
                a["selected" + ("M" === n ? "Month" : "Year")] = a["draw" + ("M" === n ? "Month" : "Year")] = parseInt(t.options[t.selectedIndex].value, 10), this._notifyChange(a), this._adjustDate(i)
            },
            _selectDay: function (e, t, n, i) {
                var a, s = w(e);
                w(i).hasClass(this._unselectableClass) || this._isDisabledDatepicker(s[0]) || ((a = this._getInst(s[0])).selectedDay = a.currentDay = w("a", i).html(), a.selectedMonth = a.currentMonth = t, a.selectedYear = a.currentYear = n, this._selectDate(e, this._formatDate(a, a.currentDay, a.currentMonth, a.currentYear)))
            },
            _clearDate: function (e) {
                var t = w(e);
                this._selectDate(t, "")
            },
            _selectDate: function (e, t) {
                var n, i = w(e),
                    a = this._getInst(i[0]);
                t = null != t ? t : this._formatDate(a), a.input && a.input.val(t), this._updateAlternate(a), (n = this._get(a, "onSelect")) ? n.apply(a.input ? a.input[0] : null, [t, a]) : a.input && a.input.trigger("change"), a.inline ? this._updateDatepicker(a) : (this._hideDatepicker(), this._lastInput = a.input[0], "object" != typeof a.input[0] && a.input.focus(), this._lastInput = null)
            },
            _updateAlternate: function (e) {
                var t, n, i, a = this._get(e, "altField");
                a && (t = this._get(e, "altFormat") || this._get(e, "dateFormat"), n = this._getDate(e), i = this.formatDate(t, n, this._getFormatConfig(e)), w(a).each(function () {
                    w(this).val(i)
                }))
            },
            noWeekends: function (e) {
                var t = e.getDay();
                return [0 < t && t < 6, ""]
            },
            iso8601Week: function (e) {
                var t, n = new Date(e.getTime());
                return n.setDate(n.getDate() + 4 - (n.getDay() || 7)), t = n.getTime(), n.setMonth(0), n.setDate(1), Math.floor(Math.round((t - n) / 864e5) / 7) + 1
            },
            parseDate: function (n, s, e) {
                if (null == n || null == s) throw "Invalid arguments";
                if ("" === (s = "object" == typeof s ? "" + s : s + "")) return null;
                var i, t, a, o, r = 0,
                    l = (e ? e.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                    d = "string" != typeof l ? l : (new Date).getFullYear() % 100 + parseInt(l, 10),
                    c = (e ? e.dayNamesShort : null) || this._defaults.dayNamesShort,
                    u = (e ? e.dayNames : null) || this._defaults.dayNames,
                    p = (e ? e.monthNamesShort : null) || this._defaults.monthNamesShort,
                    h = (e ? e.monthNames : null) || this._defaults.monthNames,
                    f = -1,
                    m = -1,
                    g = -1,
                    v = -1,
                    b = !1,
                    y = function (e) {
                        var t = n.length > i + 1 && n.charAt(i + 1) === e;
                        return t && i++, t
                    },
                    x = function (e) {
                        var t = y(e),
                            n = "@" === e ? 14 : "!" === e ? 20 : "y" === e && t ? 4 : "o" === e ? 3 : 2,
                            i = RegExp("^\\d{" + ("y" === e ? n : 1) + "," + n + "}"),
                            a = s.substring(r).match(i);
                        if (!a) throw "Missing number at position " + r;
                        return r += a[0].length, parseInt(a[0], 10)
                    },
                    _ = function (e, t, n) {
                        var i = -1,
                            a = w.map(y(e) ? n : t, function (e, t) {
                                return [[t, e]]
                            }).sort(function (e, t) {
                                return -(e[1].length - t[1].length)
                            });
                        if (w.each(a, function (e, t) {
                                var n = t[1];
                                return s.substr(r, n.length).toLowerCase() === n.toLowerCase() ? (i = t[0], r += n.length, !1) : void 0
                            }), -1 !== i) return i + 1;
                        throw "Unknown name at position " + r
                    },
                    k = function () {
                        if (s.charAt(r) !== n.charAt(i)) throw "Unexpected literal at position " + r;
                        r++
                    };
                for (i = 0; n.length > i; i++)
                    if (b) "'" !== n.charAt(i) || y("'") ? k() : b = !1;
                    else switch (n.charAt(i)) {
                        case "d":
                            g = x("d");
                            break;
                        case "D":
                            _("D", c, u);
                            break;
                        case "o":
                            v = x("o");
                            break;
                        case "m":
                            m = x("m");
                            break;
                        case "M":
                            m = _("M", p, h);
                            break;
                        case "y":
                            f = x("y");
                            break;
                        case "@":
                            f = (o = new Date(x("@"))).getFullYear(), m = o.getMonth() + 1, g = o.getDate();
                            break;
                        case "!":
                            f = (o = new Date((x("!") - this._ticksTo1970) / 1e4)).getFullYear(), m = o.getMonth() + 1, g = o.getDate();
                            break;
                        case "'":
                            y("'") ? k() : b = !0;
                            break;
                        default:
                            k()
                    }
                if (s.length > r && (a = s.substr(r), !/^\s+/.test(a))) throw "Extra/unparsed characters found in date: " + a;
                if (-1 === f ? f = (new Date).getFullYear() : f < 100 && (f += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (f <= d ? 0 : -100)), -1 < v)
                    for (m = 1, g = v; !(g <= (t = this._getDaysInMonth(f, m - 1)));) m++, g -= t;
                if ((o = this._daylightSavingAdjust(new Date(f, m - 1, g))).getFullYear() !== f || o.getMonth() + 1 !== m || o.getDate() !== g) throw "Invalid date";
                return o
            },
            ATOM: "yy-mm-dd",
            COOKIE: "D, dd M yy",
            ISO_8601: "yy-mm-dd",
            RFC_822: "D, d M y",
            RFC_850: "DD, dd-M-y",
            RFC_1036: "D, d M y",
            RFC_1123: "D, d M yy",
            RFC_2822: "D, d M yy",
            RSS: "D, d M y",
            TICKS: "!",
            TIMESTAMP: "@",
            W3C: "yy-mm-dd",
            _ticksTo1970: 864e9 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)),
            formatDate: function (n, e, t) {
                if (!e) return "";
                var i, a = (t ? t.dayNamesShort : null) || this._defaults.dayNamesShort,
                    s = (t ? t.dayNames : null) || this._defaults.dayNames,
                    o = (t ? t.monthNamesShort : null) || this._defaults.monthNamesShort,
                    r = (t ? t.monthNames : null) || this._defaults.monthNames,
                    l = function (e) {
                        var t = n.length > i + 1 && n.charAt(i + 1) === e;
                        return t && i++, t
                    },
                    d = function (e, t, n) {
                        var i = "" + t;
                        if (l(e))
                            for (; n > i.length;) i = "0" + i;
                        return i
                    },
                    c = function (e, t, n, i) {
                        return l(e) ? i[t] : n[t]
                    },
                    u = "",
                    p = !1;
                if (e)
                    for (i = 0; n.length > i; i++)
                        if (p) "'" !== n.charAt(i) || l("'") ? u += n.charAt(i) : p = !1;
                        else switch (n.charAt(i)) {
                            case "d":
                                u += d("d", e.getDate(), 2);
                                break;
                            case "D":
                                u += c("D", e.getDay(), a, s);
                                break;
                            case "o":
                                u += d("o", Math.round((new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime() - new Date(e.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                                break;
                            case "m":
                                u += d("m", e.getMonth() + 1, 2);
                                break;
                            case "M":
                                u += c("M", e.getMonth(), o, r);
                                break;
                            case "y":
                                u += l("y") ? e.getFullYear() : (e.getYear() % 100 < 10 ? "0" : "") + e.getYear() % 100;
                                break;
                            case "@":
                                u += e.getTime();
                                break;
                            case "!":
                                u += 1e4 * e.getTime() + this._ticksTo1970;
                                break;
                            case "'":
                                l("'") ? u += "'" : p = !0;
                                break;
                            default:
                                u += n.charAt(i)
                        }
                return u
            },
            _possibleChars: function (n) {
                var i, e = "",
                    t = !1,
                    a = function (e) {
                        var t = n.length > i + 1 && n.charAt(i + 1) === e;
                        return t && i++, t
                    };
                for (i = 0; n.length > i; i++)
                    if (t) "'" !== n.charAt(i) || a("'") ? e += n.charAt(i) : t = !1;
                    else switch (n.charAt(i)) {
                        case "d":
                        case "m":
                        case "y":
                        case "@":
                            e += "0123456789";
                            break;
                        case "D":
                        case "M":
                            return null;
                        case "'":
                            a("'") ? e += "'" : t = !0;
                            break;
                        default:
                            e += n.charAt(i)
                    }
                return e
            },
            _get: function (e, t) {
                return void 0 !== e.settings[t] ? e.settings[t] : this._defaults[t]
            },
            _setDateFromField: function (e, t) {
                if (e.input.val() !== e.lastVal) {
                    var n = this._get(e, "dateFormat"),
                        i = e.lastVal = e.input ? e.input.val() : null,
                        a = this._getDefaultDate(e),
                        s = a,
                        o = this._getFormatConfig(e);
                    try {
                        s = this.parseDate(n, i, o) || a
                    } catch (u) {
                        i = t ? "" : i
                    }
                    e.selectedDay = s.getDate(), e.drawMonth = e.selectedMonth = s.getMonth(), e.drawYear = e.selectedYear = s.getFullYear(), e.currentDay = i ? s.getDate() : 0, e.currentMonth = i ? s.getMonth() : 0, e.currentYear = i ? s.getFullYear() : 0, this._adjustInstDate(e)
                }
            },
            _getDefaultDate: function (e) {
                return this._restrictMinMax(e, this._determineDate(e, this._get(e, "defaultDate"), new Date))
            },
            _determineDate: function (r, e, l) {
                var t = function (e) {
                        var t = new Date;
                        return t.setDate(t.getDate() + e), t
                    },
                    n = null == e || "" === e ? l : "string" == typeof e ? function (e) {
                        try {
                            return w.datepicker.parseDate(w.datepicker._get(r, "dateFormat"), e, w.datepicker._getFormatConfig(r))
                        } catch (l) {}
                        for (var t = (e.toLowerCase().match(/^c/) ? w.datepicker._getDate(r) : null) || new Date, n = t.getFullYear(), i = t.getMonth(), a = t.getDate(), s = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, o = s.exec(e); o;) {
                            switch (o[2] || "d") {
                                case "d":
                                case "D":
                                    a += parseInt(o[1], 10);
                                    break;
                                case "w":
                                case "W":
                                    a += 7 * parseInt(o[1], 10);
                                    break;
                                case "m":
                                case "M":
                                    i += parseInt(o[1], 10), a = Math.min(a, w.datepicker._getDaysInMonth(n, i));
                                    break;
                                case "y":
                                case "Y":
                                    n += parseInt(o[1], 10), a = Math.min(a, w.datepicker._getDaysInMonth(n, i))
                            }
                            o = s.exec(e)
                        }
                        return new Date(n, i, a)
                    }(e) : "number" == typeof e ? isNaN(e) ? l : t(e) : new Date(e.getTime());
                return (n = n && "Invalid Date" == "" + n ? l : n) && (n.setHours(0), n.setMinutes(0), n.setSeconds(0), n.setMilliseconds(0)), this._daylightSavingAdjust(n)
            },
            _daylightSavingAdjust: function (e) {
                return e ? (e.setHours(12 < e.getHours() ? e.getHours() + 2 : 0), e) : null
            },
            _setDate: function (e, t, n) {
                var i = !t,
                    a = e.selectedMonth,
                    s = e.selectedYear,
                    o = this._restrictMinMax(e, this._determineDate(e, t, new Date));
                e.selectedDay = e.currentDay = o.getDate(), e.drawMonth = e.selectedMonth = e.currentMonth = o.getMonth(), e.drawYear = e.selectedYear = e.currentYear = o.getFullYear(), a === e.selectedMonth && s === e.selectedYear || n || this._notifyChange(e), this._adjustInstDate(e), e.input && e.input.val(i ? "" : this._formatDate(e))
            },
            _getDate: function (e) {
                return !e.currentYear || e.input && "" === e.input.val() ? null : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay))
            },
            _attachHandlers: function (e) {
                var t = this._get(e, "stepMonths"),
                    n = "#" + e.id.replace(/\\\\/g, "\\");
                e.dpDiv.find("[data-handler]").map(function () {
                    var e = {
                        prev: function () {
                            w.datepicker._adjustDate(n, -t, "M")
                        },
                        next: function () {
                            w.datepicker._adjustDate(n, +t, "M")
                        },
                        hide: function () {
                            w.datepicker._hideDatepicker()
                        },
                        today: function () {
                            w.datepicker._gotoToday(n)
                        },
                        selectDay: function () {
                            return w.datepicker._selectDay(n, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
                        },
                        selectMonth: function () {
                            return w.datepicker._selectMonthYear(n, this, "M"), !1
                        },
                        selectYear: function () {
                            return w.datepicker._selectMonthYear(n, this, "Y"), !1
                        }
                    };
                    w(this).bind(this.getAttribute("data-event"), e[this.getAttribute("data-handler")])
                })
            },
            _generateHTML: function (e) {
                var t, n, i, a, s, o, r, l, d, c, u, p, h, f, m, g, v, b, y, x, _, k, w, C, T, S, D, E, N, M, A, R, j, I, L, F, O, H, P, q = new Date,
                    B = this._daylightSavingAdjust(new Date(q.getFullYear(), q.getMonth(), q.getDate())),
                    $ = this._get(e, "isRTL"),
                    G = this._get(e, "showButtonPanel"),
                    z = this._get(e, "hideIfNoPrevNext"),
                    W = this._get(e, "navigationAsDateFormat"),
                    Y = this._getNumberOfMonths(e),
                    V = this._get(e, "showCurrentAtPos"),
                    K = this._get(e, "stepMonths"),
                    U = 1 !== Y[0] || 1 !== Y[1],
                    X = this._daylightSavingAdjust(e.currentDay ? new Date(e.currentYear, e.currentMonth, e.currentDay) : new Date(9999, 9, 9)),
                    J = this._getMinMaxDate(e, "min"),
                    Q = this._getMinMaxDate(e, "max"),
                    Z = e.drawMonth - V,
                    ee = e.drawYear;
                if (Z < 0 && (Z += 12, ee--), Q)
                    for (t = this._daylightSavingAdjust(new Date(Q.getFullYear(), Q.getMonth() - Y[0] * Y[1] + 1, Q.getDate())), t = J && t < J ? J : t; this._daylightSavingAdjust(new Date(ee, Z, 1)) > t;) --Z < 0 && (Z = 11, ee--);
                for (e.drawMonth = Z, e.drawYear = ee, n = this._get(e, "prevText"), n = W ? this.formatDate(n, this._daylightSavingAdjust(new Date(ee, Z - K, 1)), this._getFormatConfig(e)) : n, i = this._canAdjustMonth(e, -1, ee, Z) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + ($ ? "e" : "w") + "'>" + n + "</span></a>" : z ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + ($ ? "e" : "w") + "'>" + n + "</span></a>", a = this._get(e, "nextText"), a = W ? this.formatDate(a, this._daylightSavingAdjust(new Date(ee, Z + K, 1)), this._getFormatConfig(e)) : a, s = this._canAdjustMonth(e, 1, ee, Z) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + a + "'><span class='ui-icon ui-icon-circle-triangle-" + ($ ? "w" : "e") + "'>" + a + "</span></a>" : z ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + a + "'><span class='ui-icon ui-icon-circle-triangle-" + ($ ? "w" : "e") + "'>" + a + "</span></a>", o = this._get(e, "currentText"), r = this._get(e, "gotoCurrent") && e.currentDay ? X : B, o = W ? this.formatDate(o, r, this._getFormatConfig(e)) : o, l = e.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(e, "closeText") + "</button>", d = G ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + ($ ? l : "") + (this._isInRange(e, r) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + o + "</button>" : "") + ($ ? "" : l) + "</div>" : "", c = parseInt(this._get(e, "firstDay"), 10), c = isNaN(c) ? 0 : c, u = this._get(e, "showWeek"), p = this._get(e, "dayNames"), h = this._get(e, "dayNamesMin"), f = this._get(e, "monthNames"), m = this._get(e, "monthNamesShort"), g = this._get(e, "beforeShowDay"), v = this._get(e, "showOtherMonths"), b = this._get(e, "selectOtherMonths"), y = this._getDefaultDate(e), x = "", k = 0; Y[0] > k; k++) {
                    for (w = "", this.maxRows = 4, C = 0; Y[1] > C; C++) {
                        if (T = this._daylightSavingAdjust(new Date(ee, Z, e.selectedDay)), S = " ui-corner-all", D = "", U) {
                            if (D += "<div class='ui-datepicker-group", 1 < Y[1]) switch (C) {
                                case 0:
                                    D += " ui-datepicker-group-first", S = " ui-corner-" + ($ ? "right" : "left");
                                    break;
                                case Y[1] - 1:
                                    D += " ui-datepicker-group-last", S = " ui-corner-" + ($ ? "left" : "right");
                                    break;
                                default:
                                    D += " ui-datepicker-group-middle", S = ""
                            }
                            D += "'>"
                        }
                        for (D += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + S + "'>" + (/all|left/.test(S) && 0 === k ? $ ? s : i : "") + (/all|right/.test(S) && 0 === k ? $ ? i : s : "") + this._generateMonthYearHeader(e, Z, ee, J, Q, 0 < k || 0 < C, f, m) + "</div><table class='ui-datepicker-calendar'><thead><tr>", E = u ? "<th class='ui-datepicker-week-col'>" + this._get(e, "weekHeader") + "</th>" : "", _ = 0; _ < 7; _++) E += "<th scope='col'" + (5 <= (_ + c + 6) % 7 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + p[N = (_ + c) % 7] + "'>" + h[N] + "</span></th>";
                        for (D += E + "</tr></thead><tbody>", M = this._getDaysInMonth(ee, Z), ee === e.selectedYear && Z === e.selectedMonth && (e.selectedDay = Math.min(e.selectedDay, M)), A = (this._getFirstDayOfMonth(ee, Z) - c + 7) % 7, R = Math.ceil((A + M) / 7), j = U && this.maxRows > R ? this.maxRows : R, this.maxRows = j, I = this._daylightSavingAdjust(new Date(ee, Z, 1 - A)), L = 0; L < j; L++) {
                            for (D += "<tr>", F = u ? "<td class='ui-datepicker-week-col'>" + this._get(e, "calculateWeek")(I) + "</td>" : "", _ = 0; _ < 7; _++) O = g ? g.apply(e.input ? e.input[0] : null, [I]) : [!0, ""], P = (H = I.getMonth() !== Z) && !b || !O[0] || J && I < J || Q && Q < I, F += "<td class='" + (5 <= (_ + c + 6) % 7 ? " ui-datepicker-week-end" : "") + (H ? " ui-datepicker-other-month" : "") + (I.getTime() === T.getTime() && Z === e.selectedMonth && e._keyEvent || y.getTime() === I.getTime() && y.getTime() === T.getTime() ? " " + this._dayOverClass : "") + (P ? " " + this._unselectableClass + " ui-state-disabled" : "") + (H && !v ? "" : " " + O[1] + (I.getTime() === X.getTime() ? " " + this._currentClass : "") + (I.getTime() === B.getTime() ? " ui-datepicker-today" : "")) + "'" + (H && !v || !O[2] ? "" : " title='" + O[2].replace(/'/g, "&#39;") + "'") + (P ? "" : " data-handler='selectDay' data-event='click' data-month='" + I.getMonth() + "' data-year='" + I.getFullYear() + "'") + ">" + (H && !v ? "&#xa0;" : P ? "<span class='ui-state-default'>" + I.getDate() + "</span>" : "<a class='ui-state-default" + (I.getTime() === B.getTime() ? " ui-state-highlight" : "") + (I.getTime() === X.getTime() ? " ui-state-active" : "") + (H ? " ui-priority-secondary" : "") + "' href='#'>" + I.getDate() + "</a>") + "</td>", I.setDate(I.getDate() + 1), I = this._daylightSavingAdjust(I);
                            D += F + "</tr>"
                        }
                        11 < ++Z && (Z = 0, ee++), w += D += "</tbody></table>" + (U ? "</div>" + (0 < Y[0] && C === Y[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : "")
                    }
                    x += w
                }
                return x += d, e._keyEvent = !1, x
            },
            _generateMonthYearHeader: function (e, t, n, i, a, s, o, r) {
                var l, d, c, u, p, h, f, m, g = this._get(e, "changeMonth"),
                    v = this._get(e, "changeYear"),
                    b = this._get(e, "showMonthAfterYear"),
                    y = "<div class='ui-datepicker-title'>",
                    x = "";
                if (s || !g) x += "<span class='ui-datepicker-month'>" + o[t] + "</span>";
                else {
                    for (l = i && i.getFullYear() === n, d = a && a.getFullYear() === n, x += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", c = 0; c < 12; c++)(!l || c >= i.getMonth()) && (!d || a.getMonth() >= c) && (x += "<option value='" + c + "'" + (c === t ? " selected='selected'" : "") + ">" + r[c] + "</option>");
                    x += "</select>"
                }
                if (b || (y += x + (!s && g && v ? "" : "&#xa0;")), !e.yearshtml)
                    if (e.yearshtml = "", s || !v) y += "<span class='ui-datepicker-year'>" + n + "</span>";
                    else {
                        for (u = this._get(e, "yearRange").split(":"), p = (new Date).getFullYear(), f = (h = function (e) {
                                var t = e.match(/c[+\-].*/) ? n + parseInt(e.substring(1), 10) : e.match(/[+\-].*/) ? p + parseInt(e, 10) : parseInt(e, 10);
                                return isNaN(t) ? p : t
                            })(u[0]), m = Math.max(f, h(u[1] || "")), f = i ? Math.max(f, i.getFullYear()) : f, m = a ? Math.min(m, a.getFullYear()) : m, e.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>"; f <= m; f++) e.yearshtml += "<option value='" + f + "'" + (f === n ? " selected='selected'" : "") + ">" + f + "</option>";
                        e.yearshtml += "</select>", y += e.yearshtml, e.yearshtml = null
                    } return y += this._get(e, "yearSuffix"), b && (y += (!s && g && v ? "" : "&#xa0;") + x), y + "</div>"
            },
            _adjustInstDate: function (e, t, n) {
                var i = e.drawYear + ("Y" === n ? t : 0),
                    a = e.drawMonth + ("M" === n ? t : 0),
                    s = Math.min(e.selectedDay, this._getDaysInMonth(i, a)) + ("D" === n ? t : 0),
                    o = this._restrictMinMax(e, this._daylightSavingAdjust(new Date(i, a, s)));
                e.selectedDay = o.getDate(), e.drawMonth = e.selectedMonth = o.getMonth(), e.drawYear = e.selectedYear = o.getFullYear(), ("M" === n || "Y" === n) && this._notifyChange(e)
            },
            _restrictMinMax: function (e, t) {
                var n = this._getMinMaxDate(e, "min"),
                    i = this._getMinMaxDate(e, "max"),
                    a = n && t < n ? n : t;
                return i && i < a ? i : a
            },
            _notifyChange: function (e) {
                var t = this._get(e, "onChangeMonthYear");
                t && t.apply(e.input ? e.input[0] : null, [e.selectedYear, e.selectedMonth + 1, e])
            },
            _getNumberOfMonths: function (e) {
                var t = this._get(e, "numberOfMonths");
                return null == t ? [1, 1] : "number" == typeof t ? [1, t] : t
            },
            _getMinMaxDate: function (e, t) {
                return this._determineDate(e, this._get(e, t + "Date"), null)
            },
            _getDaysInMonth: function (e, t) {
                return 32 - this._daylightSavingAdjust(new Date(e, t, 32)).getDate()
            },
            _getFirstDayOfMonth: function (e, t) {
                return new Date(e, t, 1).getDay()
            },
            _canAdjustMonth: function (e, t, n, i) {
                var a = this._getNumberOfMonths(e),
                    s = this._daylightSavingAdjust(new Date(n, i + (t < 0 ? t : a[0] * a[1]), 1));
                return t < 0 && s.setDate(this._getDaysInMonth(s.getFullYear(), s.getMonth())), this._isInRange(e, s)
            },
            _isInRange: function (e, t) {
                var n, i, a = this._getMinMaxDate(e, "min"),
                    s = this._getMinMaxDate(e, "max"),
                    o = null,
                    r = null,
                    l = this._get(e, "yearRange");
                return l && (n = l.split(":"), i = (new Date).getFullYear(), o = parseInt(n[0], 10), r = parseInt(n[1], 10), n[0].match(/[+\-].*/) && (o += i), n[1].match(/[+\-].*/) && (r += i)), (!a || t.getTime() >= a.getTime()) && (!s || t.getTime() <= s.getTime()) && (!o || t.getFullYear() >= o) && (!r || r >= t.getFullYear())
            },
            _getFormatConfig: function (e) {
                var t = this._get(e, "shortYearCutoff");
                return {
                    shortYearCutoff: t = "string" != typeof t ? t : (new Date).getFullYear() % 100 + parseInt(t, 10),
                    dayNamesShort: this._get(e, "dayNamesShort"),
                    dayNames: this._get(e, "dayNames"),
                    monthNamesShort: this._get(e, "monthNamesShort"),
                    monthNames: this._get(e, "monthNames")
                }
            },
            _formatDate: function (e, t, n, i) {
                t || (e.currentDay = e.selectedDay, e.currentMonth = e.selectedMonth, e.currentYear = e.selectedYear);
                var a = t ? "object" == typeof t ? t : this._daylightSavingAdjust(new Date(i, n, t)) : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
                return this.formatDate(this._get(e, "dateFormat"), a, this._getFormatConfig(e))
            }
        }), w.fn.datepicker = function (e, t) {
            if (!this.length) return this;
            w.datepicker.initialized || (w(document).mousedown(w.datepicker._checkExternalClick), w.datepicker.initialized = !0), 0 === w("#" + w.datepicker._mainDivId).length && w("body").append(w.datepicker.dpDiv);
            var n = Array.prototype.slice.call(arguments, 1);
            return "string" != typeof e || "isDisabled" !== e && "getDate" !== e && "widget" !== e ? "option" === e && 2 === arguments.length && "string" == typeof t ? w.datepicker["_" + e + "Datepicker"].apply(w.datepicker, [this[0]].concat(n)) : this.each(function () {
                "string" == typeof e ? w.datepicker["_" + e + "Datepicker"].apply(w.datepicker, [this].concat(n)) : w.datepicker._attachDatepicker(this, e)
            }) : w.datepicker["_" + e + "Datepicker"].apply(w.datepicker, [this[0]].concat(n))
        }, w.datepicker = new n, w.datepicker.initialized = !1, w.datepicker.uuid = (new Date).getTime(), w.datepicker.version = "1.11.4", w.datepicker
    }),
    function (e) {
        "object" == typeof exports && exports && "object" == typeof module && module && module.exports === exports ? e(require("jquery")) : "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function (x) {
        function l(e) {
            var t = e[0];
            return 0 < t.offsetWidth && 0 < t.offsetHeight
        }

        function o(e) {
            if (e.minTime && (e.minTime = N(e.minTime)), e.maxTime && (e.maxTime = N(e.maxTime)), e.durationTime && "function" != typeof e.durationTime && (e.durationTime = N(e.durationTime)), "now" == e.scrollDefault) e.scrollDefault = function () {
                return e.roundingFunction(N(new Date), e)
            };
            else if (e.scrollDefault && "function" != typeof e.scrollDefault) {
                var t = e.scrollDefault;
                e.scrollDefault = function () {
                    return e.roundingFunction(N(t), e)
                }
            } else e.minTime && (e.scrollDefault = function () {
                return e.roundingFunction(e.minTime, e)
            });
            if ("string" === x.type(e.timeFormat) && e.timeFormat.match(/[gh]/) && (e._twelveHourTime = !0), !1 === e.showOnFocus && -1 != e.showOn.indexOf("focus") && e.showOn.splice(e.showOn.indexOf("focus"), 1), 0 < e.disableTimeRanges.length) {
                for (var n in e.disableTimeRanges) e.disableTimeRanges[n] = [N(e.disableTimeRanges[n][0]), N(e.disableTimeRanges[n][1])];
                e.disableTimeRanges = e.disableTimeRanges.sort(function (e, t) {
                    return e[0] - t[0]
                });
                for (n = e.disableTimeRanges.length - 1; 0 < n; n--) e.disableTimeRanges[n][0] <= e.disableTimeRanges[n - 1][1] && (e.disableTimeRanges[n - 1] = [Math.min(e.disableTimeRanges[n][0], e.disableTimeRanges[n - 1][0]), Math.max(e.disableTimeRanges[n][1], e.disableTimeRanges[n - 1][1])], e.disableTimeRanges.splice(n, 1))
            }
            return e
        }

        function d(e) {
            var t = e.data("timepicker-settings"),
                n = e.data("timepicker-list");
            if (n && n.length && (n.remove(), e.data("timepicker-list", !1)), t.useSelect) var i = n = x("<select />", {
                "class": "ui-timepicker-select"
            });
            else n = x("<ul />", {
                "class": "ui-timepicker-list"
            }), (i = x("<div />", {
                "class": "ui-timepicker-wrapper",
                tabindex: -1
            })).css({
                display: "none",
                position: "absolute"
            }).append(n);
            if (t.noneOption)
                if (!0 === t.noneOption && (t.noneOption = t.useSelect ? "Time..." : "None"), x.isArray(t.noneOption)) {
                    for (var a in t.noneOption)
                        if (parseInt(a, 10) == a) {
                            var s = _(t.noneOption[a], t.useSelect);
                            n.append(s)
                        }
                } else {
                    s = _(t.noneOption, t.useSelect);
                    n.append(s)
                } if (t.className && i.addClass(t.className), (null !== t.minTime || null !== t.durationTime) && t.showDuration) {
                "function" == typeof t.step || t.step;
                i.addClass("ui-timepicker-with-duration"), i.addClass("ui-timepicker-step-" + t.step)
            }
            var o = t.minTime;
            "function" == typeof t.durationTime ? o = N(t.durationTime()) : null !== t.durationTime && (o = t.durationTime);
            var r = null !== t.minTime ? t.minTime : 0,
                l = null !== t.maxTime ? t.maxTime : r + M - 1;
            l < r && (l += M), l === M - 1 && "string" === x.type(t.timeFormat) && t.show2400 && (l = M);
            var d = t.disableTimeRanges,
                c = 0,
                u = d.length,
                p = t.step;
            "function" != typeof p && (p = function () {
                return t.step
            });
            a = r;
            for (var h = 0; a <= l; a += 60 * p(++h)) {
                var f, m = a,
                    g = E(m, t);
                if (t.useSelect)(f = x("<option />", {
                    value: g
                })).text(g);
                else(f = x("<li />")).addClass(m % 86400 < 43200 ? "ui-timepicker-am" : "ui-timepicker-pm"), f.data("time", m <= 86400 ? m : m % 86400), f.text(g);
                if ((null !== t.minTime || null !== t.durationTime) && t.showDuration) {
                    var v = D(a - o, t.step);
                    if (t.useSelect) f.text(f.text() + " (" + v + ")");
                    else {
                        var b = x("<span />", {
                            "class": "ui-timepicker-duration"
                        });
                        b.text(" (" + v + ")"), f.append(b)
                    }
                }
                c < u && (m >= d[c][1] && (c += 1), d[c] && m >= d[c][0] && m < d[c][1] && (t.useSelect ? f.prop("disabled", !0) : f.addClass("ui-timepicker-disabled"))), n.append(f)
            }
            if (i.data("timepicker-input", e), e.data("timepicker-list", i), t.useSelect) e.val() && n.val(k(N(e.val()), t)), n.on("focus", function () {
                x(this).data("timepicker-input").trigger("showTimepicker")
            }), n.on("blur", function () {
                x(this).data("timepicker-input").trigger("hideTimepicker")
            }), n.on("change", function () {
                T(e, x(this).val(), "select")
            }), T(e, n.val(), "initial"), e.hide().after(n);
            else {
                var y = t.appendTo;
                "string" == typeof y ? y = x(y) : "function" == typeof y && (y = y(e)), y.append(i), C(e, n), n.on("mousedown click", "li", function () {
                    e.off("focus.timepicker"), e.on("focus.timepicker-ie-hack", function () {
                        e.off("focus.timepicker-ie-hack"), e.on("focus.timepicker", A.show)
                    }), w(e) || e[0].focus(), n.find("li").removeClass("ui-timepicker-selected"), x(this).addClass("ui-timepicker-selected"), S(e) && (e.trigger("hideTimepicker"), n.on("mouseup.timepicker click.timepicker", "li", function () {
                        n.off("mouseup.timepicker click.timepicker"), i.hide()
                    }))
                })
            }
        }

        function _(e, t) {
            var n, i, a;
            return "object" == typeof e ? (n = e.label, i = e.className, a = e.value) : "string" == typeof e ? n = e : x.error("Invalid noneOption value"), t ? x("<option />", {
                value: a,
                "class": i,
                text: n
            }) : x("<li />", {
                "class": i,
                text: n
            }).data("time", String(a))
        }

        function k(e, t) {
            if (null !== (e = t.roundingFunction(e, t))) return E(e, t)
        }

        function c(e) {
            if (e.target != window) {
                var t = x(e.target);
                t.closest(".ui-timepicker-input").length || t.closest(".ui-timepicker-wrapper").length || (A.hide(), x(document).unbind(".ui-timepicker"), x(window).unbind(".ui-timepicker"))
            }
        }

        function w(e) {
            var t = e.data("timepicker-settings");
            return (window.navigator.msMaxTouchPoints || "ontouchstart" in document) && t.disableTouchKeyboard
        }

        function u(e, t, i) {
            if (!i && 0 !== i) return !1;
            var n = e.data("timepicker-settings"),
                a = !1;
            i = n.roundingFunction(i, n);
            return t.find("li").each(function (e, t) {
                var n = x(t);
                if ("number" == typeof n.data("time")) return n.data("time") == i ? (a = n, !1) : void 0
            }), a
        }

        function C(e, t) {
            t.find("li").removeClass("ui-timepicker-selected");
            var n = N(p(e), e.data("timepicker-settings"));
            if (null !== n) {
                var i = u(e, t, n);
                if (i) {
                    var a = i.offset().top - t.offset().top;
                    (a + i.outerHeight() > t.outerHeight() || a < 0) && t.scrollTop(t.scrollTop() + i.position().top - i.outerHeight()), i.addClass("ui-timepicker-selected")
                }
            }
        }

        function r(e, t) {
            if ("" !== this.value && "timepicker" != t) {
                var n = x(this);
                if (!n.is(":focus") || e && "change" == e.type) {
                    var i = n.data("timepicker-settings"),
                        a = N(this.value, i);
                    if (null !== a) {
                        var s = !1;
                        if (null !== i.minTime && null !== i.maxTime && (a < i.minTime || a > i.maxTime) && (s = !0), x.each(i.disableTimeRanges, function () {
                                if (a >= this[0] && a < this[1]) return !(s = !0)
                            }), i.forceRoundTime) {
                            var o = i.roundingFunction(a, i);
                            o != a && (a = o, t = null)
                        }
                        var r = E(a, i);
                        s ? T(n, r, "error") && n.trigger("timeRangeError") : T(n, r, t)
                    } else n.trigger("timeFormatError")
                }
            }
        }

        function p(e) {
            return e.is("input") ? e.val() : e.data("ui-timepicker-value")
        }

        function T(e, t, n) {
            if (e.is("input")) {
                e.val(t);
                var i = e.data("timepicker-settings");
                i.useSelect && "select" != n && "initial" != n && e.data("timepicker-list").val(k(N(t), i))
            }
            return e.data("ui-timepicker-value") != t ? (e.data("ui-timepicker-value", t), "select" == n ? e.trigger("selectTime").trigger("changeTime").trigger("change", "timepicker") : -1 == ["error", "initial"].indexOf(n) && e.trigger("changeTime"), !0) : (e.trigger("selectTime"), !1)
        }

        function h(e) {
            switch (e.keyCode) {
                case 13:
                case 9:
                    return;
                default:
                    e.preventDefault()
            }
        }

        function f(e) {
            var t = x(this),
                n = t.data("timepicker-list");
            if (!n || !l(n)) {
                if (40 != e.keyCode) return !0;
                A.show.call(t.get(0)), n = t.data("timepicker-list"), w(t) || t.focus()
            }
            switch (e.keyCode) {
                case 13:
                    return S(t) && (r.call(t.get(0), {
                        type: "change"
                    }), A.hide.apply(this)), e.preventDefault(), !1;
                case 38:
                    var i = n.find(".ui-timepicker-selected");
                    return i.length ? i.is(":first-child") || (i.removeClass("ui-timepicker-selected"), i.prev().addClass("ui-timepicker-selected"), i.prev().position().top < i.outerHeight() && n.scrollTop(n.scrollTop() - i.outerHeight())) : (n.find("li").each(function (e, t) {
                        if (0 < x(t).position().top) return i = x(t), !1
                    }), i.addClass("ui-timepicker-selected")), !1;
                case 40:
                    return 0 === (i = n.find(".ui-timepicker-selected")).length ? (n.find("li").each(function (e, t) {
                        if (0 < x(t).position().top) return i = x(t), !1
                    }), i.addClass("ui-timepicker-selected")) : i.is(":last-child") || (i.removeClass("ui-timepicker-selected"), i.next().addClass("ui-timepicker-selected"), i.next().position().top + 2 * i.outerHeight() > n.outerHeight() && n.scrollTop(n.scrollTop() + i.outerHeight())), !1;
                case 27:
                    n.find("li").removeClass("ui-timepicker-selected"), A.hide();
                    break;
                case 9:
                    A.hide();
                    break;
                default:
                    return !0
            }
        }

        function m(e) {
            var t = x(this),
                n = t.data("timepicker-list"),
                i = t.data("timepicker-settings");
            if (!n || !l(n) || i.disableTextInput) return !0;
            switch (e.keyCode) {
                case 96:
                case 97:
                case 98:
                case 99:
                case 100:
                case 101:
                case 102:
                case 103:
                case 104:
                case 105:
                case 48:
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 65:
                case 77:
                case 80:
                case 186:
                case 8:
                case 46:
                    i.typeaheadHighlight ? C(t, n) : n.hide()
            }
        }

        function S(e) {
            var t = e.data("timepicker-settings"),
                n = null,
                i = e.data("timepicker-list").find(".ui-timepicker-selected");
            return !i.hasClass("ui-timepicker-disabled") && (i.length && (n = i.data("time")), null !== n && ("string" != typeof n && (n = E(n, t)), T(e, n, "select")), !0)
        }

        function D(e, t) {
            e = Math.abs(e);
            var n, i, a = Math.round(e / 60),
                s = [];
            return a < 60 ? s = [a, g.mins] : (n = Math.floor(a / 60), i = a % 60, 30 == t && 30 == i && (n += g.decimal + 5), s.push(n), s.push(1 == n ? g.hr : g.hrs), 30 != t && i && (s.push(i), s.push(g.mins))), s.join(" ")
        }

        function E(e, t) {
            if ("number" != typeof e) return null;
            var n = parseInt(e % 60),
                i = parseInt(e / 60 % 60),
                a = parseInt(e / 3600 % 24),
                s = new Date(1970, 0, 2, a, i, n, 0);
            if (isNaN(s.getTime())) return null;
            if ("function" === x.type(t.timeFormat)) return t.timeFormat(s);
            for (var o, r, l = "", d = 0; d < t.timeFormat.length; d++) switch (r = t.timeFormat.charAt(d)) {
                case "a":
                    l += 11 < s.getHours() ? g.pm : g.am;
                    break;
                case "A":
                    l += 11 < s.getHours() ? g.PM : g.AM;
                    break;
                case "g":
                    l += 0 === (o = s.getHours() % 12) ? "12" : o;
                    break;
                case "G":
                    o = s.getHours(), e === M && (o = t.show2400 ? 24 : 0), l += o;
                    break;
                case "h":
                    0 !== (o = s.getHours() % 12) && o < 10 && (o = "0" + o), l += 0 === o ? "12" : o;
                    break;
                case "H":
                    o = s.getHours(), e === M && (o = t.show2400 ? 24 : 0), l += 9 < o ? o : "0" + o;
                    break;
                case "i":
                    l += 9 < (i = s.getMinutes()) ? i : "0" + i;
                    break;
                case "s":
                    l += 9 < (n = s.getSeconds()) ? n : "0" + n;
                    break;
                case "\\":
                    d++, l += t.timeFormat.charAt(d);
                    break;
                default:
                    l += r
            }
            return l
        }

        function N(e, t) {
            if ("" === e || null === e) return null;
            if ("object" == typeof e) return 3600 * e.getHours() + 60 * e.getMinutes() + e.getSeconds();
            if ("string" != typeof e) return e;
            "a" != (e = e.toLowerCase().replace(/[\s\.]/g, "")).slice(-1) && "p" != e.slice(-1) || (e += "m");
            var n = "(" + g.am.replace(".", "") + "|" + g.pm.replace(".", "") + "|" + g.AM.replace(".", "") + "|" + g.PM.replace(".", "") + ")?",
                i = new RegExp("^" + n + "([0-9]?[0-9])\\W?([0-5][0-9])?\\W?([0-5][0-9])?" + n + "$"),
                a = e.match(i);
            if (!a) return null;
            var s = parseInt(1 * a[2], 10);
            if (24 < s) {
                if (t && !1 === t.wrapHours) return null;
                s %= 24
            }
            var o = a[1] || a[5],
                r = s;
            if (s <= 12 && o) {
                var l = o == g.pm || o == g.PM;
                r = 12 == s ? l ? 12 : 0 : s + (l ? 12 : 0)
            }
            var d = 3600 * r + 60 * (1 * a[3] || 0) + (1 * a[4] || 0);
            if (s < 12 && !o && t && t._twelveHourTime && t.scrollDefault) {
                var c = d - t.scrollDefault();
                c < 0 && M / -2 <= c && (d = (d + M / 2) % M)
            }
            return d
        }
        var M = 86400,
            g = {
                am: "am",
                pm: "pm",
                AM: "AM",
                PM: "PM",
                decimal: ".",
                mins: "mins",
                hr: "hr",
                hrs: "hrs"
            },
            A = {
                init: function (s) {
                    return this.each(function () {
                        var e = x(this),
                            t = [];
                        for (var n in x.fn.timepicker.defaults) e.data(n) && (t[n] = e.data(n));
                        var i = x.extend({}, x.fn.timepicker.defaults, s, t);
                        if (i.lang && (g = x.extend(g, i.lang)), i = o(i), e.data("timepicker-settings", i), e.addClass("ui-timepicker-input"), i.useSelect) d(e);
                        else {
                            if (e.prop("autocomplete", "off"), i.showOn)
                                for (var a in i.showOn) e.on(i.showOn[a] + ".timepicker", A.show);
                            e.on("change.timepicker", r), e.on("keydown.timepicker", f), e.on("keyup.timepicker", m), i.disableTextInput && e.on("keydown.timepicker", h), r.call(e.get(0), null, "initial")
                        }
                    })
                },
                show: function (e) {
                    var t = x(this),
                        n = t.data("timepicker-settings");
                    if (e && e.preventDefault(), n.useSelect) t.data("timepicker-list").focus();
                    else {
                        w(t) && t.blur();
                        var i = t.data("timepicker-list");
                        if (!t.prop("readonly") && (i && 0 !== i.length && "function" != typeof n.durationTime || (d(t), i = t.data("timepicker-list")), !l(i))) {
                            t.data("ui-timepicker-value", t.val()), C(t, i), A.hide(), i.show();
                            var a = {};
                            n.orientation.match(/r/) ? a.left = t.offset().left + t.outerWidth() - i.outerWidth() + parseInt(i.css("marginLeft").replace("px", ""), 10) : a.left = t.offset().left + parseInt(i.css("marginLeft").replace("px", ""), 10), "t" == (n.orientation.match(/t/) ? "t" : n.orientation.match(/b/) ? "b" : t.offset().top + t.outerHeight(!0) + i.outerHeight() > x(window).height() + x(window).scrollTop() ? "t" : "b") ? (i.addClass("ui-timepicker-positioned-top"), a.top = t.offset().top - i.outerHeight() + parseInt(i.css("marginTop").replace("px", ""), 10)) : (i.removeClass("ui-timepicker-positioned-top"), a.top = t.offset().top + t.outerHeight() + parseInt(i.css("marginTop").replace("px", ""), 10)), i.offset(a);
                            var s = i.find(".ui-timepicker-selected");
                            if (!s.length) {
                                var o = N(p(t));
                                null !== o ? s = u(t, i, o) : n.scrollDefault && (s = u(t, i, n.scrollDefault()))
                            }
                            if (s && s.length) {
                                var r = i.scrollTop() + s.position().top - s.outerHeight();
                                i.scrollTop(r)
                            } else i.scrollTop(0);
                            return n.stopScrollPropagation && x(document).on("wheel.ui-timepicker", ".ui-timepicker-wrapper", function (e) {
                                e.preventDefault();
                                var t = x(this).scrollTop();
                                x(this).scrollTop(t + e.originalEvent.deltaY)
                            }), x(document).on("touchstart.ui-timepicker mousedown.ui-timepicker", c), x(window).on("resize.ui-timepicker", c), n.closeOnWindowScroll && x(document).on("scroll.ui-timepicker", c), t.trigger("showTimepicker"), this
                        }
                    }
                },
                hide: function () {
                    var e = x(this),
                        t = e.data("timepicker-settings");
                    return t && t.useSelect && e.blur(), x(".ui-timepicker-wrapper").each(function () {
                        var e = x(this);
                        if (l(e)) {
                            var t = e.data("timepicker-input"),
                                n = t.data("timepicker-settings");
                            n && n.selectOnBlur && S(t), e.hide(), t.trigger("hideTimepicker")
                        }
                    }), this
                },
                option: function (i, a) {
                    return "string" == typeof i && void 0 === a ? x(this).data("timepicker-settings")[i] : this.each(function () {
                        var e = x(this),
                            t = e.data("timepicker-settings"),
                            n = e.data("timepicker-list");
                        "object" == typeof i ? t = x.extend(t, i) : "string" == typeof i && (t[i] = a), t = o(t), e.data("timepicker-settings", t), n && (n.remove(), e.data("timepicker-list", !1)), t.useSelect && d(e)
                    })
                },
                getSecondsFromMidnight: function () {
                    return N(p(this))
                },
                getTime: function (e) {
                    var t = p(this);
                    if (!t) return null;
                    var n = N(t);
                    if (null === n) return null;
                    e || (e = new Date);
                    var i = new Date(e);
                    return i.setHours(n / 3600), i.setMinutes(n % 3600 / 60), i.setSeconds(n % 60), i.setMilliseconds(0), i
                },
                isVisible: function () {
                    var e = this.data("timepicker-list");
                    return !(!e || !l(e))
                },
                setTime: function (e) {
                    var t = this,
                        n = t.data(
                            "timepicker-settings");
                    if (n.forceRoundTime) var i = k(N(e), n);
                    else i = E(N(e), n);
                    return e && null === i && n.noneOption && (i = e), T(t, i), t.data("timepicker-list") && C(t, t.data("timepicker-list")), this
                },
                remove: function () {
                    var e = this;
                    if (e.hasClass("ui-timepicker-input")) {
                        var t = e.data("timepicker-settings");
                        return e.removeAttr("autocomplete", "off"), e.removeClass("ui-timepicker-input"), e.removeData("timepicker-settings"), e.off(".timepicker"), e.data("timepicker-list") && e.data("timepicker-list").remove(), t.useSelect && e.show(), e.removeData("timepicker-list"), this
                    }
                }
            };
        x.fn.timepicker = function (e) {
            return this.length ? A[e] ? this.hasClass("ui-timepicker-input") ? A[e].apply(this, Array.prototype.slice.call(arguments, 1)) : this : "object" != typeof e && e ? void x.error("Method " + e + " does not exist on jQuery.timepicker") : A.init.apply(this, arguments) : this
        }, x.fn.timepicker.defaults = {
            appendTo: "body",
            className: null,
            closeOnWindowScroll: !1,
            disableTextInput: !1,
            disableTimeRanges: [],
            disableTouchKeyboard: !1,
            durationTime: null,
            forceRoundTime: !1,
            maxTime: null,
            minTime: null,
            noneOption: !1,
            orientation: "l",
            roundingFunction: function (e, t) {
                if (null === e) return null;
                if ("number" != typeof t.step) return e;
                var n = e % (60 * t.step);
                return (n -= (t.minTime || 0) % (60 * t.step)) >= 30 * t.step ? e += 60 * t.step - n : e -= n, e == M && t.show2400 ? e : e % M
            },
            scrollDefault: null,
            selectOnBlur: !1,
            show2400: !1,
            showDuration: !1,
            showOn: ["click", "focus"],
            showOnFocus: !0,
            step: 30,
            stopScrollPropagation: !1,
            timeFormat: "g:ia",
            typeaheadHighlight: !0,
            useSelect: !1,
            wrapHours: !0
        }
    }),
    function (q) {
        var B = {},
            $ = {
                mode: "horizontal",
                slideSelector: "",
                infiniteLoop: !0,
                hideControlOnEnd: !1,
                speed: 500,
                easing: null,
                slideMargin: 0,
                startSlide: 0,
                randomStart: !1,
                captions: !1,
                ticker: !1,
                tickerHover: !1,
                adaptiveHeight: !1,
                adaptiveHeightSpeed: 500,
                video: !1,
                useCSS: !0,
                preloadImages: "visible",
                responsive: !0,
                slideZIndex: 50,
                wrapperClass: "bx-wrapper",
                touchEnabled: !0,
                swipeThreshold: 50,
                oneToOneTouch: !0,
                preventDefaultSwipeX: !0,
                preventDefaultSwipeY: !1,
                pager: !0,
                pagerType: "full",
                pagerShortSeparator: " / ",
                pagerSelector: null,
                buildPager: null,
                pagerCustom: null,
                controls: !0,
                nextText: "Next",
                prevText: "Prev",
                nextSelector: null,
                prevSelector: null,
                autoControls: !1,
                startText: "Start",
                stopText: "Stop",
                autoControlsCombine: !1,
                autoControlsSelector: null,
                auto: !1,
                pause: 4e3,
                autoStart: !0,
                autoDirection: "next",
                autoHover: !1,
                autoDelay: 0,
                autoSlideForOnePage: !1,
                minSlides: 1,
                maxSlides: 1,
                moveSlides: 0,
                slideWidth: 0,
                onSliderLoad: function () {},
                onSlideBefore: function () {},
                onSlideAfter: function () {},
                onSlideNext: function () {},
                onSlidePrev: function () {},
                onSliderResize: function () {}
            };
        q.fn.bxSlider = function (t) {
            if (0 == this.length) return this;
            if (1 < this.length) return this.each(function () {
                q(this).bxSlider(t)
            }), this;
            var d = {},
                c = this;
            B.el = this;
            var n = q(window).width(),
                a = q(window).height(),
                s = function () {
                    d.settings = q.extend({}, $, t), d.settings.slideWidth = parseInt(d.settings.slideWidth), d.children = c.children(d.settings.slideSelector), d.children.length < d.settings.minSlides && (d.settings.minSlides = d.children.length), d.children.length < d.settings.maxSlides && (d.settings.maxSlides = d.children.length), d.settings.randomStart && (d.settings.startSlide = Math.floor(Math.random() * d.children.length)), d.active = {
                        index: d.settings.startSlide
                    }, d.carousel = 1 < d.settings.minSlides || 1 < d.settings.maxSlides, d.carousel && (d.settings.preloadImages = "all"), d.minThreshold = d.settings.minSlides * d.settings.slideWidth + (d.settings.minSlides - 1) * d.settings.slideMargin, d.maxThreshold = d.settings.maxSlides * d.settings.slideWidth + (d.settings.maxSlides - 1) * d.settings.slideMargin, d.working = !1, d.controls = {}, d.interval = null, d.animProp = "vertical" == d.settings.mode ? "top" : "left", d.usingCSS = d.settings.useCSS && "fade" != d.settings.mode && function () {
                        var e = document.createElement("div"),
                            t = ["WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"];
                        for (var n in t)
                            if (e.style[t[n]] !== undefined) return d.cssPrefix = t[n].replace("Perspective", "").toLowerCase(), d.animProp = "-" + d.cssPrefix + "-transform", !0;
                        return !1
                    }(), "vertical" == d.settings.mode && (d.settings.maxSlides = d.settings.minSlides), c.data("origStyle", c.attr("style")), c.children(d.settings.slideSelector).each(function () {
                        q(this).data("origStyle", q(this).attr("style"))
                    }), e()
                },
                e = function () {
                    c.wrap('<div class="' + d.settings.wrapperClass + '"><div class="bx-viewport"></div></div>'), d.viewport = c.parent(), d.loader = q('<div class="bx-loading" />'), d.viewport.prepend(d.loader), c.css({
                        width: "horizontal" == d.settings.mode ? 100 * d.children.length + 215 + "%" : "auto",
                        position: "relative"
                    }), d.usingCSS && d.settings.easing ? c.css("-" + d.cssPrefix + "-transition-timing-function", d.settings.easing) : d.settings.easing || (d.settings.easing = "swing");
                    h();
                    d.viewport.css({
                        width: "100%",
                        overflow: "hidden",
                        position: "relative"
                    }), d.viewport.parent().css({
                        maxWidth: l()
                    }), d.settings.pager || d.viewport.parent().css({
                        margin: "0 auto 0px"
                    }), d.children.css({
                        "float": "horizontal" == d.settings.mode ? "left" : "none",
                        listStyle: "none",
                        position: "relative"
                    }), d.children.css("width", p()), "horizontal" == d.settings.mode && 0 < d.settings.slideMargin && d.children.css("marginRight", d.settings.slideMargin), "vertical" == d.settings.mode && 0 < d.settings.slideMargin && d.children.css("marginBottom", d.settings.slideMargin), "fade" == d.settings.mode && (d.children.css({
                        position: "absolute",
                        zIndex: 0,
                        display: "none"
                    }), d.children.eq(d.settings.startSlide).css({
                        zIndex: d.settings.slideZIndex,
                        display: "block"
                    })), d.controls.el = q('<div class="bx-controls" />'), d.settings.captions && k(), d.active.last = d.settings.startSlide == f() - 1, d.settings.video && c.fitVids();
                    var e = d.children.eq(d.settings.startSlide);
                    "all" == d.settings.preloadImages && (e = d.children), d.settings.ticker ? d.settings.pager = !1 : (d.settings.pager && y(), d.settings.controls && x(), d.settings.auto && d.settings.autoControls && _(), (d.settings.controls || d.settings.autoControls || d.settings.pager) && d.viewport.after(d.controls.el)), o(e, r)
                },
                o = function (e, t) {
                    var n = e.find("img, iframe").length;
                    if (0 != n) {
                        var i = 0;
                        e.find("img, iframe").each(function () {
                            q(this).one("load", function () {
                                ++i == n && t()
                            }).each(function () {
                                this.complete && q(this).load()
                            })
                        })
                    } else t()
                },
                r = function () {
                    if (d.settings.infiniteLoop && "fade" != d.settings.mode && !d.settings.ticker) {
                        var e = "vertical" == d.settings.mode ? d.settings.minSlides : d.settings.maxSlides,
                            t = d.children.slice(0, e).clone().addClass("bx-clone"),
                            n = d.children.slice(-e).clone().addClass("bx-clone");
                        c.append(t).prepend(n)
                    }
                    d.loader.remove(), g(), "vertical" == d.settings.mode && (d.settings.adaptiveHeight = !0), d.viewport.height(u()), c.redrawSlider(), d.settings.onSliderLoad(d.active.index), d.initialized = !0, d.settings.responsive && q(window).bind("resize", P), d.settings.auto && d.settings.autoStart && (1 < f() || d.settings.autoSlideForOnePage) && R(), d.settings.ticker && j(), d.settings.pager && E(d.settings.startSlide), d.settings.controls && A(), d.settings.touchEnabled && !d.settings.ticker && L()
                },
                u = function () {
                    var e = 0,
                        t = q();
                    if ("vertical" == d.settings.mode || d.settings.adaptiveHeight)
                        if (d.carousel) {
                            var n = 1 == d.settings.moveSlides ? d.active.index : d.active.index * m();
                            for (t = d.children.eq(n), i = 1; i <= d.settings.maxSlides - 1; i++) t = n + i >= d.children.length ? t.add(d.children.eq(i - 1)) : t.add(d.children.eq(n + i))
                        } else t = d.children.eq(d.active.index);
                    else t = d.children;
                    return "vertical" == d.settings.mode ? (t.each(function () {
                        e += q(this).outerHeight()
                    }), 0 < d.settings.slideMargin && (e += d.settings.slideMargin * (d.settings.minSlides - 1))) : e = Math.max.apply(Math, t.map(function () {
                        return q(this).outerHeight(!1)
                    }).get()), "border-box" == d.viewport.css("box-sizing") ? e += parseFloat(d.viewport.css("padding-top")) + parseFloat(d.viewport.css("padding-bottom")) + parseFloat(d.viewport.css("border-top-width")) + parseFloat(d.viewport.css("border-bottom-width")) : "padding-box" == d.viewport.css("box-sizing") && (e += parseFloat(d.viewport.css("padding-top")) + parseFloat(d.viewport.css("padding-bottom"))), e
                },
                l = function () {
                    var e = "100%";
                    return 0 < d.settings.slideWidth && (e = "horizontal" == d.settings.mode ? d.settings.maxSlides * d.settings.slideWidth + (d.settings.maxSlides - 1) * d.settings.slideMargin : d.settings.slideWidth), e
                },
                p = function () {
                    var e = d.settings.slideWidth,
                        t = d.viewport.width();
                    return 0 == d.settings.slideWidth || d.settings.slideWidth > t && !d.carousel || "vertical" == d.settings.mode ? e = t : 1 < d.settings.maxSlides && "horizontal" == d.settings.mode && (t > d.maxThreshold || t < d.minThreshold && (e = (t - d.settings.slideMargin * (d.settings.minSlides - 1)) / d.settings.minSlides)), e
                },
                h = function () {
                    var e = 1;
                    if ("horizontal" == d.settings.mode && 0 < d.settings.slideWidth)
                        if (d.viewport.width() < d.minThreshold) e = d.settings.minSlides;
                        else if (d.viewport.width() > d.maxThreshold) e = d.settings.maxSlides;
                    else {
                        var t = d.children.first().width() + d.settings.slideMargin;
                        e = Math.floor((d.viewport.width() + d.settings.slideMargin) / t)
                    } else "vertical" == d.settings.mode && (e = d.settings.minSlides);
                    return e
                },
                f = function () {
                    var e = 0;
                    if (0 < d.settings.moveSlides)
                        if (d.settings.infiniteLoop) e = Math.ceil(d.children.length / m());
                        else
                            for (var t = 0, n = 0; t < d.children.length;) ++e, t = n + h(), n += d.settings.moveSlides <= h() ? d.settings.moveSlides : h();
                    else e = Math.ceil(d.children.length / h());
                    return e
                },
                m = function () {
                    return 0 < d.settings.moveSlides && d.settings.moveSlides <= h() ? d.settings.moveSlides : h()
                },
                g = function () {
                    if (d.children.length > d.settings.maxSlides && d.active.last && !d.settings.infiniteLoop) {
                        if ("horizontal" == d.settings.mode) {
                            var e = d.children.last(),
                                t = e.position();
                            v(-(t.left - (d.viewport.width() - e.outerWidth())), "reset", 0)
                        } else if ("vertical" == d.settings.mode) {
                            var n = d.children.length - d.settings.minSlides;
                            t = d.children.eq(n).position();
                            v(-t.top, "reset", 0)
                        }
                    } else {
                        t = d.children.eq(d.active.index * m()).position();
                        d.active.index == f() - 1 && (d.active.last = !0), t != undefined && ("horizontal" == d.settings.mode ? v(-t.left, "reset", 0) : "vertical" == d.settings.mode && v(-t.top, "reset", 0))
                    }
                },
                v = function (e, t, n, i) {
                    if (d.usingCSS) {
                        var a = "vertical" == d.settings.mode ? "translate3d(0, " + e + "px, 0)" : "translate3d(" + e + "px, 0, 0)";
                        c.css("-" + d.cssPrefix + "-transition-duration", n / 1e3 + "s"), "slide" == t ? (c.css(d.animProp, a), c.bind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function () {
                            c.unbind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"), N()
                        })) : "reset" == t ? c.css(d.animProp, a) : "ticker" == t && (c.css("-" + d.cssPrefix + "-transition-timing-function", "linear"), c.css(d.animProp, a), c.bind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function () {
                            c.unbind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"), v(i.resetValue, "reset", 0), I()
                        }))
                    } else {
                        var s = {};
                        s[d.animProp] = e, "slide" == t ? c.animate(s, n, d.settings.easing, function () {
                            N()
                        }) : "reset" == t ? c.css(d.animProp, e) : "ticker" == t && c.animate(s, speed, "linear", function () {
                            v(i.resetValue, "reset", 0), I()
                        })
                    }
                },
                b = function () {
                    for (var e = "", t = f(), n = 0; n < t; n++) {
                        var i = "";
                        d.settings.buildPager && q.isFunction(d.settings.buildPager) ? (i = d.settings.buildPager(n), d.pagerEl.addClass("bx-custom-pager")) : (i = n + 1, d.pagerEl.addClass("bx-default-pager")), e += '<div class="bx-pager-item"><a href="" data-slide-index="' + n + '" class="bx-pager-link">' + i + "</a></div>"
                    }
                    d.pagerEl.html(e)
                },
                y = function () {
                    d.settings.pagerCustom ? d.pagerEl = q(d.settings.pagerCustom) : (d.pagerEl = q('<div class="bx-pager" />'), d.settings.pagerSelector ? q(d.settings.pagerSelector).html(d.pagerEl) : d.controls.el.addClass("bx-has-pager").append(d.pagerEl), b()), d.pagerEl.on("click", "a", D)
                },
                x = function () {
                    d.controls.next = q('<a class="bx-next" href="">' + d.settings.nextText + "</a>"), d.controls.prev = q('<a class="bx-prev" href="">' + d.settings.prevText + "</a>"), d.controls.next.bind("click", w), d.controls.prev.bind("click", C), d.settings.nextSelector && q(d.settings.nextSelector).append(d.controls.next), d.settings.prevSelector && q(d.settings.prevSelector).append(d.controls.prev), d.settings.nextSelector || d.settings.prevSelector || (d.controls.directionEl = q('<div class="bx-controls-direction" />'), d.controls.directionEl.append(d.controls.prev).append(d.controls.next), d.controls.el.addClass("bx-has-controls-direction").append(d.controls.directionEl))
                },
                _ = function () {
                    d.controls.start = q('<div class="bx-controls-auto-item"><a class="bx-start" href="">' + d.settings.startText + "</a></div>"), d.controls.stop = q('<div class="bx-controls-auto-item"><a class="bx-stop" href="">' + d.settings.stopText + "</a></div>"), d.controls.autoEl = q('<div class="bx-controls-auto" />'), d.controls.autoEl.on("click", ".bx-start", T), d.controls.autoEl.on("click", ".bx-stop", S), d.settings.autoControlsCombine ? d.controls.autoEl.append(d.controls.start) : d.controls.autoEl.append(d.controls.start).append(d.controls.stop), d.settings.autoControlsSelector ? q(d.settings.autoControlsSelector).html(d.controls.autoEl) : d.controls.el.addClass("bx-has-controls-auto").append(d.controls.autoEl), M(d.settings.autoStart ? "stop" : "start")
                },
                k = function () {
                    d.children.each(function () {
                        var e = q(this).find("img:first").attr("title");
                        e != undefined && ("" + e).length && q(this).append('<div class="bx-caption"><span>' + e + "</span></div>")
                    })
                },
                w = function (e) {
                    d.settings.auto && c.stopAuto(), c.goToNextSlide(), e.preventDefault()
                },
                C = function (e) {
                    d.settings.auto && c.stopAuto(), c.goToPrevSlide(), e.preventDefault()
                },
                T = function (e) {
                    c.startAuto(), e.preventDefault()
                },
                S = function (e) {
                    c.stopAuto(), e.preventDefault()
                },
                D = function (e) {
                    d.settings.auto && c.stopAuto();
                    var t = q(e.currentTarget);
                    if (t.attr("data-slide-index") !== undefined) {
                        var n = parseInt(t.attr("data-slide-index"));
                        n != d.active.index && c.goToSlide(n), e.preventDefault()
                    }
                },
                E = function (n) {
                    var e = d.children.length;
                    if ("short" == d.settings.pagerType) return 1 < d.settings.maxSlides && (e = Math.ceil(d.children.length / d.settings.maxSlides)), void d.pagerEl.html(n + 1 + d.settings.pagerShortSeparator + e);
                    d.pagerEl.find("a").removeClass("active"), d.pagerEl.each(function (e, t) {
                        q(t).find("a").eq(n).addClass("active")
                    })
                },
                N = function () {
                    if (d.settings.infiniteLoop) {
                        var e = "";
                        0 == d.active.index ? e = d.children.eq(0).position() : d.active.index == f() - 1 && d.carousel ? e = d.children.eq((f() - 1) * m()).position() : d.active.index == d.children.length - 1 && (e = d.children.eq(d.children.length - 1).position()), e && ("horizontal" == d.settings.mode ? v(-e.left, "reset", 0) : "vertical" == d.settings.mode && v(-e.top, "reset", 0))
                    }
                    d.working = !1, d.settings.onSlideAfter(d.children.eq(d.active.index), d.oldIndex, d.active.index)
                },
                M = function (e) {
                    d.settings.autoControlsCombine ? d.controls.autoEl.html(d.controls[e]) : (d.controls.autoEl.find("a").removeClass("active"), d.controls.autoEl.find("a:not(.bx-" + e + ")").addClass("active"))
                },
                A = function () {
                    1 == f() ? (d.controls.prev.addClass("disabled"), d.controls.next.addClass("disabled")) : !d.settings.infiniteLoop && d.settings.hideControlOnEnd && (0 == d.active.index ? (d.controls.prev.addClass("disabled"), d.controls.next.removeClass("disabled")) : d.active.index == f() - 1 ? (d.controls.next.addClass("disabled"), d.controls.prev.removeClass("disabled")) : (d.controls.prev.removeClass("disabled"), d.controls.next.removeClass("disabled")))
                },
                R = function () {
                    if (0 < d.settings.autoDelay) setTimeout(c.startAuto, d.settings.autoDelay);
                    else c.startAuto();
                    d.settings.autoHover && c.hover(function () {
                        d.interval && (c.stopAuto(!0), d.autoPaused = !0)
                    }, function () {
                        d.autoPaused && (c.startAuto(!0), d.autoPaused = null)
                    })
                },
                j = function () {
                    var e = 0;
                    if ("next" == d.settings.autoDirection) c.append(d.children.clone().addClass("bx-clone"));
                    else {
                        c.prepend(d.children.clone().addClass("bx-clone"));
                        var t = d.children.first().position();
                        e = "horizontal" == d.settings.mode ? -t.left : -t.top
                    }
                    v(e, "reset", 0), d.settings.pager = !1, d.settings.controls = !1, d.settings.autoControls = !1, d.settings.tickerHover && !d.usingCSS && d.viewport.hover(function () {
                        c.stop()
                    }, function () {
                        var e = 0;
                        d.children.each(function () {
                            e += "horizontal" == d.settings.mode ? q(this).outerWidth(!0) : q(this).outerHeight(!0)
                        });
                        var t = d.settings.speed / e,
                            n = "horizontal" == d.settings.mode ? "left" : "top",
                            i = t * (e - Math.abs(parseInt(c.css(n))));
                        I(i)
                    }), I()
                },
                I = function (e) {
                    speed = e || d.settings.speed;
                    var t = {
                            left: 0,
                            top: 0
                        },
                        n = {
                            left: 0,
                            top: 0
                        };
                    "next" == d.settings.autoDirection ? t = c.find(".bx-clone").first().position() : n = d.children.first().position();
                    var i = "horizontal" == d.settings.mode ? -t.left : -t.top,
                        a = "horizontal" == d.settings.mode ? -n.left : -n.top;
                    v(i, "ticker", speed, {
                        resetValue: a
                    })
                },
                L = function () {
                    d.touch = {
                        start: {
                            x: 0,
                            y: 0
                        },
                        end: {
                            x: 0,
                            y: 0
                        }
                    }, d.viewport.bind("touchstart", F)
                },
                F = function (e) {
                    if (d.working) e.preventDefault();
                    else {
                        d.touch.originalPos = c.position();
                        var t = e.originalEvent;
                        d.touch.start.x = t.changedTouches[0].pageX, d.touch.start.y = t.changedTouches[0].pageY, d.viewport.bind("touchmove", O), d.viewport.bind("touchend", H)
                    }
                },
                O = function (e) {
                    var t = e.originalEvent,
                        n = Math.abs(t.changedTouches[0].pageX - d.touch.start.x),
                        i = Math.abs(t.changedTouches[0].pageY - d.touch.start.y);
                    if (i < 3 * n && d.settings.preventDefaultSwipeX ? e.preventDefault() : n < 3 * i && d.settings.preventDefaultSwipeY && e.preventDefault(), "fade" != d.settings.mode && d.settings.oneToOneTouch) {
                        var a = 0;
                        if ("horizontal" == d.settings.mode) {
                            var s = t.changedTouches[0].pageX - d.touch.start.x;
                            a = d.touch.originalPos.left + s
                        } else {
                            s = t.changedTouches[0].pageY - d.touch.start.y;
                            a = d.touch.originalPos.top + s
                        }
                        v(a, "reset", 0)
                    }
                },
                H = function (e) {
                    d.viewport.unbind("touchmove", O);
                    var t = e.originalEvent,
                        n = 0;
                    if (d.touch.end.x = t.changedTouches[0].pageX, d.touch.end.y = t.changedTouches[0].pageY, "fade" == d.settings.mode) {
                        (i = Math.abs(d.touch.start.x - d.touch.end.x)) >= d.settings.swipeThreshold && (d.touch.start.x > d.touch.end.x ? c.goToNextSlide() : c.goToPrevSlide(), c.stopAuto())
                    } else {
                        var i = 0;
                        "horizontal" == d.settings.mode ? (i = d.touch.end.x - d.touch.start.x, n = d.touch.originalPos.left) : (i = d.touch.end.y - d.touch.start.y, n = d.touch.originalPos.top), !d.settings.infiniteLoop && (0 == d.active.index && 0 < i || d.active.last && i < 0) ? v(n, "reset", 200) : Math.abs(i) >= d.settings.swipeThreshold ? (i < 0 ? c.goToNextSlide() : c.goToPrevSlide(), c.stopAuto()) : v(n, "reset", 200)
                    }
                    d.viewport.unbind("touchend", H)
                },
                P = function () {
                    if (d.initialized) {
                        var e = q(window).width(),
                            t = q(window).height();
                        n == e && a == t || (n = e, a = t, c.redrawSlider(), d.settings.onSliderResize.call(c, d.active.index))
                    }
                };
            return c.goToSlide = function (e, t) {
                if (!d.working && d.active.index != e)
                    if (d.working = !0, d.oldIndex = d.active.index, e < 0 ? d.active.index = f() - 1 : e >= f() ? d.active.index = 0 : d.active.index = e, d.settings.onSlideBefore(d.children.eq(d.active.index), d.oldIndex, d.active.index), "next" == t ? d.settings.onSlideNext(d.children.eq(d.active.index), d.oldIndex, d.active.index) : "prev" == t && d.settings.onSlidePrev(d.children.eq(d.active.index), d.oldIndex, d.active.index), d.active.last = d.active.index >= f() - 1, d.settings.pager && E(d.active.index), d.settings.controls && A(), "fade" == d.settings.mode) d.settings.adaptiveHeight && d.viewport.height() != u() && d.viewport.animate({
                        height: u()
                    }, d.settings.adaptiveHeightSpeed), d.children.filter(":visible").fadeOut(d.settings.speed).css({
                        zIndex: 0
                    }), d.children.eq(d.active.index).css("zIndex", d.settings.slideZIndex + 1).fadeIn(d.settings.speed, function () {
                        q(this).css("zIndex", d.settings.slideZIndex), N()
                    });
                    else {
                        d.settings.adaptiveHeight && d.viewport.height() != u() && d.viewport.animate({
                            height: u()
                        }, d.settings.adaptiveHeightSpeed);
                        var n = 0,
                            i = {
                                left: 0,
                                top: 0
                            };
                        if (!d.settings.infiniteLoop && d.carousel && d.active.last)
                            if ("horizontal" == d.settings.mode) {
                                i = (s = d.children.eq(d.children.length - 1)).position(), n = d.viewport.width() - s.outerWidth()
                            } else {
                                var a = d.children.length - d.settings.minSlides;
                                i = d.children.eq(a).position()
                            }
                        else if (d.carousel && d.active.last && "prev" == t) {
                            var s, o = 1 == d.settings.moveSlides ? d.settings.maxSlides - m() : (f() - 1) * m() - (d.children.length - d.settings.maxSlides);
                            i = (s = c.children(".bx-clone").eq(o)).position()
                        } else if ("next" == t && 0 == d.active.index) i = c.find("> .bx-clone").eq(d.settings.maxSlides).position(), d.active.last = !1;
                        else if (0 <= e) {
                            var r = e * m();
                            i = d.children.eq(r).position()
                        }
                        if (void 0 !== i) {
                            var l = "horizontal" == d.settings.mode ? -(i.left - n) : -i.top;
                            v(l, "slide", d.settings.speed)
                        }
                    }
            }, c.goToNextSlide = function () {
                if (d.settings.infiniteLoop || !d.active.last) {
                    var e = parseInt(d.active.index) + 1;
                    c.goToSlide(e, "next")
                }
            }, c.goToPrevSlide = function () {
                if (d.settings.infiniteLoop || 0 != d.active.index) {
                    var e = parseInt(d.active.index) - 1;
                    c.goToSlide(e, "prev")
                }
            }, c.startAuto = function (e) {
                d.interval || (d.interval = setInterval(function () {
                    "next" == d.settings.autoDirection ? c.goToNextSlide() : c.goToPrevSlide()
                }, d.settings.pause), d.settings.autoControls && 1 != e && M("stop"))
            }, c.stopAuto = function (e) {
                d.interval && (clearInterval(d.interval), d.interval = null, d.settings.autoControls && 1 != e && M("start"))
            }, c.getCurrentSlide = function () {
                return d.active.index
            }, c.getCurrentSlideElement = function () {
                return d.children.eq(d.active.index)
            }, c.getSlideCount = function () {
                return d.children.length
            }, c.redrawSlider = function () {
                d.children.add(c.find(".bx-clone")).width(p()), d.viewport.css("height", u()), d.settings.ticker || g(), d.active.last && (d.active.index = f() - 1), d.active.index >= f() && (d.active.last = !0), d.settings.pager && !d.settings.pagerCustom && (b(), E(d.active.index))
            }, c.destroySlider = function () {
                d.initialized && (d.initialized = !1, q(".bx-clone", this).remove(), d.children.each(function () {
                    q(this).data("origStyle") != undefined ? q(this).attr("style", q(this).data("origStyle")) : q(this).removeAttr("style")
                }), q(this).data("origStyle") != undefined ? this.attr("style", q(this).data("origStyle")) : q(this).removeAttr("style"), q(this).unwrap().unwrap(), d.controls.el && d.controls.el.remove(), d.controls.next && d.controls.next.remove(), d.controls.prev && d.controls.prev.remove(), d.pagerEl && d.settings.controls && d.pagerEl.remove(), q(".bx-caption", this).remove(), d.controls.autoEl && d.controls.autoEl.remove(), clearInterval(d.interval), d.settings.responsive && q(window).unbind("resize", P))
            }, c.reloadSlider = function (e) {
                e != undefined && (t = e), c.destroySlider(), s()
            }, s(), this
        }
    }(jQuery), jQuery(function (e) {
        e("div:has(.login-form)").addClass("border-none")
    }),
    function (e, t, n) {
        var i, a = e.getElementsByTagName(t)[0];
        e.getElementById(n) || ((i = e.createElement(t)).id = n, i.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.9", a.parentNode.insertBefore(i, a))
    }(document, "script", "facebook-jssdk"),
    function (e, t, n) {
        var i, a = e.getElementsByTagName(t)[0],
            s = /^http:/.test(e.location) ? "http" : "https";
        e.getElementById(n) || ((i = e.createElement(t)).id = n, i.src = s + "://platform.twitter.com/widgets.js", a.parentNode.insertBefore(i, a))
    }(document, "script", "twitter-wjs"),
    function (e, t, n, i, a, s, o) {
        e.GoogleAnalyticsObject = a, e[a] = e[a] || function () {
            (e[a].q = e[a].q || []).push(arguments)
        }, e[a].l = 1 * new Date, s = t.createElement(n), o = t.getElementsByTagName(n)[0], s.async = 1, s.src = i, o.parentNode.insertBefore(s, o)
    }(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga"), ga("create", "UA-91018921-1", "auto"), ga("send", "pageview"),
    function (B, _) {
        "use strict";

        function T(e, t, n) {
            var i = {};
            return i[e.key] = t, e.pos && (i[e.pos] = n), i
        }

        function S(e, t) {
            for (var n, i = t.length, a = e.length; a < i;) n = t[--i], t.splice(i, 1), n.unmount()
        }

        function D(n, i) {
            Object.keys(n.tags).forEach(function (t) {
                var e = n.tags[t];
                z(e) ? A(e, function (e) {
                    a(e, t, i)
                }) : a(e, t, i)
            })
        }

        function E(e, t, n) {
            var i, a = e._root;
            for (e._virts = []; a;) i = a.nextSibling, n ? t.insertBefore(a, n._root) : t.appendChild(a), e._virts.push(a), a = i
        }

        function N(e, t, n, i) {
            for (var a, s = e._root, o = 0; o < i; o++) a = s.nextSibling, t.insertBefore(s, n._root), s = a
        }

        function s(c, u, p) {
            I(c, "each");
            var h, f = typeof F(c, "no-reorder") !== ie || I(c, "no-reorder"),
                m = q(c),
                g = Z[m] || {
                    tmpl: c.outerHTML
                },
                v = n.test(m),
                b = c.parentNode,
                y = document.createTextNode(""),
                x = o(c),
                _ = "option" === m.toLowerCase(),
                k = [],
                w = [],
                C = "VIRTUAL" == c.tagName;
            p = ce.loopKeys(p), b.insertBefore(y, c), u.one("before-mount", function () {
                c.parentNode.removeChild(c), b.stub && (b = u.root)
            }).on("update", function () {
                var t = ce(p.val, u),
                    e = document.createDocumentFragment();
                z(t) || (t = (h = t || !1) ? Object.keys(t).map(function (e) {
                    return T(p, e, t[e])
                }) : []);
                for (var n = 0, i = t.length; n < i; n++) {
                    var a = t[n],
                        s = f && a instanceof Object && !h,
                        o = w.indexOf(a),
                        r = ~o && s ? o : n,
                        l = k[r];
                    a = !h && p.key ? T(p, a, n) : a, !s && !l || s && !~o || !l ? ((l = new M(g, {
                        parent: u,
                        isLoop: !0,
                        hasImpl: !!Z[m],
                        root: v ? b : c.cloneNode(),
                        item: a
                    }, c.innerHTML)).mount(), C && (l._root = l.root.firstChild), n != k.length && k[n] ? (C ? E(l, b, k[n]) : b.insertBefore(l.root, k[n].root), w.splice(n, 0, a)) : C ? E(l, e) : e.appendChild(l.root), k.splice(n, 0, l), r = n) : l.update(a, !0), r !== n && s && k[n] && (C ? N(l, b, k[n], c.childNodes.length) : b.insertBefore(l.root, k[n].root), p.pos && (l[p.pos] = n), k.splice(n, 0, k.splice(r, 1)[0]), w.splice(n, 0, w.splice(r, 1)[0]), !x && l.tags && D(l, n)), l._item = a, P(l, "_parent", u)
                }
                if (S(t, k), _) {
                    if (b.appendChild(e), re && !b.multiple)
                        for (var d = 0; d < b.length; d++)
                            if (b[d].__riot1374) {
                                b.selectedIndex = d, delete b[d].__riot1374;
                                break
                            }
                } else b.insertBefore(e, y);
                x && (u.tags[m] = k), w = t.slice()
            })
        }

        function k(e, n, i, a) {
            u(e, function (e) {
                if (1 == e.nodeType) {
                    if (e.isLoop = e.isLoop || e.parentNode && e.parentNode.isLoop || F(e, "each") ? 1 : 0, i) {
                        var t = o(e);
                        t && !e.isLoop && i.push(c(t, {
                            root: e,
                            parent: n
                        }, e.innerHTML, n))
                    }
                    e.isLoop && !a || g(e, n, [])
                }
            })
        }

        function w(e, n, i) {
            function a(e, t, n) {
                ce.hasExpr(t) && i.push($({
                    dom: e,
                    expr: t
                }, n))
            }
            u(e, function (i) {
                var e, t = i.nodeType;
                if (3 == t && "STYLE" != i.parentNode.tagName && a(i, i.nodeValue), 1 == t) return (e = F(i, "each")) ? (s(i, n, e), !1) : (A(i.attributes, function (e) {
                    var t = e.name,
                        n = t.split("__")[1];
                    if (a(i, e.value, {
                            attr: n || t,
                            bool: n
                        }), n) return I(i, t), !1
                }), !o(i) && void 0)
            })
        }

        function M(t, e, n) {
            function i() {
                var n = h && p ? d : u || d;
                A(v.attributes, function (e) {
                    var t = e.value;
                    c[L(e.name)] = ce.hasExpr(t) ? ce(t, n) : t
                }), A(Object.keys(y), function (e) {
                    c[L(e)] = ce(y[e], n)
                })
            }

            function a(e) {
                for (var t in f) typeof d[t] !== ae && W(d, t) && (d[t] = e[t])
            }

            function s() {
                d.parent && p && A(Object.keys(d.parent), function (e) {
                    var t = !G(se, e) && G(x, e);
                    (typeof d[e] === ae || t) && (t || x.push(e), d[e] = d.parent[e])
                })
            }

            function o(e) {
                d.update(e, !0)
            }

            function r(t) {
                if (A(g, function (e) {
                        e[t ? "mount" : "unmount"]()
                    }), u) {
                    var e = t ? "on" : "off";
                    p ? u[e]("unmount", d.unmount) : u[e]("update", o)[e]("unmount", d.unmount)
                }
            }
            var l, d = X.observable(this),
                c = U(e.opts) || {},
                u = e.parent,
                p = e.isLoop,
                h = e.hasImpl,
                f = Y(e.item),
                m = [],
                g = [],
                v = e.root,
                b = v.tagName.toLowerCase(),
                y = {},
                x = [];
            t.name && v._tag && v._tag.unmount(!0), this.isMounted = !1, v.isLoop = p, P(v._tag = this, "_riot_id", ++J), $(this, {
                parent: u,
                root: v,
                opts: c,
                tags: {}
            }, f), A(v.attributes, function (e) {
                var t = e.value;
                ce.hasExpr(t) && (y[e.name] = t)
            }), l = ue(t.tmpl, n), P(this, "update", function (e, t) {
                return e = Y(e), s(), e && j(f) && (a(e), f = e), $(d, e), i(), d.trigger("update", e), C(m, d), t && d.parent ? d.parent.one("updated", function () {
                    d.trigger("updated")
                }) : he(function () {
                    d.trigger("updated")
                }), this
            }), P(this, "mixin", function () {
                return A(arguments, function (e) {
                    var t;
                    R(e = typeof e === ie ? X.mixin(e) : e) ? (t = new e, e = e.prototype) : t = e, A(Object.getOwnPropertyNames(e), function (e) {
                        "init" != e && (d[e] = R(t[e]) ? t[e].bind(d) : t[e])
                    }), t.init && t.init.bind(d)()
                }), this
            }), P(this, "mount", function () {
                i();
                var e = X.mixin(ee);
                if (e && d.mixin(e), t.fn && t.fn.call(d, c), w(l, d, m), r(!0), t.attrs && V(t.attrs, function (e, t) {
                        O(v, e, t)
                    }), (t.attrs || h) && w(d.root, d, m), d.parent && !p || d.update(f), d.trigger("before-mount"), p && !h) v = l.firstChild;
                else {
                    for (; l.firstChild;) v.appendChild(l.firstChild);
                    v.stub && (v = u.root)
                }
                P(d, "root", v), p && k(d.root, d.parent, null, !0), !d.parent || d.parent.isMounted ? (d.isMounted = !0, d.trigger("mount")) : d.parent.one("mount", function () {
                    K(d.root) || (d.parent.isMounted = d.isMounted = !0, d.trigger("mount"))
                })
            }), P(this, "unmount", function (e) {
                var n, t = v,
                    i = t.parentNode,
                    a = Q.indexOf(d);
                if (d.trigger("before-unmount"), ~a && Q.splice(a, 1), i) {
                    if (u) z((n = H(u)).tags[b]) ? A(n.tags[b], function (e, t) {
                        e._riot_id == d._riot_id && n.tags[b].splice(t, 1)
                    }) : n.tags[b] = _;
                    else
                        for (; t.firstChild;) t.removeChild(t.firstChild);
                    e ? (I(i, ne), I(i, te)) : i.removeChild(t)
                }
                this._virts && A(this._virts, function (e) {
                    e.parentNode && e.parentNode.removeChild(e)
                }), d.trigger("unmount"), r(), d.off("*"), d.isMounted = !1, delete v._tag
            }), k(l, this, g)
        }

        function l(e, i, a, s) {
            a[e] = function (e) {
                var t = s._parent,
                    n = s._item;
                if (!n)
                    for (; t && !n;) n = t._item, t = t._parent;
                W(e = e || B.event, "currentTarget") && (e.currentTarget = a), W(e, "target") && (e.target = e.srcElement), W(e, "which") && (e.which = e.charCode || e.keyCode), e.item = n, !0 === i.call(s, e) || /radio|check/.test(a.type) || (e.preventDefault && e.preventDefault(), e.returnValue = !1), e.preventUpdate || (n ? H(t) : s).update()
            }
        }

        function d(e, t, n) {
            e && (e.insertBefore(n, t), e.removeChild(t))
        }

        function C(e, r) {
            A(e, function (e) {
                var t = e.dom,
                    n = e.attr,
                    i = ce(e.expr, r),
                    a = e.dom.parentNode;
                if (e.bool ? i = !!i : null == i && (i = ""), e.value !== i) {
                    if (e.value = i, !n) return i += "", void(a && ("TEXTAREA" === a.tagName ? (a.value = i, oe || (t.nodeValue = i)) : t.nodeValue = i));
                    if ("value" !== n)
                        if (I(t, n), R(i)) l(n, i, t, r);
                        else if ("if" == n) {
                        var s = e.stub,
                            o = function () {
                                d(t.parentNode, t, s)
                            };
                        i ? s && (function () {
                            d(s.parentNode, s, t)
                        }(), t.inStub = !1, K(t) || u(t, function (e) {
                            e._tag && !e._tag.isMounted && (e._tag.isMounted = !!e._tag.trigger("mount"))
                        })) : (s = e.stub = s || document.createTextNode(""), t.parentNode ? o() : (r.parent || r).one("updated", o), t.inStub = !0)
                    } else "show" === n ? t.style.display = i ? "" : "none" : "hide" === n ? t.style.display = i ? "none" : "" : e.bool ? ((t[n] = i) && O(t, n, n), re && "selected" === n && "OPTION" === t.tagName && (t.__riot1374 = i)) : (0 === i || i && typeof i !== x) && (v(n, y) && n != te && (n = n.slice(y.length)), O(t, n, i));
                    else t.value = i
                }
            })
        }

        function A(e, t) {
            for (var n, i = e ? e.length : 0, a = 0; a < i; a++) null != (n = e[a]) && !1 === t(n, a) && a--;
            return e
        }

        function R(e) {
            return typeof e === i || !1
        }

        function j(e) {
            return e && typeof e === x
        }

        function I(e, t) {
            e.removeAttribute(t)
        }

        function L(e) {
            return e.replace(/-(\w)/g, function (e, t) {
                return t.toUpperCase()
            })
        }

        function F(e, t) {
            return e.getAttribute(t)
        }

        function O(e, t, n) {
            e.setAttribute(t, n)
        }

        function o(e) {
            return e.tagName && Z[F(e, ne) || F(e, te) || e.tagName.toLowerCase()]
        }

        function r(e, t, n) {
            var i = n.tags[t];
            i ? (z(i) || i !== e && (n.tags[t] = [i]), G(n.tags[t], e) || n.tags[t].push(e)) : n.tags[t] = e
        }

        function a(e, t, n) {
            var i, a = e.parent;
            a && (z(i = a.tags[t]) ? i.splice(n, 0, i.splice(i.indexOf(e), 1)[0]) : r(e, t, a))
        }

        function c(e, t, n, i) {
            var a = new M(e, t, n),
                s = q(t.root),
                o = H(i);
            return a.parent = o, a._parent = i, r(a, s, o), o !== i && r(a, s, i), t.root.innerHTML = "", a
        }

        function H(e) {
            for (var t = e; !o(t.root) && t.parent;) t = t.parent;
            return t
        }

        function P(e, t, n, i) {
            return Object.defineProperty(e, t, $({
                value: n,
                enumerable: !1,
                writable: !1,
                configurable: !0
            }, i)), e
        }

        function q(e) {
            var t = o(e),
                n = F(e, "name");
            return n && !ce.hasExpr(n) ? n : t ? t.name : e.tagName.toLowerCase()
        }

        function $(e) {
            for (var t, n = arguments, i = 1; i < n.length; ++i)
                if (t = n[i])
                    for (var a in t) W(e, a) && (e[a] = t[a]);
            return e
        }

        function G(e, t) {
            return ~e.indexOf(t)
        }

        function z(e) {
            return Array.isArray(e) || e instanceof Array
        }

        function W(e, t) {
            var n = Object.getOwnPropertyDescriptor(e, t);
            return typeof e[t] === ae || n && n.writable
        }

        function Y(e) {
            if (!(e instanceof M || e && typeof e.trigger == i)) return e;
            var t = {};
            for (var n in e) G(se, n) || (t[n] = e[n]);
            return t
        }

        function u(e, t) {
            if (e) {
                if (!1 === t(e)) return;
                for (e = e.firstChild; e;) u(e, t), e = e.nextSibling
            }
        }

        function V(e, t) {
            for (var n, i = /([-\w]+) ?= ?(?:"([^"]*)|'([^']*)|({[^}]*}))/g; n = i.exec(e);) t(n[1].toLowerCase(), n[2] || n[3] || n[4])
        }

        function K(e) {
            for (; e;) {
                if (e.inStub) return !0;
                e = e.parentNode
            }
            return !1
        }

        function p(e) {
            return document.createElement(e)
        }

        function h(e, t) {
            return (t || document).querySelectorAll(e)
        }

        function f(e, t) {
            return (t || document).querySelector(e)
        }

        function U(e) {
            function t() {}
            return t.prototype = e, new t
        }

        function m(e) {
            return F(e, "id") || F(e, "name")
        }

        function g(t, n, i) {
            var a, s = m(t),
                e = function (e) {
                    G(i, s) || (a = z(e), e ? (!a || a && !G(e, t)) && (a ? e.push(t) : n[s] = [e, t]) : n[s] = t)
                };
            s && (ce.hasExpr(s) ? n.one("mount", function () {
                s = m(t), e(n[s])
            }) : e(n[s]))
        }

        function v(e, t) {
            return e.slice(0, t.length) === t
        }

        function b(e, t, n) {
            var i = Z[t],
                a = e._innerHTML = e._innerHTML || e.innerHTML;
            return e.innerHTML = "", i && e && (i = new M(i, {
                root: e,
                opts: n
            }, a)), i && i.mount && (i.mount(), G(Q, i) || Q.push(i)), i
        }
        var X = {
                version: "v2.3.18",
                settings: {}
            },
            J = 0,
            Q = [],
            Z = {},
            ee = "__global_mixin",
            y = "riot-",
            te = y + "tag",
            ne = "data-is",
            ie = "string",
            x = "object",
            ae = "undefined",
            i = "function",
            n = /^(?:t(?:body|head|foot|[rhd])|caption|col(?:group)?|opt(?:ion|group))$/,
            se = ["_item", "_id", "_parent", "update", "root", "mount", "unmount", "mixin", "isMounted", "isLoop", "tags", "parent", "opts", "trigger", "on", "off", "one"],
            oe = 0 | (B && B.document || {}).documentMode,
            re = B && !!B.InstallTrigger;
        X.observable = function (s) {
                s = s || {};
                var o = {},
                    r = Array.prototype.slice,
                    l = function (e, t) {
                        e.replace(/\S+/g, t)
                    };
                return Object.defineProperties(s, {
                    on: {
                        value: function (e, n) {
                            return "function" != typeof n || l(e, function (e, t) {
                                (o[e] = o[e] || []).push(n), n.typed = 0 < t
                            }), s
                        },
                        enumerable: !1,
                        writable: !1,
                        configurable: !1
                    },
                    off: {
                        value: function (e, a) {
                            return "*" != e || a ? l(e, function (e) {
                                if (a)
                                    for (var t, n = o[e], i = 0; t = n && n[i]; ++i) t == a && n.splice(i--, 1);
                                else delete o[e]
                            }) : o = {}, s
                        },
                        enumerable: !1,
                        writable: !1,
                        configurable: !1
                    },
                    one: {
                        value: function (e, t) {
                            function n() {
                                s.off(e, n), t.apply(s, arguments)
                            }
                            return s.on(e, n)
                        },
                        enumerable: !1,
                        writable: !1,
                        configurable: !1
                    },
                    trigger: {
                        value: function (e) {
                            for (var i, t = arguments.length - 1, a = new Array(t), n = 0; n < t; n++) a[n] = arguments[n + 1];
                            return l(e, function (e) {
                                i = r.call(o[e] || [], 0);
                                for (var t, n = 0; t = i[n]; ++n) {
                                    if (t.busy) return;
                                    t.busy = 1, t.apply(s, t.typed ? [e].concat(a) : a), i[n] !== t && n--, t.busy = 0
                                }
                                o["*"] && "*" != e && s.trigger.apply(s, ["*", e].concat(a))
                            }), s
                        },
                        enumerable: !1,
                        writable: !1,
                        configurable: !1
                    }
                }), s
            },
            function (e) {
                function n(e) {
                    return e.split(/[/?#]/)
                }

                function i(e, t) {
                    var n = new RegExp("^" + t[w](/\*/g, "([^/?#]+?)")[w](/\.\./, ".*") + "$"),
                        i = e.match(n);
                    if (i) return i.slice(1)
                }

                function t(e, t) {
                    var n;
                    return function () {
                        clearTimeout(n), n = setTimeout(e, t)
                    }
                }

                function a(e) {
                    h = t(c, 1), E[_](C, h), E[_](T, h), N[_](j, u), e && c(!0)
                }

                function s() {
                    this.$ = [], e.observable(this), L.on("stop", this.s.bind(this)), L.on("emit", this.e.bind(this))
                }

                function o(e) {
                    return e[w](/^\/|\/$/, "")
                }

                function r(e) {
                    return "string" == typeof e
                }

                function l(e) {
                    return (e || A.href)[w](b, "")
                }

                function d(e) {
                    return "#" == f[0] ? (e || A.href || "").split(f)[1] || "" : (A ? l(e) : e || "")[w](f, "")
                }

                function c(t) {
                    var e = 0 == H;
                    if (!(D <= H) && (H++, O.push(function () {
                            var e = d();
                            (t || e != m) && (L[S]("emit", e), m = e)
                        }), e)) {
                        for (; O.length;) O[0](), O.shift();
                        H = 0
                    }
                }

                function u(e) {
                    if (!(1 != e.which || e.metaKey || e.ctrlKey || e.shiftKey || e.defaultPrevented)) {
                        for (var t = e.target; t && "A" != t.nodeName;) t = t.parentNode;
                        !t || "A" != t.nodeName || t[k]("download") || !t[k]("href") || t.target && "_self" != t.target || -1 == t.href.indexOf(A.href.match(b)[0]) || (t.href == A.href || t.href.split("#")[0] != A.href.split("#")[0] && ("#" == f || 0 === l(t.href).indexOf(f)) && p(d(t.href), t.title || N.title)) && e.preventDefault()
                    }
                }

                function p(e, t, n) {
                    return M ? (e = f + o(e), t = t || N.title, n ? M.replaceState(null, t, e) : M.pushState(null, t, e), N.title = t, F = !1, c(), F) : L[S]("emit", d(e))
                }
                var h, f, m, g, v, b = /^.+?\/\/+[^\/]+/,
                    y = "EventListener",
                    x = "remove" + y,
                    _ = "add" + y,
                    k = "hasAttribute",
                    w = "replace",
                    C = "popstate",
                    T = "hashchange",
                    S = "trigger",
                    D = 3,
                    E = void 0 !== B && B,
                    N = "undefined" != typeof document && document,
                    M = E && history,
                    A = E && (M.location || E.location),
                    R = s.prototype,
                    j = N && N.ontouchstart ? "touchstart" : "click",
                    I = !1,
                    L = e.observable(),
                    F = !1,
                    O = [],
                    H = 0;
                R.m = function (e, t, n) {
                    !r(e) || t && !r(t) ? t ? this.r(e, t) : this.r("@", e) : p(e, t, n || !1)
                }, R.s = function () {
                    this.off("*"), this.$ = []
                }, R.e = function (n) {
                    this.$.concat("@").some(function (e) {
                        var t = ("@" == e ? g : v)(o(n), o(e));
                        if (void 0 !== t) return this[S].apply(null, [e].concat(t)), F = !0
                    }, this)
                }, R.r = function (e, t) {
                    "@" != e && (e = "/" + o(e), this.$.push(e)), this.on(e, t)
                };
                var P = new s,
                    q = P.m.bind(P);
                q.create = function () {
                    var e = new s,
                        t = e.m.bind(e);
                    return t.stop = e.s.bind(e), t
                }, q.base = function (e) {
                    f = e || "#", m = d()
                }, q.exec = function () {
                    c(!0)
                }, q.parser = function (e, t) {
                    e || t || (g = n, v = i), e && (g = e), t && (v = t)
                }, q.query = function () {
                    var i = {};
                    return (A.href || m)[w](/[?&](.+?)=([^&]*)/g, function (e, t, n) {
                        i[t] = n
                    }), i
                }, q.stop = function () {
                    I && (E && (E[x](C, h), E[x](T, h), N[x](j, u)), L[S]("stop"), I = !1)
                }, q.start = function (e) {
                    I || (E && ("complete" == document.readyState ? a(e) : E[_]("load", function () {
                        setTimeout(function () {
                            a(e)
                        }, 1)
                    })), I = !0)
                }, q.base(), q.parser(), e.route = q
            }(X);
        var le, de = function (e) {
                function t(e) {
                    return e
                }

                function n(e, t) {
                    return t || (t = v), new RegExp(e.source.replace(/{/g, t[2]).replace(/}/g, t[3]), e.global ? d : "")
                }

                function i(e) {
                    if (e === f) return m;
                    var t = e.split(" ");
                    if (2 !== t.length || /[\x00-\x1F<>a-zA-Z0-9'",;\\]/.test(e)) throw new Error('Unsupported brackets "' + e + '"');
                    return (t = t.concat(e.replace(/(?=[[\]()*+?.^$|])/g, "\\").split(" ")))[4] = n(1 < t[1].length ? /{[\S\s]*?}/ : m[4], t), t[5] = n(3 < e.length ? /\\({|})/g : m[5], t), t[6] = n(m[6], t), t[7] = RegExp("\\\\(" + t[3] + ")|([[({])|(" + t[3] + ")|" + p, d), t[8] = e, t
                }

                function a(e) {
                    return e instanceof RegExp ? r(e) : v[e]
                }

                function s(e) {
                    (e || (e = f)) !== v[8] && (v = i(e), r = e === f ? t : n, v[9] = r(m[9])), g = e
                }

                function o(e) {
                    var t;
                    t = (e = e || {}).brackets, Object.defineProperty(e, "brackets", {
                        set: s,
                        get: function () {
                            return g
                        },
                        enumerable: !0
                    }), l = e, s(t)
                }
                var r, l, d = "g",
                    c = /\/\*[^*]*\*+(?:[^*\/][^*]*\*+)*\//g,
                    u = /"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'/g,
                    p = u.source + "|" + /(?:\breturn\s+|(?:[$\w\)\]]|\+\+|--)\s*(\/)(?![*\/]))/.source + "|" + /\/(?=[^*\/])[^[\/\\]*(?:(?:\[(?:\\.|[^\]\\]*)*\]|\\.)[^[\/\\]*)*?(\/)[gim]*/.source,
                    h = {
                        "(": RegExp("([()])|" + p, d),
                        "[": RegExp("([[\\]])|" + p, d),
                        "{": RegExp("([{}])|" + p, d)
                    },
                    f = "{ }",
                    m = ["{", "}", "{", "}", /{[^}]*}/, /\\([{}])/g, /\\({)|{/g, RegExp("\\\\(})|([[({])|(})|" + p, d), f, /^\s*{\^?\s*([$\w]+)(?:\s*,\s*(\S+))?\s+in\s+(\S.*)\s*}/, /(^|[^\\]){=[\S\s]*?}/],
                    g = e,
                    v = [];
                return a.split = function b(e, t, n) {
                    function i(e) {
                        t || o ? d.push(e && e.replace(n[5], "$1")) : d.push(e)
                    }

                    function a(e, t, n) {
                        var i, a = h[t];
                        for (a.lastIndex = n, n = 1;
                            (i = a.exec(e)) && (!i[1] || (i[1] === t ? ++n : --n)););
                        return n ? e.length : a.lastIndex
                    }
                    n || (n = v);
                    var s, o, r, l, d = [],
                        c = n[6];
                    for (o = r = c.lastIndex = 0; s = c.exec(e);) {
                        if (l = s.index, o) {
                            if (s[2]) {
                                c.lastIndex = a(e, s[2], c.lastIndex);
                                continue
                            }
                            if (!s[3]) continue
                        }
                        s[1] || (i(e.slice(r, l)), r = c.lastIndex, (c = n[6 + (o ^= 1)]).lastIndex = r)
                    }
                    return e && r < e.length && i(e.slice(r)), d
                }, a.hasExpr = function y(e) {
                    return v[4].test(e)
                }, a.loopKeys = function x(e) {
                    var t = e.match(v[9]);
                    return t ? {
                        key: t[1],
                        pos: t[2],
                        val: v[0] + t[3].trim() + v[1]
                    } : {
                        val: e.trim()
                    }
                }, a.array = function _(e) {
                    return e ? i(e) : v
                }, Object.defineProperty(a, "settings", {
                    set: o,
                    get: function () {
                        return l
                    }
                }), a.settings = void 0 !== X && X.settings || {}, a.set = s, a.R_STRINGS = u, a.R_MLCOMMS = c, a.S_QBLOCKS = p, a
            }(),
            ce = function () {
                function n(e, t) {
                    return e ? (o[e] || (o[e] = a(e))).call(t, i) : e
                }

                function i(e, t) {
                    n.errorHandler && (e.riotData = {
                        tagName: t && t.root && t.root.tagName,
                        _riot_id: t && t._riot_id
                    }, n.errorHandler(e))
                }

                function a(e) {
                    var t = s(e);
                    return "try{return " !== t.slice(0, 11) && (t = "return " + t), new Function("E", t + ";")
                }

                function s(e) {
                    var t, n = [],
                        i = de.split(e.replace(l, '"'), 1);
                    if (2 < i.length || i[0]) {
                        var a, s, o = [];
                        for (a = s = 0; a < i.length; ++a)(t = i[a]) && (t = 1 & a ? r(t, 1, n) : '"' + t.replace(/\\/g, "\\\\").replace(/\r\n?|\n/g, "\\n").replace(/"/g, '\\"') + '"') && (o[s++] = t);
                        t = s < 2 ? o[0] : "[" + o.join(",") + '].join("")'
                    } else t = r(i[1], 0, n);
                    return n[0] && (t = t.replace(d, function (e, t) {
                        return n[t].replace(/\r/g, "\\r").replace(/\n/g, "\\n")
                    })), t
                }

                function r(s, e, n) {
                    function t(e, t) {
                        var n, i = 1,
                            a = f[e];
                        for (a.lastIndex = t.lastIndex; n = a.exec(s);)
                            if (n[0] === e) ++i;
                            else if (!--i) break;
                        t.lastIndex = i ? s.length : a.lastIndex
                    }
                    if (s = s.replace(h, function (e, t) {
                            return 2 < e.length && !t ? u + (n.push(e) - 1) + "~" : e
                        }).replace(/\s+/g, " ").trim().replace(/\ ?([[\({},?\.:])\ ?/g, "$1")) {
                        for (var i, a = [], o = 0; s && (i = s.match(p)) && !i.index;) {
                            var r, l, d = /,|([[{(])|$/g;
                            for (s = RegExp.rightContext, r = i[2] ? n[i[2]].slice(1, -1).trim().replace(/\s+/g, " ") : i[1]; l = (i = d.exec(s))[1];) t(l, d);
                            l = s.slice(0, i.index), s = RegExp.rightContext, a[o++] = c(l, 1, r)
                        }
                        s = o ? 1 < o ? "[" + a.join(",") + '].join(" ").trim()' : a[0] : c(s, e)
                    }
                    return s
                }

                function c(e, t, n) {
                    var s;
                    return e = e.replace(g, function (e, t, n, i, a) {
                        return n && (i = s ? 0 : i + e.length, "this" !== n && "global" !== n && "window" !== n ? (e = t + '("' + n + m + n, i && (s = "." === (a = a[i]) || "(" === a || "[" === a)) : i && (s = !v.test(a.slice(i)))), e
                    }), s && (e = "try{return " + e + "}catch(e){E(e,this)}"), n ? e = (s ? "function(){" + e + "}.call(this)" : "(" + e + ")") + '?"' + n + '":""' : t && (e = "function(v){" + (s ? e.replace("return ", "v=") : "v=(" + e + ")") + ';return v||v===0?v:""}.call(this)'), e
                }
                var o = {};
                n.haveRaw = de.hasRaw, n.hasExpr = de.hasExpr, n.loopKeys = de.loopKeys, n.errorHandler = null;
                var u = "\u2057",
                    p = /^(?:(-?[_A-Za-z\xA0-\xFF][-\w\xA0-\xFF]*)|\u2057(\d+)~):/,
                    h = RegExp(de.S_QBLOCKS, "g"),
                    l = /\u2057/g,
                    d = /\u2057(\d+)~/g,
                    f = {
                        "(": /[()]/g,
                        "[": /[[\]]/g,
                        "{": /[{}]/g
                    },
                    m = '"in this?this:' + ("object" != typeof B ? "global" : "window") + ").",
                    g = /[,{][$\w]+:|(^ *|[^$\w\.])(?!(?:typeof|true|false|null|undefined|in|instanceof|is(?:Finite|NaN)|void|NaN|new|Date|RegExp|Math)(?![$\w]))([$_A-Za-z][$\w]*)/g,
                    v = /^(?=(\.[$\w]+))\1(?:[^.[(]|$)/;
                return n.parse = function (e) {
                    return e
                }, n.version = de.version = "v2.3.22", n
            }(),
            ue = function e() {
                function e(e, t) {
                    var n = e && e.match(/^\s*<([-\w]+)/),
                        i = n && n[1].toLowerCase(),
                        a = p("div");
                    return e = o(e, t), c.test(i) ? a = s(a, e, i) : a.innerHTML = e, a.stub = !0, a
                }

                function s(e, t, n) {
                    var i = "o" === n[0],
                        a = i ? "select>" : "table>";
                    if (e.innerHTML = "<" + a + t.trim() + "</" + a, a = e.firstChild, i) a.selectedIndex = -1;
                    else {
                        var s = d[n];
                        s && 1 === a.childElementCount && (a = f(s, a))
                    }
                    return a
                }

                function o(e, n) {
                    if (!t.test(e)) return e;
                    var i = {};
                    return n = n && n.replace(r, function (e, t, n) {
                        return i[t] = i[t] || n, ""
                    }).trim(), e.replace(l, function (e, t, n) {
                        return i[t] || n || ""
                    }).replace(a, function (e, t) {
                        return n || t || ""
                    })
                }
                var t = /<yield\b/i,
                    a = /<yield\s*(?:\/>|>([\S\s]*?)<\/yield\s*>)/gi,
                    r = /<yield\s+to=['"]([^'">]*)['"]\s*>([\S\s]*?)<\/yield\s*>/gi,
                    l = /<yield\s+from=['"]?([-\w]+)['"]?\s*(?:\/>|>([\S\s]*?)<\/yield\s*>)/gi,
                    d = {
                        tr: "tbody",
                        th: "tr",
                        td: "tr",
                        col: "colgroup"
                    },
                    c = oe && oe < 10 ? n : /^(?:t(?:body|head|foot|[rhd])|caption|col(?:group)?)$/;
                return e
            }(),
            pe = function (e) {
                if (!B) return {
                    add: function () {},
                    inject: function () {}
                };
                var t = function () {
                        var e = p("style");
                        O(e, "type", "text/css");
                        var t = f("style[type=riot]");
                        return t ? (t.id && (e.id = t.id), t.parentNode.replaceChild(e, t)) : document.getElementsByTagName("head")[0].appendChild(e), e
                    }(),
                    n = t.styleSheet,
                    i = "";
                return Object.defineProperty(e, "styleNode", {
                    value: t,
                    writable: !0
                }), {
                    add: function (e) {
                        i += e
                    },
                    inject: function () {
                        i && (n ? n.cssText += i : t.innerHTML += i, i = "")
                    }
                }
            }(X),
            he = function (e) {
                var t = e.requestAnimationFrame || e.mozRequestAnimationFrame || e.webkitRequestAnimationFrame;
                if (!t || /iP(ad|hone|od).*OS 6/.test(e.navigator.userAgent)) {
                    var i = 0;
                    t = function (e) {
                        var t = Date.now(),
                            n = Math.max(16 - (t - i), 0);
                        setTimeout(function () {
                            e(i = t + n)
                        }, n)
                    }
                }
                return t
            }(B || {});
        X.util = {
            brackets: de,
            tmpl: ce
        }, X.mixin = (le = {}, function (e, t) {
            return j(e) ? (t = e, void(le[ee] = $(le[ee] || {}, t))) : t ? void(le[e] = t) : le[e]
        }), X.tag = function (e, t, n, i, a) {
            return R(i) && (a = i, /^[\w\-]+\s?=/.test(n) ? (i = n, n = "") : i = ""), n && (R(n) ? a = n : pe.add(n)), e = e.toLowerCase(), Z[e] = {
                name: e,
                tmpl: t,
                attrs: i,
                fn: a
            }, e
        }, X.tag2 = function (e, t, n, i, a) {
            return n && pe.add(n), Z[e] = {
                name: e,
                tmpl: t,
                attrs: i,
                fn: a
            }, e
        }, X.mount = function (e, i, a) {
            function t(e) {
                var t = "";
                return A(e, function (e) {
                    /[^-\w]/.test(e) || (e = e.trim().toLowerCase(), t += ",[" + ne + '="' + e + '"],[' + te + '="' + e + '"]')
                }), t
            }

            function n() {
                var e = Object.keys(Z);
                return e + t(e)
            }

            function s(e) {
                if (e.tagName) {
                    var t = F(e, ne) || F(e, te);
                    i && t !== i && (O(e, ne, t = i), O(e, te, i));
                    var n = b(e, t || e.tagName.toLowerCase(), a);
                    n && l.push(n)
                } else e.length && A(e, s)
            }
            var o, r, l = [];
            if (pe.inject(), j(i) && (a = i, i = 0), typeof e === ie ? ("*" === e ? e = r = n() : e += t(e.split(/, */)), o = e ? h(e) : []) : o = e, "*" === i) {
                if (i = r || n(), o.tagName) o = h(i, o);
                else {
                    var d = [];
                    A(o, function (e) {
                        d.push(h(i, e))
                    }), o = d
                }
                i = 0
            }
            return s(o), l
        }, X.update = function () {
            return A(Q, function (e) {
                e.update()
            })
        }, X.vdom = Q, X.Tag = M, typeof exports === x ? module.exports = X : typeof define === i && typeof define.amd !== ae ? define(function () {
            return X
        }) : B.riot = X
    }("undefined" != typeof window ? window : void 0), riot.tag2("guest_list", '<div class="guest-header"> <h1 class="page-title align-left">\u30b2\u30b9\u30c8\u4e00\u89a7</h1> <div class="submenu"> <a class="submenu-item excel" onclick="{modalOpen.bind(this, \'excel-dl\')}"> <image riot-src="{images.excelBrown}">\u4e00\u89a7<br class="pc-none">\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9 </a> <a class="submenu-item bell" onclick="{modalOpen.bind(this, \'bell\')}"> <image riot-src="{images.bell}">\u30b2\u30b9\u30c8\u767b\u9332<br class="pc-none">\u901a\u77e5\u8a2d\u5b9a </a> </div> <div class="notice-popup">{notice}</div> </div> <section class="guest-data-wrap mar-b20"> <div class="guest-data"> <dl> <dt class="attend">\u51fa\u5e2d</dt> <dd><span>{guestCount.attend}</span>\u540d</dd> </dl> <dl> <dt class="absence">\u6b20\u5e2d</dt> <dd><span>{guestCount.absence}</span>\u540d</dd> </dl> </div> <div class="add-guest"> <button type="button" class="button btn-add btn-small" __disabled="{!host.complete}" onclick="{modalOpen.bind(this, \'guest-edit\')}"> <span class="icon"></span>\u30b2\u30b9\u30c8\u767b\u9332 </button> </div> </section> <section class="guest-wrap"> <div class="search"> <div class="item-wrap"> <p class="item filter" onclick="{hideTooltip}">\u7d5e\u308a\u8fbc\u307f</p> <div class="tooltip arrow-top-left guest-list-filter"> <dl> <dt>\u51fa\u6b20</dt> <dd> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="search_param_attend" class="boxRadio-input" value="all" __checked="{searchParams.attend === \'all\'}" onchange="{search}"> <span class="boxRadio-parts">\u3059\u3079\u3066</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_attend" class="boxRadio-input" value="attendance" __checked="{searchParams.attend === \'attendance\'}" onchange="{search}"> <span class="boxRadio-parts">\u51fa\u5e2d</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_attend" class="boxRadio-input" value="absence" __checked="{searchParams.attend === \'absence\'}" onchange="{search}"> <span class="boxRadio-parts">\u6b20\u5e2d</span> </label> </div> </dd> </dl> <dl if="{host.use_eshugi}"> <dt>\u6c7a\u6e08</dt> <dd> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="search_param_settlement" class="boxRadio-input" value="all" __checked="{searchParams.settlement === \'all\'}" onchange="{search}"> <span class="boxRadio-parts">\u3059\u3079\u3066</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_settlement" class="boxRadio-input" value="paid" __checked="{searchParams.settlement === \'paid\'}" onchange="{search}"> <span class="boxRadio-parts">\u30af\u30ec\u30b8\u30c3\u30c8</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_settlement" class="boxRadio-input" value="not_paid" __checked="{searchParams.settlement === \'not_paid\'}" onchange="{search}"> <span class="boxRadio-parts">\u5f53\u65e5</span> </label> </div> </dd> </dl> <dl> <dt>\u62db\u5f85\u533a\u5206</dt> <dd> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="search_param_whos" class="boxRadio-input" value="all" __checked="{searchParams.whos === \'all\'}" onchange="{search}"> <span class="boxRadio-parts">\u3059\u3079\u3066</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_whos" class="boxRadio-input" value="bride" __checked="{searchParams.whos === \'bride\'}" onchange="{search}"> <span class="boxRadio-parts">\u65b0\u5a66\u53cb\u4eba</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_whos" class="boxRadio-input" value="groom" __checked="{searchParams.whos === \'groom\'}" onchange="{search}"> <span class="boxRadio-parts">\u65b0\u90ce\u53cb\u4eba</span> </label> </div> </dd> </dl> </div> </div> <div class="item-wrap"> <p class="item sort" onclick="{hideTooltip}">\u4e26\u3073\u9806</p> <div class="tooltip arrow-top-right guest-list-sort"> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="search_param_order" class="boxRadio-input" value="new" __checked="{searchParams.order === \'new\'}" onchange="{search}"> <span class="boxRadio-parts">\u65b0\u3057\u3044\u9806</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_order" class="boxRadio-input" value="old" __checked="{searchParams.order === \'old\'}" onchange="{search}"> <span class="boxRadio-parts">\u53e4\u3044\u9806</span> </label> </div> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="search_param_order" class="boxRadio-input" value="name_asc" __checked="{searchParams.order === \'name_asc\'}" onchange="{search}"> <span class="boxRadio-parts">\u540d\u524d\u6607\u9806</span> </label> <label class="boxRadio"> <input type="radio" name="search_param_order" class="boxRadio-input" value="name_desc" __checked="{searchParams.order === \'name_desc\'}" onchange="{search}"> <span class="boxRadio-parts">\u540d\u524d\u964d\u9806</span> </label> </div> </div> </div> </div> <div class="loading_img" if="{searching}"><image src="/assets/loading.gif"></div> <ul class="guest-list" if="{!searching}"> <li class="{guest.whosGuest}" each="{guest in guests}" onclick="{showGuestDetail}"> <div class="wrap"> <span class="status {guest.attendClass}">{guest.attendShort}</span> <div class="name">{guest.name}</div> <div class="gift" if="{host.use_eshugi === true}"> <span class="icon {guest.paymentClass}"></span> <span if="{guest.paymentMethod != 2}">{Number(guest.dineExpenseAmount || 0).toLocaleString()}\u5186</span> </div> </div> <ul class="companion" show="{guest.companions.length > 0}"> <li each="{companion in guest.companions}"> <span class="status {companion.attendClass}">{companion.attendShort}</span> <div class="name">{companion.name}</div> <div class="gift" if="{host.use_eshugi === true && host.purpose === \'kaihi\'}"> <span class="icon {guest.paymentClass}"></span> {guest.paymentMethod == 2 ? \'\' : Number(companion.dineExpenseAmount || null).toLocaleString() + \'\u5186\'} </div> </li> </ul> </li> </ul> </section> <section class="gift-wrap" if="{host.use_eshugi}"> <div class="gift-data"> <dl class="total"> <dt>\u304a\u632f\u8fbc\u984d\u5408\u8a08</dt> <dd>{Number(total.transfer || null).toLocaleString()}\u5186</dd> </dl> <dl class="breakdown"> <dt>\u5185\u8a33</dt> <dd> \u7dcf\u6c7a\u6e08\u984d{Number(total.amount || null).toLocaleString()}\u5186 \u2212 \u624b\u6570\u65995% ({Number(total.diff).toLocaleString()}\u5186) </dd> </dl> </div> </section> <div id="excel-dl" class="modal-content normal" show="{excelModal}"> <h2 class="modal-title">\u30b2\u30b9\u30c8\u4e00\u89a7\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9</h2> \u30c0\u30a6\u30f3\u30ed\u30fc\u30c9\u3057\u305f\u3044\u4e00\u89a7\u8868\u306e\u7a2e\u985e\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002<br> \u73fe\u5728\u4e00\u89a7\u3067\u8868\u793a\u3057\u3066\u3044\u308b\u4e26\u3073\u9806\u304c\u30d5\u30a1\u30a4\u30eb\u306b\u3082\u9069\u7528\u3055\u308c\u307e\u3059\u3002<br> <form name="excel_export" id="excel_export" action="/admin/guests/export_excel"> <input type="hidden" name="search_params[attend]" value="{searchParams.attend}"> <input type="hidden" name="search_params[settlement]" value="{searchParams.settlement}"> <input type="hidden" name="search_params[whos]" value="{searchParams.whos}"> <input type="hidden" name="search_params[order]" value="{searchParams.order}"> <div class="excel-dlselect"> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="export_type" class="boxRadio-input" value="all" checked="1" onchange="{setExportType}"> <span class="boxRadio-parts">\u5168\u4ef6</span> </label> <label class="boxRadio"> <input type="radio" name="export_type" class="boxRadio-input" value="search" onchange="{setExportType}"> <span class="boxRadio-parts">\u7d5e\u308a\u8fbc\u307f\u5168\u4ef6</span> </label> </div> </div> <div class="excel-dlbox"> <dl> <dt><image riot-src="{images.excelGreen}">\u76f4\u63a5\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9</dt> <dd> <button class="button btn-max excel" type="button" name="button" onclick="{excelDownload}">\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9</button> </dd> <dt> <image riot-src="{images.mail}">\u30e1\u30fc\u30eb\u3067\u4e00\u89a7\u30d5\u30a1\u30a4\u30eb\u3092\u9001\u4fe1 </dt> <dd class="flex"> <input class="textfield solid" type="text" name="email" value=""> <button class="button mail" type="button" name="button" onclick="{excelMail}">\u9001\u4fe1</button> </dd> </dl> </div> </form> <a class="modal-close" onclick="{modalClose}">\u9589\u3058\u308b</a> </div> <div id="bell" class="modal-content normal" show="{bellModal}"> <h2 class="modal-title">\u30b2\u30b9\u30c8\u767b\u9332\u901a\u77e5\u8a2d\u5b9a</h2> <div class="mar-b10"> \u30b2\u30b9\u30c8\u767b\u9332\u304c\u3042\u3063\u305f\u969b\u3001\u767b\u9332\u4eba\u6570\u3092\u30e1\u30fc\u30eb\u3067\u901a\u77e5\u3057\u307e\u3059\u3002\u8a2d\u5b9a\u3059\u308b\u3068\u3001\u671d10:00\u9803\u901a\u77e5\u30e1\u30fc\u30eb\u304c\u9001\u4fe1\u3055\u308c\u307e\u3059\u3002 </div> <div class="boxRadio-wrap mar-b10"> <label class="boxRadio"> <input type="radio" name="span" value="0" __checked="{host.span == 0}" class="boxRadio-input" onchange="{spanUpdate}"> <span class="boxRadio-parts">\u901a\u77e5\u3057\u306a\u3044</span> </label> <label class="boxRadio"> <input type="radio" name="span" value="1" __checked="{host.span == 1}" class="boxRadio-input" onchange="{spanUpdate}"> <span class="boxRadio-parts">1\u65e5\u3054\u3068</span> </label> </div> <div class="boxRadio-wrap"> <label class="boxRadio"> <input type="radio" name="span" value="3" __checked="{host.span == 3}" class="boxRadio-input" onchange="{spanUpdate}"> <span class="boxRadio-parts">3\u65e5\u3054\u3068</span> </label> <label class="boxRadio"> <input type="radio" name="span" value="7" __checked="{host.span == 7}" class="boxRadio-input" onchange="{spanUpdate}"> <span class="boxRadio-parts">7\u65e5\u3054\u3068</span> </label> </div> <a class="modal-close" onclick="{modalClose}"></a> </div> <div id="guest-edit" class="modal-content full guest" show="{edit === true}"> <h1 class="modal-header">\u30b2\u30b9\u30c8{editGuest.id ? \'\u7de8\u96c6\' : \'\u767b\u9332\'}</h1> <ul class="validation-message"> <li each="{error in errors}">{error}</li> </ul> <div class="formBox-wrap"> <div class="boxRadio-wrap attendance"> <label class="boxRadio"> <input type="radio" name="attend" value="attendance" __checked="{editGuest.attend === \'attendance\'}" class="boxRadio-input" onchange="{setGuestValue}"> <span class="boxRadio-parts">\u51fa\u5e2d</span> </label> <label class="boxRadio"> <input type="radio" name="attend" value="absence" __checked="{editGuest.attend === \'absence\'}" class="boxRadio-input" onchange="{setGuestValue}"> <span class="boxRadio-parts">\u6b20\u5e2d</span> </label> </div> <p class="text-caution" show="{editGuest.attend === \'absence\' && editGuest.paymentMethod == 0}"> \u6c7a\u6e08\u6e08\u307f\u306e\u304a\u795d\u3044\u91d1\u306f\u30ad\u30e3\u30f3\u30bb\u30eb\u3055\u308c\u307e\u305b\u3093\u3002<br class="pc-none">\u3054\u65b0\u90ce\u3054\u65b0\u5a66\u69d8\u3088\u308a \u3054\u8fd4\u91d1\u3092\u9802\u304d\u307e\u3059\u3088\u3046\u304a\u9858\u3044\u81f4\u3057\u307e\u3059\u3002 </p> <dl class="formBox"> <dt>\u6c0f\u540d</dt> <dd> <input type="text" name="name" value="{editGuest.name}" class="textfield fill" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u3075\u308a\u304c\u306a</dt> <dd> <input type="text" name="kana" value="{editGuest.kana}" class="textfield fill" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9</dt> <dd> <input type="text" name="email" class="textfield fill" value="{editGuest.email}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u6027\u5225</dt> <dd> <div class="basicRadio-wrap"> <label class="basicRadio"> <input type="radio" name="gender" value="male" __checked="{editGuest.gender === \'male\'}" class="basicRadio-input" onchange="{setGuestValue}"> <span class="basicRadio-parts">\u7537\u6027</span> </label> <label class="basicRadio"> <input type="radio" name="gender" value="female" __checked="{editGuest.gender === \'female\'}" class="basicRadio-input" onchange="{setGuestValue}"> <span class="basicRadio-parts">\u5973\u6027</span> </label> </div> </dd> </dl> <dl class="formBox"> <dt>\u90f5\u4fbf\u756a\u53f7</dt> <dd> <input type="text" name="postal_code" class="textfield fill" value="{editGuest.postalCode}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u4f4f\u6240</dt> <dd> <input type="text" name="address" class="textfield fill" value="{editGuest.address}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u96fb\u8a71\u756a\u53f7</dt> <dd> <input type="text" name="tel" class="textfield fill" value="{editGuest.tel}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u30a2\u30ec\u30eb\u30ae\u30fc</dt> <dd> <input type="text" name="allergy" class="textfield fill" value="{editGuest.allergy}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u62db\u5f85\u533a\u5206</dt> <dd> <div class="basicRadio-wrap wrap"> <label class="basicRadio"> <input type="radio" name="whos_guest" value="groom" __checked="{editGuest.whosGuest === \'groom\'}" class="basicRadio-input" onclick="{setGuestValue}"> <span class="basicRadio-parts">\u3054\u65b0\u90ce\u69d8\u62db\u5f85\u5ba2</span> </label> <label class="basicRadio"> <input type="radio" name="whos_guest" value="bride" __checked="{editGuest.whosGuest === \'bride\'}" class="basicRadio-input" onchange="{setGuestValue}"> <span class="basicRadio-parts">\u3054\u65b0\u5a66\u69d8\u62db\u5f85\u5ba2</span> </label> </div> </dd> </dl> <dl class="formBox"> <dt>{host.purpose === \'shugi\' ? \'\u3054\u795d\u5100\' : \'\u4f1a\u8cbb\'}</dt> <dd class="party-fees"> <input type="text" name="dine_expense_category" value="{editGuest.dineExpenseCategory}" class="textfield fill" placeholder="\u9805\u76ee\u540d" __readonly="{editGuest.paymentMethod == 0}" onchange="{setGuestValue}"> <input type="text" name="dine_expense_amount" value="{editGuest.dineExpenseAmount}" class="textfield fill" placeholder="{host.purpose === \'shugi\' ? \'\u3054\u795d\u5100\' : \'\u4f1a\u8cbb\'}" __readonly="{editGuest.paymentMethod == 0}" onchange="{setGuestValue}"> <small class="text-attention mar-t05" if="{editGuest.paymentMethod == 0}">\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u3054\u5229\u7528\u306e\u305f\u3081\u5909\u66f4\u3067\u304d\u307e\u305b\u3093</small> </dd> </dl> <dl class="formBox" if="{editGuest.otherFamilies.length > 0}"> <dt>\u540c\u884c\u8005</dt> <dd> <input type="text" name="other_families" class="textfield fill" value="{editGuest.otherFamilies}" onchange="{setGuestValue}"> </dd> </dl> <dl class="formBox"> <dt>\u5099\u8003</dt> <dd> <input type="text" name="note" class="textfield fill" value="{editGuest.note}" onchange="{setGuestValue}"> </dd> </dl> </div> <h2 class="modal-sub-title" show="{editCompanions.length > 0}">\u540c\u884c\u8005\u60c5\u5831</h2> <div class="formBox-wrap companion" each="{companion, i in editCompanions}" hide="{companion._destroy}"> <div class="boxRadio-wrap attendance"> <label class="boxRadio"> <input type="radio" name="companion_{i}_attend" value="attendance" __checked="{companion.attend === \'attendance\'}" class="boxRadio-input" onchange="{setCompanionValue.bind(this, \'attend\', i)}"> <span class="boxRadio-parts">\u51fa\u5e2d</span> </label> <label class="boxRadio"> <input type="radio" name="companion_{i}_attend" value="absence" __checked="{companion.attend === \'absence\'}" class="boxRadio-input" onchange="{setCompanionValue.bind(this, \'attend\', i)}"> <span class="boxRadio-parts">\u6b20\u5e2d</span> </label> </div> <dl class="formBox"> <dt>\u6c0f\u540d</dt> <dd> <input type="text" name="companion_{i}_name" value="{companion.name}" class="textfield fill" onchange="{setCompanionValue.bind(this, \'name\', i)}"> </dd> </dl> <dl class="formBox"> <dt>\u3075\u308a\u304c\u306a</dt> <dd> <input type="text" name="companion_{i}_kana" value="{companion.kana}" class="textfield fill" onchange="{setCompanionValue.bind(this, \'kana\', i)}"> </dd> </dl> <dl class="formBox"> <dt>\u30a2\u30ec\u30eb\u30ae\u30fc</dt> <dd> <input type="text" name="companion_{i}_allergy" value="{companion.allergy}" class="textfield fill" onchange="{setCompanionValue.bind(this, \'allergy\', i)}"> </dd> </dl> <dl class="formBox"> <dt>{host.purpose === \'shugi\' ? \'\u3054\u795d\u5100\' : \'\u4f1a\u8cbb\'}</dt> <dd class="party-fees"> <input type="text" name="companion_{i}_dine_expense_category" value="{companion.dineExpenseCategory}" class="textfield fill" placeholder="\u9805\u76ee\u540d" __readonly="{editGuest.paymentMethod == 0}" onchange="{setCompanionValue.bind(this, \'dine_expense_category\', i)}"> <input type="text" name="companion_{i}_dine_expense_amount" value="{companion.dineExpenseAmount}" class="textfield fill" placeholder="{host.purpose === \'shugi\' ? \'\u3054\u795d\u5100\' : \'\u4f1a\u8cbb\'}" __readonly="{editGuest.paymentMethod == 0}" onchange="{setCompanionValue.bind(this, \'dine_expense_amount\', i)}"> <small class="text-attention mar-t05" if="{editGuest.paymentMethod == 0}">\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u3054\u5229\u7528\u306e\u305f\u3081\u5909\u66f4\u3067\u304d\u307e\u305b\u3093</small> </dd> </dl> <div class="delete" onclick="{deleteCompanion.bind(this, i)}"></div> </div> <div class="button-bar"> <a class="button btn-add btn-middle" onclick="{addCompanion}"><span class="icon"></span>\u540c\u884c\u8005\u3092\u8ffd\u52a0</a> </div> <div class="button-bar"> <a class="button btn-solid btn-small" onclick="{editCancel}">\u623b\u308b</a> <a class="button btn-submit btn-small" onclick="{save}">\u4fdd\u5b58\u3059\u308b</a> </div> <a class="modal-close" onclick="{modalClose}"></a> </div> <div id="guest-detail" class="modal-content full guest" show="{editGuest.id != null && edit == false}"> <div if="{editGuest.id != null}"> <div class="guest-status"> <span class="status {editGuest.whosGuest} {editGuest.attendClass}">{editGuest.attendLong}</span> <h2 class="guest-name"> <span class="kana">{editGuest.kana}</span> {editGuest.name}\u69d8 </h2> </div> <div class="formBox-wrap"> <dl class="formBox"> <dt>\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9</dt> <dd>{editGuest.email}</dd> </dl> <dl class="formBox"> <dt>\u6027\u5225</dt> <dd>{editGuest.genderJp}</dd> </dl> <dl class="formBox"> <dt>\u90f5\u4fbf\u756a\u53f7</dt> <dd>{editGuest.postalCode || \'-\'}</dd> </dl> <dl class="formBox"> <dt>\u4f4f\u6240</dt> <dd>{editGuest.address || \'-\'}</dd> </dl> <dl class="formBox"> <dt>\u96fb\u8a71\u756a\u53f7</dt> <dd>{editGuest.tel || \'-\'}</dd> </dl> <dl class="formBox"> <dt>\u30a2\u30ec\u30eb\u30ae\u30fc</dt> <dd>{editGuest.allergy || \'-\'}</dd> </dl> <dl class="formBox"> <dt>{host.purpose === \'shugi\' ? \'\u3054\u795d\u5100\' : \'\u4f1a\u8cbb\'}</dt> <dd>{editGuest.dineExpense}</dd> </dl> <dl class="formBox" if="{editGuest.otherFamilies.length > 0}"> <dt>\u540c\u884c\u8005</dt> <dd>{editGuest.otherFamilies}</dd> </dl> <dl class="formBox"> <dt>\u5099\u8003</dt> <dd>{editGuest.note || \'-\'}</dd> </dl> </div> <div show="{editCompanions.length > 0}"> <h2 class="modal-sub-title">\u540c\u884c\u8005\u60c5\u5831</h2> <div class="companion-status"> <dl each="{companion in editCompanions}"> <dt class="{companion.attendClass}">{companion.attendLong}</dt> <dd> <div class="companion-name"> <span class="kana">{companion.kana || \'-\'}</span> {companion.name || \'-\'} \u69d8 </div> <div class="gift" if="{host.purpose === \'kaihi\'}"> {companion.dineExpense} </div> <div class="allergy" show="{companion.allergy}"> \u30a2\u30ec\u30eb\u30ae\u30fc\uff1a {companion.allergy} </div> </dd> </dl> </div> </div> <div class="guest-image" if="{editGuest.recentImage}"> <img riot-src="{editGuest.recentImage}"> </div> <div class="guest-message">{editGuest.message}</div> <div class="button-bar"> <input type="button" value="\u524a\u9664" class="button btn-delete btn-small" __disabled="{editGuest.entryFlg == false}" onclick="{deleteGuest}"> <a class="button btn-normal btn-small" onclick="{modalOpen.bind(this, \'guest-edit\')}">\u7de8\u96c6</a> </div> </div> <a class="modal-close" onclick="{modalClose}"></a> <a class="modal-pager right" onclick="{changeGuest.bind(this, \'next\')}"></a> <a class="modal-pager left" onclick="{changeGuest.bind(this, \'prev\')}"></a> </div> <div class="modal-overlay" if="{showOverlay}" onclick="{modalClose}"></div>', "", "", function (e) {
        var i = this;
        i.host = e.data.host, i.guests = e.data.guests, i.guestCount = e.data.guestCount, i.total = e.data.total, i.searchParams = e.data.searchParams, i.images = e.images, i.edit = !1, i.editGuest = {}, i.editCompanions = [], i.excelModal = !1, i.bellModal = !1, i.showOverlay = !1, i.searching = !1, i.notice = null, i.errors = [], this.on("mount", function () {
            $(".item").click(function () {
                $(this).next().fadeToggle()
            }), $(".blank-data dt").click(function () {
                $(this).toggleClass("close"), $(this).next().slideToggle()
            })
        }), showNotice = function (e) {
            modalClose(), i.notice = e, i.update(), setTimeout(function () {
                i.notice = null, i.update()
            }, 3e3)
        }, modalResize = function (e) {
            var t = document.getElementById(e),
                n = $(window).width(),
                i = $(window).height(),
                a = (n - $(t).outerWidth(!0)) / 2,
                s = (i - $(t).outerHeight(!0)) / 2;
            $(t).css({
                left: a + "px",
                top: s + "px"
            })
        }, modalClose = function () {
            i.edit = !1, i.editGuest = {}, i.editCompanions = [], i.excelModal = !1, i.bellModal = !1, i.showOverlay = !1, i.errors = []
        }, this.modalOpen = function (e) {
            switch (e) {
                case "excel-dl":
                    i.excelModal = !0;
                    break;
                case "bell":
                    i.bellModal = !0;
                    break;
                case "guest-edit":
                    i.edit = !0;
                    break;
                default:
                    return
            }
            i.showOverlay = !0, modalResize(e)
        }.bind(this), this.showGuestDetail = function (e) {
            var t = JSON.parse(JSON.stringify(e.item.guest));
            i.editGuest = t, i.editCompanions = t.companions || [{}], i.showOverlay = !0, modalResize("guest-detail")
        }.bind(this), this.editCancel = function () {
            i.edit = !1
        }.bind(this), this.setGuestValue = function (e) {
            var t = e.target.name;
            "gender" === t && e.target.value === i.editGuest[t] ? i.editGuest[t] = null : i.editGuest[t] = e.target.value
        }.bind(this), this.deleteGuest = function () {
            0 != i.editGuest.entryFlg ? $.ajax({
                method: "DELETE",
                dataType: "json",
                url: "/admin/guests/" + i.editGuest.id
            }).done(function (e) {
                i.guests = e.guests, i.guestCount = e.guestCount, modalClose()
            }).fail(function (e) {
                i.errors = JSON.parse(e.responseText)
            }).always(function () {
                i.update()
            }) : alert("\u30d5\u30a9\u30fc\u30e0\u304b\u3089\u56de\u7b54\u3055\u308c\u305f\u30b2\u30b9\u30c8\u60c5\u5831\u306f\u524a\u9664\u3067\u304d\u307e\u305b\u3093")
        }.bind(this), this.setCompanionValue = function (e, t, n) {
            i.editCompanions[t][e] = n.target.value
        }.bind(this), this.addCompanion = function () {
            i.editCompanions.push({
                entry_flg: 1
            })
        }.bind(this), this.deleteCompanion = function (e) {
            i.editCompanions.slice(e, e + 1)[0]._destroy = !0
        }.bind(this), this.hideTooltip = function (t) {
            document.querySelectorAll(".tooltip").forEach(function (e) {
                e !== t.target.nextElementSibling && (e.style.display = "none")
            })
        }.bind(this), this.spanUpdate = function (e) {
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/guests/span_update",
                data: {
                    span: e.target.value
                }
            }).done(function (e) {
                showNotice(e.message)
            })
        }.bind(this), this.save = function () {
            i.errors = [], null == i.editGuest.attend && i.errors.push("\u30b2\u30b9\u30c8\u306e\u51fa\u6b20\u304c\u672a\u767b\u9332\u3067\u3059"), 0 < i.editCompanions.filter(function (e) {
                return null == e.attend
            }).lenght && i.errors.push("\u540c\u884c\u8005\u306e\u51fa\u6b20\u304c\u672a\u767b\u9332\u3067\u3059"), 0 < i.errors.length ? document.querySelector(".modal-header").scrollIntoView() : (i.editGuest.id ? (type = "PATCH", url = "/admin/guests/" + i.editGuest.id) : (type = "POST",
                url = "/admin/guests", i.editGuest.entry_flg = !0), i.editGuest.host_id = i.editGuest.host_id || i.host.id, i.editGuest.companions_attributes = i.editCompanions, i.editGuest.is_edit = !0, $.ajax({
                type: type,
                dataType: "json",
                url: url,
                data: {
                    guest: i.editGuest
                }
            }).done(function (e) {
                i.editGuest.id ? (i.guests = e.guests, i.guestCount = e.guestCount, modalClose()) : window.location.reload()
            }).fail(function (e) {
                i.errors = JSON.parse(e.responseText)
            }).always(function () {
                i.update()
            }))
        }.bind(this), this.search = function (e) {
            i.searching = !0;
            var t = e.target.name.split("_")[2];
            i.searchParams[t] = e.target.value, $.ajax({
                type: "GET",
                dataType: "json",
                url: "/admin/guests/search",
                data: {
                    search_params: i.searchParams
                }
            }).done(function (e) {
                i.guests = e.guests, i.guestCount = e.guestCount
            }).always(function () {
                i.searching = !1, i.update()
            })
        }.bind(this), this.changeGuest = function (e) {
            var t = i.guests.map(function (e) {
                return e.id
            }).indexOf(i.editGuest.id);
            if (!(-1 === t || 0 === t && "prev" === e || t === i.guests.length - 1 && "next" === e)) {
                var n = i.guests["next" === e ? t + 1 : t - 1];
                i.editGuest = JSON.parse(JSON.stringify(n)), i.update()
            }
        }.bind(this), this.excelDownload = function (e) {
            e.target.form.submit(), showNotice("\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9\u304c\u5b8c\u4e86\u3057\u307e\u3057\u305f")
        }.bind(this), this.excelMail = function () {
            i.searching = !0;
            var e = document.querySelector("[name='email']").value,
                t = document.querySelector("[name='export_type']").value;
            $.ajax({
                type: "GET",
                dataType: "json",
                url: "/admin/guests/send_excel",
                data: {
                    email: e,
                    export_type: t,
                    search_params: i.searchParams
                }
            }).done(function (e) {
                showNotice(e.message)
            }).fail(function () {
                showNotice("\u30e1\u30fc\u30eb\u306e\u9001\u4fe1\u306b\u5931\u6557\u3057\u307e\u3057\u305f")
            }).always(function () {
                i.searching = !1, i.update()
            })
        }.bind(this)
    }), riot.tag2("raw", "<span></span>", "", "", function (e) {
        this.root.innerHTML = e.content.replace(/\r?\n/g, "<br>")
    }), riot.tag2("guest_details", '<section> <h1 class="section-title">\u30b2\u30b9\u30c8\u4e00\u89a7</h1> <table class="footable"> <tr class="manage_commit"> <th>No.</th> <th>\u540d\u524d</th> <th>\u51fa\u6b20</th> <th>\u652f\u6255\u65b9\u6cd5</th> <th>\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9</th> <th>\u96fb\u8a71\u756a\u53f7</th> <th>\u6c7a\u6e08\u7528\u30aa\u30fc\u30c0\u30fc</th> <th>\u6c7a\u6e08\u984d(\u5185\u624b\u6570\u65995%)</th> </tr> <tr class="manage_commit" each="{guest, i in guests}"> <td>{i + 1}</td> <td id="{\'guest_\' + guest.id}" onclick="{showGuest}">{guest.name}</td> <td>{guest.attend}</td> <td> {guest.paymentMethod} </td> <td>{guest.email.length > 0 ? guest.email : \'\u672a\u767b\u9332\'}</td> <td>{guest.tel || \'-\'}</td> <td>{guest.serviceOrder || \'-\'}</td> <td> <p show="{guest.amount > 0}">{guest.amount.toLocaleString()}\u5186({(guest.amount-guest.dineExpense).toLocaleString()}\u5186)</p> <p hide="{guest.amount > 0}">-</p> </td> </tr> <tr class="sum manage_commit"> <td colspan="2">\u5408\u8a08</td> <td></td> <td></td> <td></td> <td></td> <td></td> <td> <p show="{useEshugi}"> {opts.data.amountSum.toLocaleString()}<span class="font10">\u5186</span><br> <span class="font10">({(opts.data.amountSum - opts.data.expenseSum).toLocaleString()}\u5186)</span> </p> <p hide="{useEshugi}">-</p> </td> </tr> </table> <div each="{guest, i in guests}" class="guest_detail_modal" id="{\'detail_\' + guest.id}"> <h2 class="section-title"> \u30b2\u30b9\u30c8\u60c5\u5831\u8a73\u7d30 <div class="cursors"> <a hide="{guests[i - 1] == undefined}" href="{\'#guest_\' + guests[i - 1].id}" onclick="{nextGuest}" id="{\'prev_\' + guest.id}" class="prev_cursor">\u524d\u3078</a> <p show="{guests[i - 1] == undefined}" class="prev_cursor">\u524d\u3078</p> <a hide="{guests[i + 1] == undefined}" href="{\'#guest_\' + guests[i + 1].id}" onclick="{nextGuest}" id="{\'next_\' + guest.id}" class="next_cursor">\u6b21\u3078</a> <p show="{guests[i + 1] == undefined}" class="next_cursor">\u6b21\u3078</p> </div> </h2> <table class="tableInfo"> <tr> <th>\u304a\u540d\u524d</th> <td>{guest.name}</td> </tr> <tr> <th>\u51fa\u6b20</th> <td>{guest.attend}</td> </tr> <tr> <th>\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9</th> <td>{guest.email}</td> </tr> <tr> <th>\u30a2\u30ec\u30eb\u30ae\u30fc</th> <td>{guest.allergy}</td> </tr> <tr if="{host.useEshugi}"> <th>\u6c7a\u6e08\u984d</th> <td></td> </tr> <tr> <th>\u56de\u7b54\u65e5</th> <td>{guest.repliedDate}</td> </tr> </table> <h2 class="section-title" if="{guest.companions.length > 0}">\u30b2\u30b9\u30c8\u540c\u884c\u8005\u8a73\u7d30</h2> <table class="tableInfo"> <tr each="{companion in guest.companions}"> <th>\u304a\u540d\u524d(\u304b\u306a)</th> <td>{companion.name}({companion.kana})</td> <th>\u30a2\u30ec\u30eb\u30ae\u30fc</th> <td>{companion.allergy}</td> </tr> </table> <h2 class="section-title">\u56de\u7b54\u5185\u5bb9</h2> <table class="tableInfo"> <tr> <th>\u753b\u50cf</th> <td show="{guest.recentImage.length > 0}" ondragstart="return false;" oncontextmenu="return false;"><img riot-src="{guest.recentImage}"></td> <td hide="{guest.recentImage.length > 0}">\u306a\u3057</td> </tr> <tr> <th>\u30e1\u30c3\u30bb\u30fc\u30b8</th> <td><pre>{guest.message}</pre></td> </tr> </table> </div> <div class="overlay"></div>', "", "", function (e) {
        var t = this;
        t.guests = e.data.guests, t.useEshugi = e.data.useEshugi, this.on("mount", function () {
            $(".overlay").on("click", function () {
                $('[id^="detail_"]').fadeOut("fast"), $(".overlay").fadeOut("fast")
            })
        }), this.showGuest = function (e) {
            var t = e.target.id.split("_")[1];
            $(".overlay").fadeIn("fast"), $("#detail_" + t).fadeIn("fast")
        }.bind(this), this.nextGuest = function (e) {
            var t = e.target.id.split("_")[1],
                n = e.target.href.split("#")[1].split("_")[1];
            $("#detail_" + t).hide(), $("#detail_" + n).show()
        }.bind(this)
    }), riot.tag2("new_settlement", '<div if="{guest.errors.length > 0}" class="caution"> <ul><li>\u672a\u5165\u529b\u9805\u76ee\u304c\u3042\u308a\u307e\u3059</li></ul> </div> <h3 class="topic-s"><span class="required">\u5fc5\u9808</span>\u51fa\u6b20</h3> <div class="cont_box"> <div class="reply_invitation"> <label class="{radio-yes: true, c_off: guest.attend == null, c_on: guest.attend === \'attendance\'}"> <input type="radio" name="guest[attend]" value="attendance" onchange="{checkAttend}" __checked="{guest.attend === \'attendance\'}"> </label> <label class="{radio-no: true, c_off: guest.attend == null, c_on: guest.attend === \'absence\'}"> <input type="radio" name="guest[attend]" value="absence" onchange="{checkDontAttend}" __checked="{guest.attend === \'absence\'}"> </label> </div> <p if="{guest.errors.attend}" class="text-center text-caution">\u3054\u51fa\u5e2d\u30fb\u3054\u6b20\u5e2d\u3092\u3054\u9078\u629e\u304f\u3060\u3055\u3044</p> </div> <h2 class="sub-title">\u53c2\u52a0\u8005\u60c5\u5831</h2> <div class="formBox-wrap"> <dl class="formBox solid-btm"> <dt><span class="required">\u5fc5\u9808</span>\u540d\u524d</dt> <dd> <input class="textfield fill" type="text" name="guest[name]" placeholder="\u7530\u4e2d\u592a\u90ce" value="{guest.name}" class="{field_with_errors: guest.errors.name}"> <p if="{guest.errors.name}" class="text-caution">\u304a\u540d\u524d\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm"> <dt><span class="required">\u5fc5\u9808</span>\u3075\u308a\u304c\u306a</dt> <dd> <input type="text" class="textfield fill" name="guest[kana]" placeholder="\u305f\u306a\u304b\u305f\u308d\u3046" value="{guest.kana}" class="{field_with_errors: guest.errors.kana}"> <p if="{guest.errors.kana}" class="text-caution">\u3075\u308a\u304c\u306a\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm"> <dt class="pos-rel"> <span class="required">\u5fc5\u9808</span> <span class="font11">\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9</span> <div class="tooltip-mail"> <span class="icon">\uff1f</span> <div class="box">\u767b\u9332\u5b8c\u4e86\u7b49\u3092\u3054\u6848\u5185\u3059\u308b\u3068\u304d\u306b\u5229\u7528\u3057\u307e\u3059\u3002</div> </div> </dt> <dd> <input class="textfield fill" name="guest[email]" placeholder="tanaka@example.co.jp" value="{guest.email}" class="{field_with_errors: guest.errors.email}" type="{\'email\'}"> <p if="{guest.errors.email}" class="text-caution">\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_gender !== 2}"> <dt><span class="required" if="{formSetting.need_gender === 1}">\u5fc5\u9808</span>\u6027\u5225</dt> <dd> <div class="basicCheck-wrap"> <label class="basicCheck"> <input class="basicCheck-input" type="checkbox" name="guest[gender]" value="male" id="male" __checked="{guest.gender == \'male\'}" onclick="{removeCheck}"> <span class="basicCheck-parts">\u7537\u6027</span> </label> <label class="basicCheck"> <input class="basicCheck-input" type="checkbox" name="guest[gender]" value="female" id="female" __checked="{guest.gender == \'female\'}" onclick="{removeCheck}"> <span class="basicCheck-parts">\u5973\u6027</span> </label> </div> <p if="{guest.errors.gender}" class="text-caution">\u6027\u5225\u3092\u3054\u9078\u629e\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_postal_code !== 2}"> <dt><span class="required" if="{formSetting.need_postal_code === 1}">\u5fc5\u9808</span>\u90f5\u4fbf\u756a\u53f7</dt> <dd> <input class="textfield fill" type="text" name="guest[postal_code]" placeholder="0123456" value="{guest.postal_code}" class="{field_with_errors: guest.errors.postal_code}"> <p if="{guest.errors.postal_code}" class="text-caution">\u90f5\u4fbf\u756a\u53f7\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_address !== 2}"> <dt><span if="{formSetting.need_address === 1}" class="required">\u5fc5\u9808</span>\u4f4f\u6240</dt> <dd> <textarea class="textarea fill" name="guest[address]" placeholder="\u6771\u4eac\u90fd\u5343\u4ee3\u7530\u533a..." class="{field_with_errors: guest.errors.address}"> {guest.address} </textarea> <p if="{guest.errors.address}" class="text-caution">\u4f4f\u6240\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_tel !== 2}"> <dt><span if="{formSetting.need_tel === 1}" class="required">\u5fc5\u9808</span>\u96fb\u8a71\u756a\u53f7</dt> <dd> <input class="textfield fill" type="tel" name="guest[tel]" placeholder="0123456789" value="{guest.tel}" class="{field_with_errors: guest.errors.tel}"> <p if="{guest.errors.tel}" class="text-caution">\u96fb\u8a71\u756a\u53f7\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_allergy !== 2}"> <dt><span if="{formSetting.need_allergy === 1}" class="required">\u5fc5\u9808</span>\u30a2\u30ec\u30eb\u30ae\u30fc</dt> <dd> <input class="textfield fill" type="text" name="guest[allergy]" value="{guest.allergy}" class="{field_with_errors: guest.errors.allergy}"> <p if="{guest.errors.allergy}" class="text-caution">\u30a2\u30ec\u30eb\u30ae\u30fc\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_whos_guest !== 2}"> <dt class="pos-rel"> <span class="required">\u5fc5\u9808</span>\u62db\u5f85\u533a\u5206 <div class="tooltip-whos"> <span class="icon">\uff1f</span> <div class="box">\u3054\u65b0\u90ce\u69d8\u3054\u65b0\u5a66\u69d8\u306e\u3069\u3061\u3089\u304b<br>\u3054\u62db\u5f85\u9802\u3044\u305f\u65b9\u3092\u304a\u9078\u3073\u304f\u3060\u3055\u3044\u3002</div> </div> </dt> <dd> <div class="basicCheck-wrap"> <label class="basicCheck"> <input class="basicCheck-input" type="radio" name="guest[whos_guest]" value="groom" __checked="{guest.whos_guest === \'groom\'}"> <span class="basicCheck-parts">\u65b0\u90ce</span> </label> <label class="basicCheck"> <input class="basicCheck-input" type="radio" name="guest[whos_guest]" value="bride" __checked="{guest.whos_guest === \'bride\'}"> <span class="basicCheck-parts">\u65b0\u5a66</span> </label> </div> <p if="{guest.errors.whos_guest}" class="text-caution">\u62db\u5f85\u533a\u5206\u3092\u3054\u9078\u629e\u304f\u3060\u3055\u3044</p> </dd> </dl> <dl class="formBox solid-btm" if="{host.purpose === \'kaihi\' && guest.attend !== \'absence\'}"> <dt><span class="required">\u5fc5\u9808</span>\u4f1a\u8cbb</dt> <dd> <div class="basicRadio-wrap wrap"> <label class="basicRadio" each="{de in dineExpenses}"> <input type="radio" class="basicRadio-input" name="guest[dine_expense_id]" value="{de.id}" __checked="{de.category === guest.dine_expense_category}" onchange="{dineExpenseSelect.bind(this, guest)}"> <span class="basicRadio-parts">{de.display}</span> </label> </div> <p if="{guest.errors.dine_expense_id}" class="text-caution">\u4f1a\u8cbb\u3092\u3054\u9078\u629e\u304f\u3060\u3055\u3044</p> </dd> </dl> <input type="hidden" name="guest[dine_expense_category]" value="{guest.dine_expense_category}"> <input type="hidden" name="guest[dine_expense_amount]" value="{guest.dine_expense_amount}"> <p class="text-attention"> \u203b\u540c\u3058\u304a\u540d\u524d\u3068\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u3067\u306e\u767b\u9332\u306f\u4e00\u5ea6\u304d\u308a\u3067\u3059\u3002\u518d\u5ea6\u767b\u9332\u3055\u308c\u308b\u969b\u306f\u304a\u540d\u524d\u3092\u3054\u5909\u66f4\u304f\u3060\u3055\u3044\u3002<br> <span show="{host.use_eshugi}">\u203b\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u306e\u5834\u5408\u306e\u53e3\u5ea7\u540d\u7fa9\u306f\u4f55\u5ea6\u3067\u3082\u3054\u5229\u7528\u3044\u305f\u3060\u3051\u307e\u3059\u3002</span> </p> </div> <h2 class="sub-title">\u540c\u884c\u8005\u60c5\u5831</h2> <div class="formBox-wrap companion" each="{companion, i in companions}"> <input type="hidden" value="{companion.id}" name="guest[companions_attributes][{i}][id]"> <dl class="formBox solid-btm"> <dt>\u51fa\u6b20</dt> <dd> <div class="basicCheck-wrap"> <label class="basicCheck"> <input class="basicCheck-input" type="radio" value="attendance" name="guest[companions_attributes][{i}][attend]" __checked="{companion.attend === \'attendance\'}"> <span class="basicCheck-parts">\u51fa\u5e2d</span> </label> <label class="basicCheck"> <input class="basicCheck-input" type="radio" value="absence" name="guest[companions_attributes][{i}][attend]" __checked="{companion.attend === \'absence\'}"> <span class="basicCheck-parts">\u6b20\u5e2d</span> </label> </div> </dd> </dl> <dl class="formBox solid-btm"> <dt>\u540d\u524d</dt> <dd> <input class="textfield fill" type="text" name="guest[companions_attributes][{i}][name]" value="{companion.name}"> </dd> </dl> <dl class="formBox solid-btm"> <dt>\u3075\u308a\u304c\u306a</dt> <dd> <input class="textfield fill" type="text" name="guest[companions_attributes][{i}][kana]" value="{companion.kana}"> </dd> </dl> <dl class="formBox solid-btm" if="{formSetting.need_allergy !== 2}"> <dt>\u30a2\u30ec\u30eb\u30ae\u30fc</dt> <dd> <input class="textfield fill" type="text" name="guest[companions_attributes][{i}][allergy]" value="{companion.allergy}"> </dd> </dl> <dl class="formBox solid-btm" if="{host.purpose === \'kaihi\'}"> <dt>\u4f1a\u8cbb</dt> <dd> <div class="basicRadio-wrap wrap"> <label class="basicRadio" each="{de in dineExpenses}"> <input type="radio" class="basicRadio-input" name="guest[companions_attributes][{i}][dine_expense_id]" value="{de.id}" __checked="{companion.dine_expense_category === de.category}" onchange="{dineExpenseSelect.bind(this, companion)}"> <span class="basicRadio-parts">{de.category}\uff1a {Number(de.amount || null).toLocaleString()}\u5186</span> </label> </div> </dd> </dl> <input type="hidden" name="guest[companions_attributes][{i}][dine_expense_category]" value="{companion.dine_expense_category}"> <input type="hidden" name="guest[companions_attributes][{i}][dine_expense_amount]" value="{companion.dine_expense_amount}"> <input type="hidden" name="guest[companions_attributes][{i}][_destroy]" value="0"> <div class="delete" onclick="{deleteCompanion.bind(this, i)}"></div> </div> <div class="button-bar"> <button type="button" class="button btn-add btn-middle" onclick="{addCompanion}"> <span class="icon"></span>\u540c\u884c\u8005\u3092\u8ffd\u52a0 </button> </div> <h2 class="sub-title">\u5099\u8003</h2> <div class="formBox-wrap"> <textarea class="textarea fill" name="guest[note]">{guest.note}</textarea> </div> <div if="{formSetting.need_message !== 2}"> <h2 class="sub-title"> <span if="{formSetting.need_message === 1}" class="required">\u5fc5\u9808</span>\u30e1\u30c3\u30bb\u30fc\u30b8 </h2> <div class="formBox-wrap"> <textarea class="textarea fill" name="guest[message]" class="{field_with_errors: guest.errors.message}">{guest.message}</textarea> <p if="{guest.errors.message}" class="text-caution">\u30e1\u30c3\u30bb\u30fc\u30b8\u3092\u3054\u5165\u529b\u304f\u3060\u3055\u3044</p> <p class="text-caution">\u7d75\u6587\u5b57\u306f\u3054\u5229\u7528\u3044\u305f\u3060\u3051\u307e\u305b\u3093\u306e\u3067\u3001\u3054\u6ce8\u610f\u304f\u3060\u3055\u3044\u3002</p> </div> </div> <div if="{formSetting.need_image !== 2}"> <h2 class="sub-title icon-right pos-rel"> <span if="{formSetting.need_image === 1}" class="required">\u5fc5\u9808</span>\u304a\u5199\u771f <div class="tooltip-picture"> <span class="icon">\uff1f</span> <div class="box">\u56de\u7b54\u3068\u540c\u6642\u306b\u30db\u30b9\u30c8\u3078\u5199\u771f\u3092\u8d08\u308b\u3053\u3068\u304c\u3067\u304d\u307e\u3059\u3002</div> </div> </h2> <div class="imgInput img-box"> <img riot-src="{guest.recent_image.url ? guest.recent_image.url : noImage}" alt="\u8fd1\u6cc1\u753b\u50cf" class="imgView"> <label class="btn-dropshadow fileup"> <input multiple type="file" name="guest[recent_image]" accept="image/*"> <input type="hidden" name="guest[recent_image_cache]" value="{guest.recent_image_cache}"> <div class="left">\u753b\u50cf</div> <span class="button btn-xsmall btn-normal">\u9078\u629e</span> </label> <p if="{guest.errors.image}" class="text-caution">\u304a\u5199\u771f\u3092\u3054\u767b\u9332\u304f\u3060\u3055\u3044</p> </div> </div> <div class="memo-confirm" show="{host.note.length > 0}"> <p>\u5099\u8003</p> <pre>{host.note}</pre> </div> <div class="credit_box" if="{host.use_eshugi}"> <h2 class="sub-title icon-right">{settlementTitle}\u306e\u304a\u6e21\u3057<a href="/terms_guest" class="contract">\u3054\u5229\u7528\u898f\u7d04</a></h2> <div class="cont_box font13" if="{!canSettlement}"> <s if="{guest.attend === \'absence\'}"><br>\u3054\u6b20\u5e2d\u3092\u3055\u308c\u307e\u3059\u304a\u5ba2\u69d8\u3082\u3001\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u306b\u3066\u3054\u65b0\u90ce\u3054\u65b0\u5a66\u69d8\u3078\u304a\u795d\u3044\u91d1\u306e\u304a\u6e21\u3057\u304c\u53ef\u80fd\u3067\u3054\u3056\u3044\u307e\u3059\u3002</s> <p>\u8fd4\u4fe1\u671f\u65e5\u3092\u8d85\u904e\u3057\u3066\u3044\u308b\u305f\u3081\u3001{settlementTitle}\u306e\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u306f\u3054\u5229\u7528\u3044\u305f\u3060\u3051\u307e\u305b\u3093\u3002</p> </div> <div class="cont_box font13" if="{canSettlement}"> <pre>{formSetting.settlement_note}</pre> <p if="{guest.attend === \'absence\'}"><br>\u3054\u6b20\u5e2d\u3092\u3055\u308c\u307e\u3059\u304a\u5ba2\u69d8\u3082\u3001\u30af\u30ec\u30b8\u30c3\u30c8\u6c7a\u6e08\u306b\u3066\u3054\u65b0\u90ce\u3054\u65b0\u5a66\u69d8\u3078\u304a\u795d\u3044\u91d1\u306e\u304a\u6e21\u3057\u304c\u53ef\u80fd\u3067\u3054\u3056\u3044\u307e\u3059\u3002</p> </div> <div class="absence"> <div class="boxRadio-wrap"> <label class="boxRadio" onchange="{toggleSettlement}"> <input type="{guest.attend !== \'absence\' ? \'radio\' : \'checkbox\'}" __disabled="{!canSettlement}" class="boxRadio-input" name="want_settlement" __checked="{wantSettlement === true}"> <span class="boxRadio-parts">Web\u3067\u6c7a\u6e08</span> </label> <label class="boxRadio" onchange="{toggleSettlement}" if="{guest.attend !== \'absence\' && !host.require_settlement}"> <input type="radio" class="boxRadio-input" name="want_settlement" __disabled="{!canSettlement}" __checked="{wantSettlement === false}"> <span class="boxRadio-parts">\u5f53\u65e5\u306e\u304a\u6e21\u3057</span> </label> </div> </div> <input type="hidden" name="guest[settlements_attributes][0][guest_attend]" value="{guest.attend}"> <input type="hidden" name="guest[settlements_attributes][0][want_settlement]" value="{wantSettlement === true ? 1 : 0}"> <div if="{wantSettlement !== false && canSettlement}"> <input type="hidden" id="upcmemberid" name="guest[settlements_attributes][0][upcmemberid]"> <input type="hidden" id="expired_at" name="guest[settlements_attributes][0][expired_at]"> <input type="hidden" id="masked_cardno" name="guest[settlements_attributes][0][masked_cardno]"> <input type="hidden" name="guest[settlements_attributes][0][dine_expense]" value="{sumAmount}"> <h3 class="spare-title">{settlementTitle}</h3> <div class="cont_box" if="{host.purpose == \'shugi\' || guest.attend === \'absence\'}"> <p><span class="text-bold">\u5341\u4e07\u30fb\u4e07\u30fb\u5343</span>\u306e\u5358\u4f4d\u306e\u5024\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044</p> <div class="select-price"> <select class="num" name="guest[settlements_attributes][0][dine_expense_i1]" onchange="{shugiSelect}"> <option each="{i in amounts_i1}" value="{i}" __selected="{i == dine_expense_i1 ? \'selected\' : null}">{i == 0 ? \'-\' : i}</option> </select> <select class="num" name="guest[settlements_attributes][0][dine_expense_i2]" onchange="{shugiSelect}"> <option each="{i in amounts_i2_i3}" __selected="{i == dine_expense_i2 ? \'selected\' : null}">{i}</option> </select> <select class="num" name="guest[settlements_attributes][0][dine_expense_i3]" onchange="{shugiSelect}"> <option each="{i in amounts_i2_i3}" __selected="{i == dine_expense_i3 ? \'selected\' : null}">{i}</option> </select> <span>,000\u5186</span> </div> </div> <div class="cont_box" if="{host.purpose == \'kaihi\' && guest.attend !== \'absence\'}"> <div> <span class="sum_expense">{sumAmount.toLocaleString()}\u5186</span> <p class="text-attention" if="{sumAmount == 0}">\u203b\u304a\u5148\u306b\u4f1a\u8cbb\u3092\u3054\u9078\u629e\u304f\u3060\u3055\u3044</p> </div> </div> <div class="text-caution text-right" if="{host.isSelfPayment}">\u203b\u624b\u6570\u65995%\u304c\u52a0\u7b97\u3055\u308c\u307e\u3059</div> <div class="cont_box"> <h3 class="spare-title">\u30ab\u30fc\u30c9\u60c5\u5831</h3> <table class="cards"> <tr> <td each="{creditCardCompany in creditCardCompanies}"><img riot-src="{creditCardCompany}"></td> </tr> </table> <div class="formBox-wrap card_info_box"> <dl class="formBox solid-btm"> <dt>\u2f94\u8a9e</dt> <dd> <div class="select fill"> <select name="lang" id="lang"> <option value="ja">\u2f47\u672c\u8a9e\uff08ja\uff09</option> <option value="en">\u82f1\u8a9e\uff08en\uff09</option> <option value="cn">\u4e2d\u56fd\u8a9e\uff08cn\uff09</option> <option value="tw">\u53f0\u6e7e\u8a9e\uff08tw\uff09</option> </select> </div> </dd> </dl> <dl class="formBox solid-btm"> <dt>\u30ab\u30fc\u30c9\u756a\u53f7</dt> <dd><input class="textfield fill" pattern="\\d*" value="" name="cardno" id="cardno" type="number"></dd> </dl> <dl class="formBox solid-btm"> <dt>\u30ab\u30fc\u30c9\u6709\u52b9\u671f\u9650</dt> <dd class="flex-line"> <input class="textfield fill" pattern="\\d*" placeholder="month" name="expire_month" id="expire_month" type="number">/ <input class="textfield fill" pattern="\\d*" placeholder="year" name="expire_year" id="expire_year" type="number"> </dd> </dl> <dl class="formBox solid-btm"> <dt>\u30ab\u30fc\u30c9\u540d\u7fa9</dt> <dd class="flex-sprit"> <input class="textfield fill" type="text" placeholder="Tarou" name="holderfirstname" id="holderfirstname"> <input class="textfield fill" type="text" placeholder="Yamamoto" name="holderlastname" id="holderlastname"> </dd> </dl> <dl class="formBox solid-btm"> <dt class="pos-rel"> \u30bb\u30ad\u30e5\u30ea\u30c6\u30a3\u30b3\u30fc\u30c9 <div class="tooltip-card"> <div class="box"> <img riot-src="{exampleCreditImage}" class="security_code_image"> \u30ab\u30fc\u30c9\u88cf\u9762\u7f72\u540d\u6b04\u306b\u5370\u5b57\u3055\u308c\u3066\u3044\u308b\u53f3\u7aef4\u6841\u306e\u6570\u5b57\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044 </div> <span class="icon">\uff1f</span> </div> </dt> <dd><input class="textfield fill" type="text" placeholder="123" name="securitycode" id="securitycode"></dd> </dl> <dl class="formBox solid-btm"> <dt>\u96fb\u8a71\u756a\u53f7</dt> <dd><input class="textfield fill" type="text" placeholder="0123456789" name="guest[settlements_attributes][0][tel]"></dd> </dl> <div class="text-caution text-right">*\u6c7a\u6e08\u65b9\u6cd5\u306f\u4e00\u62ec\u306e\u307f\u3068\u306a\u308a\u307e\u3059</div> </div> </div> </div> </div> <input type="hidden" name="guest[settlements_attributes][0][host_purpose]" value="{host.purpose}"> <input type="hidden" name="proc" value="{commit}"> <div class="button-bar"> <button type="button" onclick="{validator}" value="confirm" name="button btn-conf" id="btn-sub" class="button btn-normal btn-large"> <span>\u78ba\u8a8d\u753b\u9762\u3078</span> </button> </div>', "", "", function (e) {
        var s = this;
        s.host = e.data.host, s.guest = e.data.guest, s.guest.errors = {}, s.companions = e.data.companions, s.settlement = e.data.settlement, s.creditInfo = {
            token: "",
            expired_at: "",
            masked_cardno: ""
        }, s.canSettlement = e.data.canSettlement, s.creditCardCompanies = e.data.creditCardCompanies, s.dineExpenses = e.data.dineExpenses, s.formSetting = e.data.formSetting, s.wantSettlement = !!s.canSettlement && e.data.wantSettlement, s.sumAmount = e.data.sumAmount, s.sumPeople = e.data.sumPeople, s.noImage = e.noImage, s.exampleCreditImage = e.exampleCreditImage, s.requiredColumns = e.data.requiredColumns, s.commit = e.commit, s.frm = e.frm, s.settlementTitle = "kaihi" === s.host.purpose ? "\u4f1a\u8cbb" : "\u304a\u795d\u3044\u91d1", s.amounts_i2_i3 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], s.amounts_i1 = [0, 1], s.dine_expense_i1 = e.data.dineExpense[0], s.dine_expense_i2 = e.data.dineExpense[1], s.dine_expense_i3 = e.data.dineExpense[2], this.on("mount", function () {
            $(".tooltip-mail .icon").on("click", function () {
                $(".tooltip-mail .box").fadeToggle()
            }), $(".tooltip-whos .icon").on("click", function () {
                $(".tooltip-whos .box").fadeToggle()
            }), $(".tooltip-card .icon").on("click", function () {
                $(".tooltip-card .box").fadeToggle()
            }), $(".tooltip-picture .icon").on("click", function () {
                $(".tooltip-picture .box").fadeToggle()
            });
            var e = $(".imgInput"),
                a = $(".imgView");
            e.each(function () {
                var e = $(this),
                    t = $(this).find("input[type=file]"),
                    n = e.find(a),
                    i = n.attr("src");
                t.change(function () {
                    var e = $(this).prop("files")[0],
                        t = new FileReader;
                    this.files.length && e.type.match("image.*") ? (t.onload = function () {
                        n.attr("src", t.result)
                    }, t.readAsDataURL(e)) : n.attr("src", i)
                })
            })
        }), this.checkAttend = function (e) {
            s.guest.attend = e.target.value, s.canSettlement ? s.wantSettlement = !0 : s.wantSettlement = !1, s.settlementTitle = "kaihi" === s.host.purpose ? "\u4f1a\u8cbb" : "\u304a\u795d\u3044\u91d1"
        }.bind(this), this.checkDontAttend = function (e) {
            s.guest.attend = e.target.value, s.wantSettlement = !1, s.settlementTitle = "\u304a\u795d\u3044\u91d1"
        }.bind(this), this.toggleSettlement = function () {
            s.wantSettlement = !s.wantSettlement, s.guest.want_settlement = s.wantSettlement, s.settlement.want_settlement = s.wantSettlement
        }.bind(this), this.removeCheck = function (e) {
            $(e.target).prop("checked") && ($('[name="guest[gender]"]').prop("checked", !1), $(e.target).prop("checked", !0), s.guest.gender = e.target.value)
        }.bind(this), this.dineExpenseSelect = function (e, t) {
            if ("" !== t.target.value) {
                var n = s.dineExpenses.filter(function (e) {
                    return e.id == t.target.value
                })[0];
                e.dine_expense_id = n.id, e.dine_expense_category = n.category, e.dine_expense_amount = n.amount;
                var i = s.companions.map(function (e) {
                        return e.dine_expense_amount || 0
                    }),
                    a = [s.guest.dine_expense_amount || 0].concat(i);
                s.sumAmount = a.reduce(function (e, t) {
                    return e + t
                }), s.update()
            }
        }.bind(this), this.shugiSelect = function () {
            var e = String(document.querySelector('[name="guest[settlements_attributes][0][dine_expense_i1]"]').value),
                t = String(document.querySelector('[name="guest[settlements_attributes][0][dine_expense_i2]"]').value),
                n = String(document.querySelector('[name="guest[settlements_attributes][0][dine_expense_i3]"]').value);
            s.sumAmount = Number(e + t + n + "000"), s.guest.dine_expense_amount = s.sumAmount, s.guest.dine_expense_category = "\u304a\u795d\u3044\u91d1", s.update()
        }.bind(this), this.addCompanion = function () {
            s.companions.push({
                id: null
            })
        }.bind(this), this.deleteCompanion = function (n) {
            s.companions = s.companions.filter(function (e, t) {
                return t !== n
            }), document.querySelector('[name="guest[companions_attributes][' + n + '][_destroy]"]').value = 1
        }.bind(this), this.validator = function () {
            s.guest.errors = {}, s.requiredColumns.forEach(function (e) {
                if ("absence" !== s.guest.attend || "dine_expense_id" !== e) {
                    var t = !1;
                    t = 0 <= ["attend", "gender", "whos_guest", "dine_expense_id"].indexOf(e) ? 0 === $('input[name="guest[' + e + ']"]:checked').length : "" === $('input[name="guest[' + e + ']"]').val(), s.guest.errors[e] = t
                }
            });
            var e = !1;
            for (key in s.guest.errors)
                if (e = !!s.guest.errors[key]) break;
            if (e) return $("html, body").animate({
                scrollTop: 0
            }, "slow"), !1;
            s.wantSettlement && s.host.use_eshugi ? getMemberToken() : document.forms[0].submit()
        }.bind(this)
    }), riot.tag2("party_schedule",
        '<div class="assist-select-wrap"> <div class="text">\u62db\u5f85\u72b6\u5f62\u5f0f</div> <div class="select"> <select name="host[use_celemony_shop]" id="host_use_celemony_shop" form="{form}" onchange="{multiToggle}"> <option value="0" __selected="{!host.useCelemonyShop}">\u4e00\u4f1a\u5834\u5229\u7528\uff08\u30c7\u30d5\u30a9\u30eb\u30c8\uff09</option> <option value="1" __selected="{host.useCelemonyShop}">\u4e8c\u4f1a\u5834\u5229\u7528\uff08\u6319\u5f0f\u3068\u62ab\u9732\u5bb4\u304c\u5225\u4f1a\u5834\u306e\u5834\u5408\u306f\u3053\u3061\u3089\uff09</option> </select> </div> </div> <div class="data"> <dl class="formBox"> <dt>\u65e5\u7a0b<span class="est">\u5fc5\u9808</span></dt> <dd> <input type="text" name="host[party_date]" id="host_party_date" class="textfield size-date solid" value="{host.partyDate}" form="{form}"> </dd> </dl> <div if="{multi != 1}"> <dl class="formBox"> <dt>\u53d7\u4ed8\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[celemony_acceptance_time]" id="host_celemony_acceptance_time" value="{host.celemonyAcceptanceTime}" form="{form}" onchange="{setValue.bind(this, \'celemonyAcceptanceTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'celemonyAcceptanceTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u6319\u5f0f\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[celemony_time]" id="host_celemony_time" value="{host.celemonyTime}" form="{form}" onchange="{setValue.bind(this, \'celemonyTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'celemonyTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u958b\u59cb\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[reception_time]" id="host_reception_time" value="{host.receptionTime}" form="{form}" onchange="{setValue.bind(this, \'receptionTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'receptionTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834\u540d<span class="est">\u5fc5\u9808</span></dt> <dd> <input type="text" name="host[shop_name]" id="host_shop_name" class="textfield solid" value="{host.shopName}" form="{form}" onchange="{setValue.bind(this, \'shopName\')}"> </dd> </dl> <dl class="formBox flex-start"> <dt>\u4f1a\u5834\u4f4f\u6240</dt> <dd> <textarea name="host[shop_address]" id="host_shop_address" class="textarea solid mar-b05" form="{form}" onchange="{setValue.bind(this, \'shopAddress\')}">{host.shopAddress}</textarea> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834URL</dt> <dd> <input type="text" name="host[shop_url]" id="host_shop_url" class="textfield solid" value="{host.shopUrl}" form="{form}" onchange="{setValue.bind(this, \'shopUrl\')}"> </dd> </dl> </div> <div if="{multi == 1}"> <h4 class="category-title">\u6319\u5f0f</h4> <dl class="formBox"> <dt>\u53d7\u4ed8\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[celemony_acceptance_time]" id="host_celemony_acceptance_time" value="{host.celemonyAcceptanceTime}" form="{form}" onchange="{setValue.bind(this, \'celemonyAcceptanceTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'celemonyAcceptanceTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u6319\u5f0f\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[celemony_time]" id="host_celemony_time" value="{host.celemonyTime}" form="{form}" onchange="{setValue.bind(this, \'celemonyTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'celemonyTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834\u540d<span class="est">\u5fc5\u9808</span></dt> <dd> <input type="text" name="host[celemony_shop_name]" id="host_celemony_shop_name" class="textfield solid" value="{host.celemonyShopName}" form="{form}" onchange="{setValue.bind(this, \'celemonyShopName\')}"> </dd> </dl> <dl class="formBox flex-start"> <dt>\u4f1a\u5834\u4f4f\u6240</dt> <dd> <textarea name="host[celemony_shop_address]" id="host_celemony_shop_address" class="textarea solid mar-b05" form="{form}" onchange="{setValue.bind(this, \'celemonyShopAddress\')}"> {host.celemonyShopAddress} </textarea> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834URL</dt> <dd> <input type="text" name="host[celemony_shop_url]" id="host_celemony_shop_url" class="textfield solid" value="{host.celemonyShopUrl}" form="{form}" onchange="{setValue.bind(this, \'celemonyShopUrl\')}"> </dd> </dl> <h4 class="category-title">\u30d1\u30fc\u30c6\u30a3\u30fc</h4> <dl class="formBox"> <dt>\u53d7\u4ed8\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[reception_acceptance_time]" id="host_reception_acceptance_time" value="{host.receptionAcceptanceTime}" form="{form}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'receptionAcceptanceTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u958b\u59cb\u6642\u9593</dt> <dd class="flex-line"> <div class="select solid size-time"> <input name="host[reception_time]" id="host_reception_time" value="{host.receptionTime}" form="{form}" onchange="{setValue.bind(this, \'receptionTime\')}" type="{\'time\'}"> </div> <span class="time-clear" onclick="{timeClear.bind(this, \'receptionTime\')}"></span> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834\u540d<span class="est">\u5fc5\u9808</span></dt> <dd> <input type="text" name="host[shop_name]" id="host_shop_name" class="textfield solid" value="{host.shopName}" form="{form}" onchange="{setValue.bind(this, \'shopName\')}"> </dd> </dl> <dl class="formBox flex-start"> <dt>\u4f1a\u5834\u4f4f\u6240</dt> <dd> <textarea name="host[shop_address]" id="host_shop_address" class="textarea solid mar-b05" form="{form}" onchange="{setValue.bind(this, \'shopAddress\')}">{host.shopAddress}</textarea> </dd> </dl> <dl class="formBox"> <dt>\u4f1a\u5834URL</dt> <dd> <input type="text" name="host[shop_url]" id="host_shop_url" class="textfield solid" value="{host.shopUrl}" form="{form}" onchange="{setValue.bind(this, \'shopUrl\')}"> </dd> </dl> </div> <dl class="formBox flex-start" if="{host.purpose === \'kaihi\'}"> <dt>\u4f1a\u8cbb</dt> <dd show="{dineExpenses.length > 0}"> <dl class="party-fees" each="{de in dineExpenses}"> <dt>{de.category}</dt> <dd>{Number(de.amount).toLocaleString()}\u5186</dd> </dl> </dd> <dd show="{dineExpenses.length <= 0}"> STEP2\u3067\u8a2d\u5b9a\u3067\u304d\u307e\u3059 </dd> </dl> </div> <div class="memo"> \u5099\u8003 <textarea name="host[note]" id="host_note" class="textarea solid">{host.note}</textarea> </div> <div class="period" if="{!host.complete}"> \u8fd4\u4fe1\u671f\u65e5 <span class="est">\u5fc5\u9808</span> <input type="text" name="host[closing_date]" id="host_closing_date" class="textfield size-date solid datepicker" value="{host.closingDate}"> <div class="text-attention">\u958b\u50ac\u65e5\u7a0b\u4ee5\u964d\u306e\u65e5\u4ed8\u306f\u767b\u9332\u3067\u304d\u307e\u305b\u3093\u3002</div> </div> <div class="period" show="{host.complete}"> \u8fd4\u4fe1\u671f\u65e5 {host.closingDate} </div>', "", "",
        function (e) {
            var n = this;
            n.host = e.host, n.form = e.form, n.multi = e.multi, n.dineExpenses = e.host.dineExpenses, n.placeholder = e.placeholder, this.on("mount", function () {
                $("#host_closing_date").datepicker({
                    language: "ja",
                    dateFormat: "yy\u5e74m\u6708d\u65e5",
                    minDate: "0y"
                }), $("#host_party_date").datepicker({
                    language: "ja",
                    dateFormat: "yy\u5e74m\u6708d\u65e5(D)",
                    minDate: "0y",
                    onSelect: function () {
                        n.update()
                    }
                }), n.update()
            }), this.on("update", function () {
                if (null != $("#host_party_date").val()) {
                    var e = $.datepicker.parseDate("yy\u5e74m\u6708d\u65e5(D)", $("#host_party_date").val());
                    $("#host_closing_date").datepicker("option", "maxDate", e)
                }
            }), this.timeClear = function (e, t) {
                n.host[e] = null, t.target.previousElementSibling.firstElementChild.value = ""
            }.bind(this), this.multiToggle = function (e) {
                n.multi = e.target.value
            }.bind(this), this.setValue = function (e) {
                n.host[e] = event.target.value
            }.bind(this)
        }), riot.tag2("reception_list", '<h2 class="reception-title">\u30b9\u30de\u30db\u53d7\u4ed8</h2> <p class="text-attention mar-t10 mar-b10 text-center"> \u304a\u5ba2\u69d8\u306e\u901a\u4fe1\u74b0\u5883\u306b\u3088\u308a\u3001\u66f4\u65b0\u306b\u6642\u9593\u304c\u304b\u304b\u308b\u5834\u5408\u304c\u3054\u3056\u3044\u307e\u3059\u3002<br> \u4e0a\u8a18\u306b\u3088\u308a\u767a\u751f\u3059\u308b\u4e0d\u5177\u5408\u306b\u95a2\u3057\u3001\u5f53\u793e\u306f\u4e00\u5207\u8cac\u4efb\u3092\u8ca0\u3044\u307e\u305b\u3093\u3002 </p> <div class="top-buttons"> <button class="button btn-solid" show="{host.purpose == \'kaihi\'}" onclick="{aggregateModalOpen}">\u96c6\u8a08</button> <div class="controls"> <p class="reload" onclick="{reload}"><i class="fas fa-redo-alt"></i>\u66f4\u65b0</p> <p class="{memo: true, active: host.web_reception_note.length > 0}" onclick="{receptionNoteModalOpen}"><i class="fas fa-edit"></i>\u5099\u8003</p> </div> </div> <div class="basicRadio-wrap whos-selector" if="{formSetting.need_whos_guest}"> <label class="basicRadio" onchange="{changeWhosTab}"> <input class="basicRadio-input" type="radio" value="all" name="whos" __checked="{whosTab === \'all\'}"> <span class="basicRadio-parts">\u5168\u3066</span> </label> <label class="basicRadio" onchange="{changeWhosTab}"> <input class="basicRadio-input" type="radio" value="groom" name="whos" __checked="{whosTab === \'groom\'}"> <span class="basicRadio-parts">\u65b0\u90ce\u30b2\u30b9\u30c8</span> </label> <label class="basicRadio" onchange="{changeWhosTab}"> <input class="basicRadio-input" type="radio" value="bride" name="whos" __checked="{whosTab === \'bride\'}"> <span class="basicRadio-parts">\u65b0\u5a66\u30b2\u30b9\u30c8</span> </label> </div> <ul class="reception-tab"> <li class="{active: receptionTab === \'incomplete\'}" onclick="{changeReceptionTab.bind(this, \'incomplete\')}"> \u672a\u53d7\u4ed8({guestsSize.incomplete}\u4eba) </li> <li class="{active: receptionTab === \'complete\'}" onclick="{changeReceptionTab.bind(this, \'complete\')}"> \u53d7\u4ed8\u6e08({guestsSize.complete}\u4eba) </li> <li class="{active: receptionTab === \'all\'}" onclick="{changeReceptionTab.bind(this, \'all\')}"> \u5168\u3066({guestsSize.all}\u4eba) </li> </ul> <div class="reception-search"> <ul> <li each="{list in kanaIndexLists}" onclick="{toggleKanaList.bind(this, list.values)}">{list.index}</li> </ul> <ul class="kana-list" show="{kanaList.length > 0}"> <li each="{kana, i in kanaList}" class="{disable: disabledKanaList[i]}" onclick="{kanaAnchor.bind(this, kana)}"> {kana} </li> </ul> </div> <table class="reception-table"> <tbody> <tr id="{guest.kanaIndex}" each="{guest, i in selectedGuests}"> <td> <div class="switchCheck-wrap center"> <label class="switchCheck"> <input type="checkbox" class="switchCheck-input" __checked="{guest.isReception}" onclick="{toggleReception.bind(this, guest)}"> <span class="switchCheck-parts"></span> </label> </div> </td> <td class="{text-left: true, bride: guest.whosGuest === \'bride\', groom: guest.whosGuest === \'groom\'}"> <div class="name"><p>{guest.kana}</p>{guest.name}</div> <ul if="{guest.companions.length > 0}"> <li each="{companion in guest.companions}"> <div class="name"><p class="font12">{companion.kana}</p>{companion.name}</div> </li> </ul> </td> <td> <div if="{host.purpose === \'shugi\'}"><p if="{guest.paymentMethod == 0}">\u304a\u795d\u3044\u91d1<br>\u9802\u6234\u6e08</p></div> <div class="color-gray" if="{host.purpose === \'kaihi\' && guest.paymentMethod == 0}">\u9802\u6234\u6e08</div> <div class="basicCheck-wrap center" if="{host.purpose === \'kaihi\' && guest.paymentMethod != 0}"> <label class="basicCheck"> <input type="checkbox" class="basicCheck-input" __checked="{guest.receptionPaid == 1}" onchange="{receptionPaidUpdate.bind(this, guest)}"> <span class="basicCheck-parts">{Number(guest.dineExpenseAmount || 0).toLocaleString()}\u5186</span> </label> </div> </td> <td onclick="{memoModalOpen.bind(this, guest)}"> <i class="{fas: true, fa-edit: true, active: guest.receptionMemo}"></i> </td> </tr> </tbody> </table> <div class="reception-overlay" show="{overlay}" onclick="{modalClose}"></div> <div class="memo modal" show="{memo}"> <textarea class="textarea" name="guest-reception-memo" if="{guest}">{guest.receptionMemo}</textarea> <div class="button-bar"> <a class="button btn-solid btn-small" onclick="{modalClose}">\u30ad\u30e3\u30f3\u30bb\u30eb</a> <a class="button btn-submit btn-small" onclick="{memoUpdate}">\u4fdd\u5b58</a> </div> </div> <div class="memo modal" show="{receptionNote}"> <textarea class="textarea" name="host-reception-note">{host.web_reception_note}</textarea> <div class="button-bar"> <a class="button btn-solid btn-small" onclick="{receptionNoteCancel}">\u30ad\u30e3\u30f3\u30bb\u30eb</a> <a class="button btn-submit btn-small" onclick="{receptionNoteUpdate}">\u4fdd\u5b58</a> </div> </div> <div class="aggregate modal" show="{aggregate}"> <h2 class="reception-title">\u96c6\u8a08</h2> <dl> <dt>\u4eba\u6570</dt><dd>{(guestsSize.complete || 0).toLocaleString()} / {(guestsSize.all || 0).toLocaleString()}</dd> </dl> <dl> <dt>\u4f1a\u8cbb</dt> <dd show="{!loading}">{(amount.complete || 0).toLocaleString()} / {(amount.all || 0).toLocaleString()}</dd> <dd show="{loading}"><img riot-src="{loadingImg}" width="30" height="auto"></dd> </dl> <p class="text-attention text-center mar-b10" show="{host.use_eshugi === true}">\u5f53\u65e5\u304a\u9810\u304b\u308a\u4e88\u5b9a\u306e\u91d1\u984d\u5408\u8a08\u3067\u3059\u3002<br class="pc-none">\u4e8b\u524d\u6c7a\u6e08\u91d1\u984d\u306f\u542b\u307e\u308c\u3066\u304a\u308a\u307e\u305b\u3093\u3002</p> </div> <div class="alert-modal" show="{warning}"> </div>', "reception_list { position: relative; }", "", function (e) {
        var i = this;
        i.guests = e.guests, i.host = e.host, i.formSetting = e.form_setting, i.loadingImg = e.loading_img, i.kanaIndexLists = e.kana_index_lists, i.existKanaList = e.exist_kana_list, i.disabledKanaList = [], i.receptionTab = "incomplete", i.whosTab = "all", i.selectedGuests = i.guests.incompleteGuests, i.guest = null, i.overlay = !1, i.memo = !1, i.receptionNote = !1, i.warning = !1, i.kanaList = [], i.guestsSize = {
            incomplete: 0,
            complete: 0,
            all: 0
        }, i.amount = {
            complete: 0,
            all: 0
        }, this.on("update", function () {
            i.guestsSize = {
                incomplete: guestsCount(i.guests.incompleteGuests),
                complete: guestsCount(i.guests.completeGuests),
                all: guestsCount(i.guests.allGuests)
            }, i.amount = {
                complete: amountCalc(i.guests.completeGuests),
                all: amountCalc(i.guests.allGuests)
            }
        }), guestsCount = function (e) {
            var t = e.length;
            return e.forEach(function (e) {
                t += e.companions.length
            }), t
        }, amountCalc = function (e) {
            var t = 0;
            return e.forEach(function (e) {
                0 != e.paymentMethod && (t += e.dineExpenseAmount)
            }), t
        }, changeReceptionTab = function (e) {
            var t = {
                incomplete: "incompleteGuests",
                complete: "completeGuests",
                all: "allGuests"
            } [i.receptionTab = e];
            i.selectedGuests = i.guests[t || "incompleteGuests"]
        }, modalClose = function () {
            i.overlay = !1, i.memo = !1, i.receptionNote = !1, i.aggregate = !1, i.guest = null
        }, guestUpdate = function (e) {
            $.ajax({
                method: "PATCH",
                dataType: "json",
                url: "/reception",
                data: {
                    key: i.host.reception_access_token,
                    whos: i.whosTab,
                    guest: {
                        id: e.id,
                        is_reception: e.isReception,
                        reception_paid: e.receptionPaid,
                        reception_memo: e.receptionMemo,
                        is_edit: !0
                    }
                }
            }).done(function (e) {
                i.guests = e
            }).fail(function (e) {
                i.errors = JSON.parse(e.responseText)
            }).always(function () {
                changeReceptionTab(i.receptionTab), modalClose(), i.update()
            })
        }, this.toggleReception = function (e) {
            e.isReception ? (e.isReception = !1, e.receptionPaid = 0) : (e.isReception = !0, e.receptionPaid = 1), guestUpdate(e)
        }.bind(this), this.receptionPaidUpdate = function (e) {
            0 != e.paymentMethod && (e.receptionPaid = 0 == e.receptionPaid ? 1 : 0, guestUpdate(e))
        }.bind(this), this.memoModalOpen = function (e) {
            i.guest = e, i.overlay = !0, i.memo = !0
        }.bind(this), this.memoUpdate = function () {
            i.guest.receptionMemo = document.querySelector('[name="guest-reception-memo"]').value, guestUpdate(i.guest)
        }.bind(this), this.receptionNoteCancel = function () {
            document.querySelector('[name="host-reception-note"]').value = i.host.web_reception_note, modalClose()
        }.bind(this), this.toggleKanaList = function (e) {
            i.kanaList = i.kanaList == e ? [] : e, 0 < e.length ? i.disabledKanaList = e.map(function (e) {
                return !i.existKanaList.includes(e)
            }) : i.disabledKanaList = []
        }.bind(this), this.kanaAnchor = function (e) {
            if (!event.target.classList.contains("disable")) {
                var t = document.getElementById(e);
                if (null != t) {
                    t.scrollIntoView(!0);
                    var n = document.querySelectorAll("#" + e);
                    n.forEach(function (e) {
                        e.classList.add("flash")
                    }), setTimeout(function () {
                        n.forEach(function (e) {
                            e.classList.remove("flash")
                        })
                    }, 800), i.kanaList = []
                }
            }
        }.bind(this), reload = function () {
            $.ajax({
                method: "GET",
                dataType: "json",
                url: "/reception",
                data: {
                    key: i.host.reception_access_token,
                    whos: i.whosTab
                }
            }).done(function (e) {
                i.host = e.host, i.guests = e.guests
            }).always(function () {
                changeReceptionTab(i.receptionTab), i.update()
            })
        }, this.changeWhosTab = function (e) {
            i.whosTab = e.target.value, reload()
        }.bind(this), this.aggregateModalOpen = function () {
            i.overlay = !0, i.aggregate = !0, i.loading = !0, i.amount = {
                complete: amountCalc(i.guests.completeGuests),
                all: amountCalc(i.guests.allGuests)
            }, i.update(), i.loading = !1
        }.bind(this), this.receptionNoteModalOpen = function () {
            i.overlay = !0, i.receptionNote = !0
        }.bind(this), this.receptionNoteUpdate = function () {
            var e = document.querySelector('[name="host-reception-note"]').value;
            $.ajax({
                method: "PATCH",
                dataType: "json",
                url: "/reception",
                data: {
                    key: i.host.reception_access_token,
                    host: {
                        web_reception_note: e
                    }
                }
            }).done(function (e) {
                i.host = e
            }).fail(function (e) {
                i.errors = JSON.parse(e.responseText)
            }).always(function () {
                modalClose(), i.update()
            })
        }.bind(this)
    });

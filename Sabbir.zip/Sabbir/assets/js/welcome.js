$(function () {
    var e = $("#lpPage");
    $("#js__btn").on("click", function () {
        e.toggleClass("open")
    }), $("#js__nav").on("click", function () {
        e.removeClass("open")
    }), $("#js-btn").on("click", function () {
        e.toggleClass("open")
    }), $("#js-nav").on("click", function () {
        e.removeClass("open")
    }), $('a[href^="#"]').click(function () {
        var e = 1e3,
            i = $(this).attr("href"),
            o = $("#" == i || "" == i ? "html" : i).offset().top;
        return $("html, body").animate({
            scrollTop: o
        }, e, "swing"), !1
    }), $(".qa-wrap.toggle dt").on("click", function () {
        $(this).next().slideToggle("fast"), $(this).toggleClass("open")
    })
}), $(window).load(function () {
    function e() {
        $(window).width() <= 767 ? i.reloadSlider() : i.destroySlider()
    }
    $(".design-slider .slider ul").bxSlider({
        pause: 5e3,
        speed: 1e3,
        maxSlides: 1,
        moveSlides: 1,
        pager: !1,
        auto: !0,
        mode: "fade",
        infiniteLoop: !0
    }), $(".design").bxSlider({
        ticker: !0,
        speed: 7e4,
        slideWidth: 250,
        maxSlides: 12,
        moveSlides: 1,
        slideMargin: 30
    });
    var i = $(".howto-lp ul").bxSlider({
        slideWidth: 300,
        maxSlides: 1,
        moveSlides: 1,
        controls: !0,
        pager: !1
    });
    e(), $(window).resize(function () {
        e()
    })
});
